//应写入腾讯地图的key
var fileHost = "https://image.chengzong.top/";//你的阿里云OSS地址  在你当前小程序的公众号后台的uploadFile 合法域名也要配上这个域名
var config = {
  uploadImageUrl: `${'/vzhushou/upload/'}`, // 默认存在根目录，可根据需求改
  AccessKeySecret: 'u2yBpUFBLH1KU9tu4H1Sn44npKMPet',        // AccessKeySecret 去你的阿里云上控制台上找
  OSSAccessKeyId: 'LTAI3BA8pYllyq7x',         // AccessKeyId 去你的阿里云上控制台上找
  timeout: 80000 //这个是上传文件时Policy的失效时间
};

module.exports = {

  key: "LG2BZ-PLTWV-BDCPG-UPBKB-XJHQO-HYFXV",
  config:config ,
  fileHost:fileHost
}