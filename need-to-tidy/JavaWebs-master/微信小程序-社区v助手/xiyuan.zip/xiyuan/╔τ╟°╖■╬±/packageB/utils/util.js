function formatTime(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()

  var hour = date.getHours()
  var minute = date.getMinutes()
  var second = date.getSeconds()


  return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

function formatDate(date) {
  var Y = date.getFullYear() + '-';
  var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
  var D = date.getDate() + ' ';


  return Y+M+D
}

function formatDate4YearMotchDay(year, month, day) {
  return [year, month, day].map(formatNumber).join('-')
}

function formatNumber(n) {
  n = n.toString()
  return n[1] ? n : '0' + n
}

function compareDate(DateOne, DateTwo) {
  var OneMonth = DateOne.substring(5, DateOne.lastIndexOf("-"));
  var OneDay = DateOne.substring(DateOne.length, DateOne.lastIndexOf("-") + 1);
  var OneYear = DateOne.substring(0, DateOne.indexOf("-"));
  var TwoMonth = DateTwo.substring(5, DateTwo.lastIndexOf("-"));
  var TwoDay = DateTwo.substring(DateTwo.length, DateTwo.lastIndexOf("-") + 1);
  var TwoYear = DateTwo.substring(0, DateTwo.indexOf("-"));
  if (Date.parse(OneMonth + "/" + OneDay + "/" + OneYear) > Date.parse(TwoMonth + "/" + TwoDay + "/" + TwoYear)) {
    return true;
  } else {
    return false;
  }
}

function arrayContains(arr, obj) {
  var i = arr.length;
  while (i--) {
    if (arr[i] === obj) {
      return true;
    }
  }
  return false;
}
// 删除本地的Storage
var removeStorage = function (key) {
  wx.removeStorage({
    key: key,
    success: function (res) {
    }
  })
};
// 添加本地的Storage
var setStorage = function (key, val) {
  wx.setStorage({
    key: key,
    data: val
  })
};
// 提示框
var showModal = function (title, text) {
  if (arguments.length == 1) {
    text = arguments[0];
    title = null;
  }
  wx.showModal({
    title: title || "提示",
    showCancel: false,
    content: text
  });
}

function timeago(dateTimeStamp) {   //dateTimeStamp是一个时间毫秒，注意时间戳是秒的形式，在这个毫秒的基础上除以1000，就是十位数的时间戳。13位数的都是时间毫秒。
  var result="";
  var minute = 1000 * 60;      //把分，时，天，周，半个月，一个月用毫秒表示
  var hour = minute * 60;
  var day = hour * 24;
  var week = day * 7;
  var halfamonth = day * 15;
  var month = day * 30;
  var now = new Date().getTime();   //获取当前时间毫秒
  console.log(now)
  var diffValue = now - dateTimeStamp;//时间差

  if (diffValue < 0) {
    return;
  }
  var minC = diffValue / minute;  //计算时间差的分，时，天，周，月
  var hourC = diffValue / hour;
  var dayC = diffValue / day;
  var weekC = diffValue / week;
  var monthC = diffValue / month;
  if (monthC >= 1 && monthC <= 3) {
    result = " " + parseInt(monthC) + "月前"
  } else if (weekC >= 1 && weekC <= 3) {
    result = " " + parseInt(weekC) + "周前"
  } else if (dayC >= 1 && dayC <= 6) {
    result = " " + parseInt(dayC) + "天前"
  } else if (hourC >= 1 && hourC <= 23) {
    result = " " + parseInt(hourC) + "小时前"
  } else if (minC >= 1 && minC <= 59) {
    result = " " + parseInt(minC) + "分钟前"
  } else if (diffValue >= 0 && diffValue <= minute) {
    result = "刚刚"
  } else {
    var datetime = new Date();
    datetime.setTime(dateTimeStamp);
    var Nyear = datetime.getFullYear();
    var Nmonth = datetime.getMonth() + 1 < 10 ? "0" + (datetime.getMonth() + 1) : datetime.getMonth() + 1;
    var Ndate = datetime.getDate() < 10 ? "0" + datetime.getDate() : datetime.getDate();
    var Nhour = datetime.getHours() < 10 ? "0" + datetime.getHours() : datetime.getHours();
    var Nminute = datetime.getMinutes() < 10 ? "0" + datetime.getMinutes() : datetime.getMinutes();
    var Nsecond = datetime.getSeconds() < 10 ? "0" + datetime.getSeconds() : datetime.getSeconds();
    result = Nyear + "/" + Nmonth + "/" + Ndate
  }
  return result;
}

function timeFormat(param) {//小于10的格式化函数
  return param < 10 ? '0' + param : param;
}

function realtime(dateTimeStamp)
{
  var now=new Date();
  var time = (dateTimeStamp - now.getTime())/1000; //计算剩余的毫秒数 
  var hours = parseInt(time % (60 * 60 * 24) / 3600); //计算剩余的小时 
  var minutes = parseInt(time % (60 * 60 * 24) % 3600 / 60);//计算剩余的分钟 
  var seconds = parseInt(time % (60 * 60 * 24) % 3600 % 60);//计算剩余的秒数 

  hours = timeFormat(hours);
  minutes = timeFormat(minutes);
  seconds = timeFormat(seconds);

  if (time<0) {
   return "车位预留时间已过";
  }
  else
  {
    return  hours + "小时" + minutes + "分" + seconds + "秒";
  }

}

module.exports = {
  formatTime: formatTime,
  formatDate: formatDate,
  formatDate4YearMotchDay: formatDate4YearMotchDay,
  compareDate: compareDate,
  arrayContains: arrayContains,
  removeStorage: removeStorage,
  setStorage: setStorage,
  showModal: showModal,
  timeago: timeago,
  realtime: realtime,
  timeFormat:timeFormat
}
