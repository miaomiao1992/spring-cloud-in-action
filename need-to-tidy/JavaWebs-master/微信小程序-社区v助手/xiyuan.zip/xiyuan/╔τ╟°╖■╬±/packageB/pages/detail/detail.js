// pages/detail/detail.js
 var utils=require("../../utils/util.js")
Page({
  data: {
    imgUrls: [
      'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1494392460210&di=e2676cd3576ae88c8c528f0dfb8ffd5e&imgtype=0&src=http%3A%2F%2Fstc.zjol.com.cn%2Fg1%2FM0007FDCggSDVeOIZiAIDGbAAEfo007Rck797.jpg%3Fwidth%3D720%26height%3D431'
    ],
    indicatorDots: false,
    autoplay: false,
    interval: 5000,
    duration: 1000,
    park:{}
    
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
    var that=this


    // 显示加载中
    wx.showToast({
      title: '加载中',
      icon: 'loading',
      duration: 200
    });
    //获取停车信息
    wx.request({
      url: app.globalData.myhost+'/Park/GetPark',
      method: "GET",
      data:
      {
      id:options.id
      },

      success: function (res) {



        that.setData({
          park: res.data.data
        }


        )



      }
    })


  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  },
  
  preOrder: function (e) {
    
    var name = e.currentTarget.dataset.name;
    var price = e.currentTarget.dataset.price;
    var id = e.currentTarget.dataset.id;
    var sparepark = e.currentTarget.dataset.sparepark

    if(sparepark==0)
    {
      utils.showModal("停车场已无空位")
    }
    else
    {
    wx.navigateTo({
      url: '../preOrder/preOrder?name='+name +'&price='+price+'&id='+id,
    })
    }
  }

})