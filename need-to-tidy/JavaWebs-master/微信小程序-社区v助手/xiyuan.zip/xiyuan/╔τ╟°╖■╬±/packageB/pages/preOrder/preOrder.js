// pages/preOrder/preOrder.js
var utils=require("../../utils/util.js")
var app=getApp()
Page({
  data: {plateAreaCharset: ['京', '津', '沪', '渝', '冀', '豫', '云', '辽', '黑', '湘', '皖', '鲁', '新', '苏', '浙', '赣', '鄂', '桂', '甘', '晋', '蒙', '陕', '吉', '闽', '贵', '粤', '青', '藏', '川', '宁', '琼'],
    plateDigitCharset: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Z', 'X', 'C', 'V', 'B', 'N', 'M'],
    inputBoxData: [{ char: '', hover: '' }, { char: '', hover: '' }, { char: '', hover: '' }, { char: '', hover: '' }, { char: '', hover: '' }, { char: '', hover: '' }, { char: '', hover: '' }],
    currentPos: null,
    showAreaKeyBoard: false,
    showKeyBoard: false,
    hasUnpaidOrders: false,
    orders: [],
    animationData: {},
    showLoading: false,
    isXuanze: false,
    noXuanze: true,
    plateNumber:"",//车牌
    price:0,//每小时单价
    parkname:"",
    parkId:0,
    "excRule": [{
      "name": "一小时",
      "value": 1
    }, {
      "name": "两小时",
      "value": 2
    }, {
      "name": "三小时",
      "value": 3
    }
    ],
    excRuleHidden:true,
    formMsgHidden:true,
    excRuleIndex:0, //选择时长的默认


   
  },
  onLoad: function (options) {
    

    var price = options.price
    var name = options.name
    var parkId=options.id
    var that = this

    that.setData(
      {
        parkId:parkId,
        price: price,
        parkname: name
      }
    )
    if (app.globalData.userInfo.nickName == null) {
      //跳转到登录界面
      wx.switchTab({
        url: '../../../pages/myself/myself'
      })
      return;
    }
 
     


  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  },


  xuanze:function(e)
  {
   var that=this

    var animation = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease',
    })
   animation.top('20rpx').step()
   
   that.putPlateInputBox();
   that.setData(

     {
       animationData: animation.export(),
       isXuanze:true,
       noXuanze:false
     }
   )

  },

  getPlateNumberString: function () {
    return this.data.inputBoxData[0].char
      + this.data.inputBoxData[1].char
      + this.data.inputBoxData[2].char
      + this.data.inputBoxData[3].char
      + this.data.inputBoxData[4].char
      + this.data.inputBoxData[5].char
      + this.data.inputBoxData[6].char
  },
  putPlateInputBox: function () {
    var that=this
    var plateNumber = wx.getStorageSync('plateNumber')
    
    var c=plateNumber.split('')
    
    var num = [{ char: c[0], hover: 'plate-input-digit-hover' }, { char: c[1], hover: 'plate-input-digit-hover' }, { char: c[2], hover: 'plate-input-digit-hover' }, { char: c[3], hover: 'plate-input-digit-hover' }, { char: c[4], hover: 'plate-input-digit-hover' }, { char: c[5], hover: 'plate-input-digit-hover' }, { char: c[6], hover: 'plate-input-digit-hover' }]
    


   that.setData(
     {
       inputBoxData:num,
       currentPos:0
     }
   )

  },

  bindDigitTap: function (res) {
    let inputBoxData = this.data.inputBoxData
    let id = res.currentTarget.id
    let currentPos = id
    console.log('res', res)
    if (id > 6) {
      id = 6
      currentPos = null;
    } else {
      inputBoxData[id].hover = 'plate-input-digit-hover'
    }
    if (this.data.currentPos != null) inputBoxData[this.data.currentPos].hover = ''

    this.setData({
      inputBoxData: inputBoxData,
      currentPos: currentPos
    })

  },
  bindKeyTap: function (res) {
    console.log(res)
    let char = res.currentTarget.dataset.char
    let inputBoxData = this.data.inputBoxData
    inputBoxData[this.data.currentPos].char = char
    let passOnData = {
      currentTarget: {
        id: parseInt(this.data.currentPos) + 1
      }
    }
    this.bindDigitTap(passOnData)
  },

 
  query: function () {
    let that = this
    let plateNumber = this.getPlateNumberString()
    wx.setStorageSync('plateNumber', plateNumber)

    that.setData(

      {
       plateNumber:plateNumber,
       isXuanze:false,
       noXuanze:true
      }
    )
    
    
    

  },



  //选择预留时间
  changeExcRule: function () {
    this.setData({
      excRuleHidden: false
    })
  },
  confirmExcRule: function () {
    this.setData({
      excRuleHidden: true
    })
  },
  selectExcRule: function (e) {
    var num = e.target.dataset.num
    this.setData({
      excRuleIndex: num
    })
    if (num == 4) {
      this.setData({
        customizeWeekHidden: false
      })
    } else {
      this.setData({
        customizeWeekHidden: true
      })
    }
  },
   

  //提交申请
  preOrder: function (event) {
   
    var that = this
  
    var passValidate = true
    var valiNum = 0;
    var formMsg = ""
    
    
    if (that.data.plateNumber== "") {
      passValidate = false
      formMsg = ++valiNum + "、车辆为空\n"
    }
    
    if (!passValidate) {
      that.setData({
        formMsgHidden: false,
        formMsg: formMsg
      })
      return;
    }
    var userInfo = app.globalData.userInfo
  
    var excRuleIndex = that.data.excRuleIndex
    var now =new Date()
    var nows = utils.formatTime(now)
    var end = new Date(now.setHours(now.getHours() + excRuleIndex+1))
    var ends =utils.formatTime(end)

    console.log(nows+ends)
    wx.request({
      url: app.globalData.myhost+"/Park/CreateNewCarOrder",
      data: {
        "location": that.data.parkname,//停车场name
        "userId":app.globalData.openId,
        "username": userInfo.nickName,
        "startDate": nows,
        "endDate":ends,
        "hours": excRuleIndex+1,
        "userId": app.globalData.openId,
        "parkPrice":that.data.price*(excRuleIndex+1),
        "plateNumber": that.data.plateNumber,
        "parkId":that.data.parkId
      },
      header: {
        "Content-Type": "application/json;charset=UTF-8"
      },
      method: 'POST',
      success: function (res) {
        if (res.data.status == -1) {
          wx.switchTab({
            url: '../../../pages/bianmin/bianmin',
          })
        }
        else if (res.data.status == -2) {
          wx.showToast({
            title: "您的车已预约过啦",
            image: '/images/warn.png',
            mask: true,
            duration: 2500
          })
        }else
        {
          wx.showToast({
            title: "您的信誉分为"+res.data.status+"分，不能进行预约",
            image: '/images/warn.png',
            mask: true,
            duration: 2500
          })

        }
      },
      fail: function (res) {
        console.info(res)
      },
      complete: function (res) {
        setTimeout(function () {
          that.setData({
            disableHookBtn: false
          })
        }, 1500)
      }
    })




  },

  //选择时长
  selectExcRule: function (e) {
    var num = e.target.dataset.num
    this.setData({
      excRuleIndex: num
    })
  },
  changeExcRule: function () {
    this.setData({
      excRuleHidden: false
    })
  },
  confirmExcRule: function () {
    this.setData({
      excRuleHidden: true
    })
  },
  
  hiddenFromMsg:function()
  {
    this.setData(
      {
        formMsgHidden: true,
        formMsg: ""
      }
    )
  }
  
})