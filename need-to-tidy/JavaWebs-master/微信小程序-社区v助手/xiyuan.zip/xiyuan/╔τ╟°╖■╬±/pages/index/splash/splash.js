// pages/location/splash/splash.js
var app = getApp();
Page({
  data: {
    city:"",
    userInfo:null
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
    var that = this;

   
      that.setData({
       city: options.city,
       userInfo:app.globalData.userInfo,
      });
      
      

  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  },

  bindmottotap: function (event) {
    var loc = "";
    if (app.globalData.latitude && app.globalData.longitude) {
      loc = "?latitude=" + app.globalData.latitude + "&&longitude=" + app.globalData.longitude;
    }
    wx.navigateTo({
      url: '/packageB/pages/location/location' + loc
    });
  }

})