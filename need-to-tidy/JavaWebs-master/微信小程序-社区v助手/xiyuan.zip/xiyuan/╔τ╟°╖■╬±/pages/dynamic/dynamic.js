var app = getApp()
var util = require('../../utils/util.js')
Page({
  data: {
    windowHeight: 0,
    windowWidth: 0,
    hiddenRelme: true,
    icon: "",
    offset: 0,
    firstLoadDataNum: 0,
    initLimit: 20,
    limit: 10,
    time: 0,
    hiddenFreshResult: true,
    freshResult: "",
    bottomLoadMsg: "点我加载",
    dynamic: [],
    hiddenComment: true,
    commentPlaceholder: "",
    commentDynamicId: "",
    commentReplyKey: "",
    commentReplyName: "",
    commentInput: "",
    commentInitInput: "",
    myOpenId: ""
  },
   
   onShow:function()
   {

     var that = this
     
     //如果没有登录跳转到登录界面
     if (app.globalData.userInfo.nickName == null) {
       //跳转到登录界面
       wx.switchTab({
         url: '../myself/myself'
       })
       return;
     }

     var sysInfo = wx.getSystemInfoSync()

     that.setData({
       windowHeight: sysInfo.windowHeight,
       windowWidth: sysInfo.windowWidth,
       icon: app.globalData.userInfo.avatarUrl,
     })
     //获取拉钩任务
     getDynamic(that, true)

   
     //获取提醒
     checkRelme(that)
     setInterval(function () {
       checkRelme(that)
     }, 60000)
   
   },

  onLoad: function () {

    var that = this

    that.setData({
     myOpenId:app.globalData.openId

    })


   
      that.onShow()
   
 
  },
  toRelme: function () {
    var that = this
    that.setData({
      hiddenRelme: true,
      dynamic:[]
    })
    
    //跳转我的动态
    wx.navigateTo({
      url: '../../packageA/pages/dynrelme/dynrelme'
    })
  },
  //跳转到与我有关
  toMyself: function () {
   var that =this
    that.setData({
      dynamic: []
    })
    wx.navigateTo({
      url: '../../packageA/pages/dynmyself/dynmyself'
    })
  },
  //评论
  //function(e)是触发事件
  toComment: function (e) {

    this.setData({
      commentDynamicId: e.target.dataset.id,
      commentReplyKey: e.target.dataset.key == null ? "" : e.target.dataset.key,
      commentReplyName: e.target.dataset.name == null ? "" : e.target.dataset.name,
      commentPlaceholder: "",
      hiddenComment: false
    })

    
    if (e.target.dataset.key != null) {
      this.setData({
        commentInitInput: "",
        commentInput: ""
      })
    }
  },
  cancelComment: function () {
    this.setData({
      hiddenComment: true
    })
  },
  setCommentInput: function (e) {
    this.setData({
      commentInput: e.detail.value,
      commentInitInput: e.detail.value
    })
  },
  //提交评论
  submitComment: function () {
    var that = this
    if (that.data.commentInput.length == 0) {
      that.setData({
        commentPlaceholder: "评论不能为空"
      })
      return
    }
    console.log("qqq" + app.globalData.openId)
    wx.request({
      url: app.globalData.myhost+"/Draghook/CommentNewOne",
      data: {
        "id": that.data.commentDynamicId,
        "key": app.globalData.openId,
        "name": app.globalData.userInfo.nickName,
        "icon": app.globalData.userInfo.avatarUrl,
        "content": that.data.commentInput,
        "replyKey": that.data.commentReplyKey.length == 0 ? "" : that.data.commentReplyKey,
        "replyName": that.data.commentReplyName.length == 0 ? "" : that.data.commentReplyName
      },
      method:'POST',
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      success: function (res) {
        // 刷新指定的动态评论
        // that.data.commentDynamicId
        refreshDynamic(that, that.data.commentDynamicId)
        //获取提醒
        checkRelme(that)
        that.setData({
          hiddenComment: true,
          commentInput:""   //清空输入框
        })
      }
    })
  },
  
  detail: function (e) {
    wx.navigateTo({
      url: '../task/task?canOper=false&canApv=false&id=' + e.target.dataset.id
    })
  },
  good: function (e) {
    var that = this
    var curKeyGood = e.target.dataset.curkeygood
    if (curKeyGood) {
      return
    }
       var id = e.target.dataset.id
    wx: wx.request({
      url: app.globalData.myhost+'/Draghook/LookGood?id=' + id + "&key=" + app.globalData.openId,
      method: 'GET',
      success: function (res) {
        var good = res.data.status
        if (good!=0) {
           wx.request({
             url: app.globalData.myhost+'/Draghook/GoodNewOne',
            data: {
              "id": id,
              "type": 1,//进行点赞
              "key": app.globalData.openId,
              "name": app.globalData.userInfo.nickName,
              "icon": app.globalData.userInfo.avatarUrl
            },
            header: {
              "Content-Type": "application/x-www-form-urlencoded;charset=utf-8"
            },
            method: 'POST',
            success: function (res) {
              refreshDynamic(that, id)
            }
          })
        }else{

          wx.request({
            url: app.globalData.myhost+'/Draghook/GoodNewOne',
            data: {
              "id": id,
              "type": 2,//取消点赞
              "key": app.globalData.openId,
              "name": app.globalData.userInfo.nickName,
              "icon": app.globalData.userInfo.avatarUrl
            },
            header: {
              "Content-Type": "application/x-www-form-urlencoded"
            },
            method: 'POST',
            success: function (res) {
              refreshDynamic(that, id)
            }
          })
         
        }
      }
    })
  },
      
  //根据id撤销动态
  removedyn: function(e)
{
    var that = this
  var id = e.target.dataset.id
  console.log(id)
  wx: wx.request({
    url: app.globalData.myhost+'/Draghook/RemoveDyn?dynid=' + id,
      method: 'GET',
      success: function (res) {
       that.setData({

         dynamic:[]
       })
       

       that.onShow();
      }
  })
  },
  
  deletecomment: function (e) {
    var that = this;
    var key = e.currentTarget.dataset.key;//获取评论人id
    var commentid = e.currentTarget.dataset.commentid //评论的id
    var id = e.currentTarget.dataset.id;//拉钩活动的id
    if(key == app.globalData.openId)
    wx.showModal({
      title: '提示',
      content: '确定撤回此评论吗',
      success: function (res) {
        if (res.confirm) {
          
          
          wx: wx.request({
            url: app.globalData.myhost+'/Draghook/RemoveComment?dynid=' + id+'&commentid='+commentid,
            method: 'GET',
            success: function (res) {
                
                refreshDynamic(that,id)
            }
          })


        
        } else if (res.cancel) {
          console.log('点击取消了');
          return false;
        }
       
      }
    })
  },

  //向下刷新加载 最新的拉钩
  onPullDownRefresh: function () {
    var that = this
    var before
    var after
    wx.request({
      url: app.globalData.myhost+'/Draghook/latestDraghookDao?curKey=' + app.globalData.openId,
      method: 'GET',
      data:
      {
        "latitude": app.globalData.latitude,
        "longitude": app.globalData.longitude
      },
      success: function (res) {
        var oldData = that.data.dynamic
        var dyns = res.data.data
        before=oldData.length
         
        
        if (dyns != null && dyns.length > 0) {
          for (var i = dyns.length - 1; i >= 0; i--)
          {
            var IsSame=true
             for(var j=oldData.length-1;j>=0;j--)
             {
              
               if(dyns[i].id==oldData[j].id)
               {
                 IsSame=false;
               }

             }
             if(IsSame)
             {
               var date = new Date(dyns[i].vartime)
               dyns[i].limitTime = util.timeago(date.getTime())
               oldData.push(dyns[i])
             }
        }
        after=oldData.length

           {

          }
        }
        that.setData({
          dynamic: oldData,
        })
        wx.stopPullDownRefresh()
        setTimeout(function () {
          var freshResult = ""
          if (dyns != null && dyns.length > 0) {
            freshResult = "发现了" + (after-before) + "条内容"
          } else {
            freshResult = "已是最新"
          }
          that.setData({
            hiddenFreshResult: false,
            freshResult: freshResult
          })
          setTimeout(function () {
            that.setData({
              hiddenFreshResult: true
            })
          }, 2000)
        }, 1200)
      }
    })
  },
  bottomLoad: function () {
    getDynamic(this, false)
  }
})
// 初始化加载数据、上拉刷新
function getDynamic(that, first) {
  var limit = 0
  if (first) {
    limit = that.data.initLimit
  } else {
    limit = that.data.limit
  }
  

  // 显示加载中
  wx.showToast({
    title: '加载中',
    icon: 'loading',
    duration: 300
  });

  wx.request({
    url: app.globalData.myhost+"/Draghook/GetDraghooksByPage?offset=" + that.data.offset + '&limit=' + limit + "&curKey=" + app.globalData.openId,
    data:
    {
      "latitude": app.globalData.latitude,
      "longitude": app.globalData.longitude
    },
    method: 'GET',
    success: function (res) {
      var oldData = that.data.dynamic
      var dyns = res.data.data
      var offset=res.data.status
      if (dyns != null && dyns.length > 0) {
        for (var i = dyns.length-1; i>=0; i--) {
          var IsSame = true
          for (var j = oldData.length - 1; j >= 0; j--) {
            if (dyns[i].id == oldData[j].id) {
              IsSame = false;
            }

          }
          if (IsSame) {
            console.log(dyns[i]);
            var date = new Date(dyns[i].vartime)
            dyns[i].limitTime = util.timeago(date.getTime())
            oldData.push(dyns[i])
          }
        }
        if (offset == null) {
          offset = 0;
        }
        that.setData({
          offset: offset,
          dynamic: oldData
        })
      
      } else {
        that.setData({
          offset:0,
          bottomLoadMsg: "我可是有底线的"
        })
      }
     
 
      
    },
    //失败的话 把offset固定为0
    fail: function (res) {

      that.offset = 0

    }
  })
}
//评论完
//刷新拉钩
function refreshDynamic(that, id) {
  wx.request({
    url:app.globalData.myhost+'/Draghook/UpdateDrahook?id='+id,
    method: 'GET',
    success: function (res1) {
      // 找到dynamic列表中的值进行替换
      var offset=that.data.offset
      var dynamics = that.data.dynamic
      if (dynamics != null && dynamics.length > 0) {
        for (var i = dynamics.length - 1; i >= 0; i--){
          var dyn = dynamics[i]
          if (dyn.id == id) {
            if (res1.data.data.comments!=null)
            {
             dyn.comments = res1.data.data.comments
          }
    
            if (res1.data.data.goods!=null)
            {
             dyn.goods = res1.data.data.goods
             }
            var date = new Date(dyn.vartime)
            dyn.limitTime = util.timeago(date.getTime())
      
            console.log("刷新的id"+dyn.id)
            break
          }
        }
      }
      that.setData({
        dynamic: dynamics
      })
    },
    
    //失败的话 把offset固定为0
    fail: function (res) {
      
      that.offset=0

    }

  })
}

//查看是否有没相关提醒
function checkRelme(that) {
  wx: wx.request({
    url: app.globalData.myhost+'/Draghook/CommentAndGoodcount?curKey=' + app.globalData.openId,
    method: 'GET',
    success: function (res) {
      var has = res.data.status
      console.log("提醒标志位"+has)
      if (has==1) {
        that.setData({
          hiddenRelme: false
        })
      }
    }
  })
}


