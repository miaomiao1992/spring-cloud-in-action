// pages/me/me.js

var app = getApp()
var util = require('../../utils/util.js')
const iconList = require('../../data/local-data2')
var token
var headImg, token, nickName, userId, userName
var alreadyGoToLogin = false;
Page({
  data: {
    motto: '世界上唯一不变的，就是一切都在变',
    userInfo: {},
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '/pages/logs/logs'
    })
  },

  /** 跳转（政务资讯、办事指南、办事大厅、办事攻略）
  * 在../../data/local-data中设定
  * 
  */
  tapGridCell: function (event) {
    var that = this
    switch (event.currentTarget.dataset.iconId) {
      case 0:
        that.data.url = "../../packageA/pages/shenghuo/shenghuo"
        console.log("拉钩约友")
        break
      case 1:
        that.data.url = "../../packageA/pages/weather/weather"
        console.log("本地天气")
        break
      case 2:
        that.data.url = "../movies/movies"
        console.log("豆瓣电影")
        break
      case 3:
        that.data.url = "../../packageB/pages/myOrder/myOrder"
        console.log("我的订单")
        break
    }

    wx.navigateTo({
      url: that.data.url
    })
  },

  //点击登录 或 退出登录
  tapBtnLoginOrLoginOut: function (e) {
    var that=this
    let statusStr = e.currentTarget.dataset.loginStatus
    //'登录' : '退出登录'

    if (statusStr == "登录") {

      //在这里进行授权登录
    
        wx.login({

          success: function (res) {
            if (res.code) {
              wx.request({
                url: app.globalData.myhost+"/User/auth",
                data: {
                  code: res.code
                },
                method: "POST",
                header: {
                  'content-type': 'application/json',
                },
                success: function (res) {
                  

                   app.globalData.openId=res.data.openId
                   token = res.data.access_token;
                  
                  wx.getUserInfo({
                    success: res => {
                     
               
                      app.globalData.userInfo=res.userInfo
                       // 保存用户信息到服务端
                      wx.request({
                        url: app.globalData.myhost+"/User/updateConsumerInfo",
                        data: res.userInfo,
                        method: "POST",
                        header: {
                          'auth':'Bearer'+token,
                          'content-type': 'application/json',
                        },
                        success: function (res) {
                          
                           //不能在这里设置这个 不然会不断重复生成OpenId
                          //app.globalData.openId=token
                          that.setData({
                            userInfo: app.globalData.userInfo,
                            hasUserInfo: true
                          })
                         
          
                          //设置用户缓存
                          wx.setStorageSync('headImg', app.globalData.userInfo.avatarUrl)
                          wx.setStorageSync('nickname', app.globalData.userInfo.nickName)
                          wx.setStorageSync('city', app.globalData.userInfo.city)
                          wx.setStorageSync('userInfo', app.globalData.userInfo)
                       
                          //将获取的openId 缓存到本地
                          wx.setStorageSync('openId', app.globalData.openId)
                          console.log("生成的openId" + app.globalData.openId)
                         
                        },
                        fail: function (error) {
                          console.log(error);
                        }
                      })
                    }
                  })

                },
                fail: function (error) {
                  console.log(error);
                }
              })
            } else {
              console.log("error code " + res.errMsg);
            }
          }
        })
  

    } else if (statusStr == "退出登录") {
      //网络请求-退出登录
      this.requestLogout()
    }
  },
  //退出登录
  requestLogout: function () {
    var that = this;
  

   //在这里进行用户注销
    wx.request({
      url: app.globalData.myhost+'/User/ConsumerInfologout',
      method: "POST",
      header: {
        'auth': 'Bearer' + token,
        'content-type': 'application/json',
      },
      success: function (res) {

        wx.hideLoading()
        if (res.data.status == 1) {
          //退出登录成功
          wx.clearStorage()
          that.setData({ 
            userInfo: null,
             })
             app.globalData.userInfo=null;
             wx.clearStorageSync()
             app.globalData.openId=""
          
          wx.showToast({
            title: '成功',
            icon: 'succes',
            duration: 1000,
            mask: true
          })
        }
        else
        {
          wx.showToast({
            title: '错误',
            icon: '../../images/warn.png',
            duration: 1000,
            mask: true
          })

        }
       
        
        }
    })

  },

 onLoad:function()
 {
   /** 设置首页四图标 */
   console.log(iconList)
   this.setData(iconList)
    //从缓存中读取openId
   app.globalData.openId = wx.getStorageSync("openId")
    
   if (app.globalData.userInfo) {
     this.setData({
       userInfo: app.globalData.userInfo,
       hasUserInfo: true
     })
   } else if (this.data.canIUse) {
     // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
     // 所以此处加入 callback 以防止这种情况
     app.userInfoReadyCallback = res => {
       this.setData({
         userInfo: res.userInfo,
         hasUserInfo: true
       })
     }
   } else {
     // 在没有 open-type=getUserInfo 版本的兼容处理
     wx.getUserInfo({
       success: res => { // ES 6 解决 this 不同
         // 全局赋值
         app.globalData.userInfo = res.userInfo
         this.setData({
           userInfo: res.userInfo,
           hasUserInfo: true
         })
       }
     })
   }

 },
  


  onRefresh:function()
  {
    

  },
  
  onShow: function () {
    if (app.globalData.userInfo.nickName == null) {
      wx.showToast({
        title: '请先进行登录',
        icon: 'warn',
        duration: 1000,
        mask: true
      })
    }
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  }
})