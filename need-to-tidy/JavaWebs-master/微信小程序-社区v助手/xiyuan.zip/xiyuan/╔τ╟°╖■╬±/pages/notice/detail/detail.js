var WxParse = require('../../../wxParse/wxParse.js');
Page({
  
  onLoad: function (options) {

    var that = this;
    var url = options.url.replace("http://mini.eastday.com",app.globalData.myhost+"")
    wx.request({
      url: url,
      method: 'GET',
      success: function (res) {
       
        //去除<!DOCTYPE html>部分
        var article = res.data.replace("<!DOCTYPE html>","");
        //去掉标签
        var article1=article.replace(options.title,"",1)
        WxParse.wxParse('article', 'html', article1, that, 5);
      }
    })
  
  }
})