//index.js
//获取应用实例
var app = getApp()
const config = require('../../utils/config')
const iconList = require('../../data/local-data')
var util = require('../../utils/util.js')
var pageNo = 0;
Page({
  data: {
    topNews: [],
    newsType: 'topNews',
    url:""
  },

  /** 跳转（政务资讯、办事指南、办事大厅、办事攻略）
   * 在../../data/local-data中设定
   * 
   */
  tapGridCell: function (event) {
    var that=this
    switch (event.currentTarget.dataset.iconId) {
      case 0:
        that.data.url = "lists/list"
        console.log("点击社区公告")
        break
      case 1:
        that.data.url = "../../packageA/pages/suggestionbox/suggestionbox"
        console.log("点击社区意见箱")
        break
      case 2:
        that.data.url = "../../packageA/pages/documents/documents"
        console.log("点击社区文件")
        break
      case 3:
        that.data.url="news/news"
        console.log("点击更多资讯")
        break
    }

    wx.navigateTo({
      url: that.data.url
    })
  },

  onLoad: function () {
    console.log('onLoad')
    /** 设置首页四图标 */
    console.log(iconList)
    this.setData(iconList)
    var that = this
    // 访问聚合数据的网络接口-头条新闻
    wx.request({
      url: 'https://v.juhe.cn/toutiao/index',
      data: {
        type: 'topNews',
        key: 'f0d2d73226712e24aa475ffe2d012708'
      },
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        if (res.data.error_code == 0) {
          that.setData({
            topNews: res.data.result.data
          })
        } else {
          console.log('获取失败');
        }
      }
    })
  

  },


  //事件处理函数
  bindViewTap: function (event) {
    wx.navigateTo({
      url: 'detail/detail?title=' + event.currentTarget.dataset.title + '&url=' + event.currentTarget.dataset.url
    })
  },
  clickNation: function () {
    this.setData({
      newsType: 'guoji'
    })
    this.getNews();
  },
  clickSport: function () {
    this.setData({
      newsType: 'tiyu'
    })
    this.getNews();
  },
  clickScience: function () {
    this.setData({
      newsType: 'keji'
    })
    this.getNews();
  },
  clickScience: function () {
    this.setData({
      newsType: 'keji'
    })
    this.getNews();
  },
  clickHappy: function () {
    this.setData({
      newsType: 'yule'
    })
    this.getNews();
  },
  clickFinance: function () {
    this.setData({
      newsType: 'caijing'
    })
    this.getNews();
  },
  getNews: function () {
    var that = this
    // 访问聚合数据的网络接口-头条新闻
    wx.request({
      url: 'https://v.juhe.cn/toutiao/index',
      data: {
        type: this.data.newsType,
        key: 'a9f703a0200d68926f707f3f13629078'
      },
      header: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        console.log(res);
        if (res.data.error_code == 0) {
          that.setData({
            topNews: res.data.result.data
          })
        } else {
          console.log('获取失败');
        }
      }
    })
  },
})
