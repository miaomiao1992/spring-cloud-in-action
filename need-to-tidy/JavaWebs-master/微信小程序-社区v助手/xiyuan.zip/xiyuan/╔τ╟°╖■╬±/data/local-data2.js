let homeiconList_local = [
  {
    iconTitle: "拉钩约友",
    iconUrl: "/images/hook-click.png"
  },
  {
    iconTitle: "本地天气",
    iconUrl: "/images/weather/100.png",
  },
  {
    iconTitle: "豆瓣电影",
    iconUrl: "/images/movie.jpg",
  },
  {
    iconTitle: "预约订单",
    iconUrl: " /images/task-click.png"
  },
]



module.exports = {
  iconList: homeiconList_local,
}