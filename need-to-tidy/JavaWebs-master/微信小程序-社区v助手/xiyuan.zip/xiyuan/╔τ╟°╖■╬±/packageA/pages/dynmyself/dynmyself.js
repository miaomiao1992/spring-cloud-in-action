var app = getApp()
var util = require('../../utils/util.js')
Page({
  data: {
    windowHeight: 0,
    windowWidth: 0,
    pageNum: 1,
    pageSize: 10,
    firstLoadDataNum: 0,
    bottomLoadMsg: "点我加载",
    dynamic: [],
    hiddenComment: true,
    myOpenId: ""
  },
  onLoad: function () {
    var that = this
    var sysInfo = wx.getSystemInfoSync()
    that.setData({
      windowHeight: sysInfo.windowHeight,
      windowWidth: sysInfo.windowWidth,
      myOpenId: app.globalData.openId
    })
    getDynamic(that, true)
  },

  bottomLoad: function () {
    getDynamic(this, false)
  },

  //根据id撤销动态
  removedyn: function (e) {
    var that = this
    var id = e.target.dataset.id
    console.log(id)
    wx: wx.request({
      url: app.globalData.myhost+'/Draghook/RemoveDyn?dynid=' + id,
      method: 'GET',
      success: function (res) {
        that.setData({

          dynamic: []
        })


        that.onShow();
      }
    })
  },

  deletecomment: function (e) {
    var that = this;
    var key = e.currentTarget.dataset.key;//获取评论人id
    var commentid = e.currentTarget.dataset.commentid //评论的id
    var id = e.currentTarget.dataset.id;//拉钩活动的id
    if (key == app.globalData.openId)
      wx.showModal({
        title: '提示',
        content: '确定撤回此评论吗',
        success: function (res) {
          if (res.confirm) {


            wx: wx.request({
              url: app.globalData.myhost+'/Draghook/RemoveComment?dynid=' + id + '&commentid=' + commentid,
              method: 'GET',
              success: function (res) {

                refreshDynamic(that, id)
              }
            })



          } else if (res.cancel) {
            console.log('点击取消了');
            return false;
          }

        }
      })
  },

  //评论
  //function(e)是触发事件
  toComment: function (e) {

    this.setData({
      commentDynamicId: e.target.dataset.id,
      commentReplyKey: e.target.dataset.key == null ? "" : e.target.dataset.key,
      commentReplyName: e.target.dataset.name == null ? "" : e.target.dataset.name,
      commentPlaceholder: "",
      hiddenComment: false
    })
    if (e.target.dataset.key != null) {
      this.setData({
        commentInitInput: "",
        commentInput: ""
      })
    }
  },
  cancelComment: function () {
    this.setData({
      hiddenComment: true
    })
  },
  setCommentInput: function (e) {
    this.setData({
      commentInput: e.detail.value,
      commentInitInput: e.detail.value
    })
  },
  //提交评论
  submitComment: function () {
    var that = this
    if (that.data.commentInput.length == 0) {
      that.setData({
        commentPlaceholder: "评论不能为空"
      })
      return
    }

    wx.request({
      url: app.globalData.myhost+"/Draghook/CommentNewOne",
      data: {
        "id": that.data.commentDynamicId,
        "key": app.globalData.openId,
        "name": app.globalData.userInfo.nickName,
        "icon": app.globalData.userInfo.avatarUrl,
        "content": that.data.commentInput,
        "replyKey": that.data.commentReplyKey.length == 0 ? "" : that.data.commentReplyKey,
        "replyName": that.data.commentReplyName.length == 0 ? "" : that.data.commentReplyName
      },
      header: {
        "Content-Type": "application/x-www-form-urlencoded"
      },
      method: 'POST',
      success: function (res) {
    
        refreshDynamic(that, that.data.commentDynamicId)
        that.setData({
          hiddenComment: true,
          commentInput: "" 
        })
      }
    })
  },

  detail: function (e) {
    wx.navigateTo({
      url: '../../../pages/task/task?canOper=false&canApv=false&id=' + e.target.dataset.id
    })
  },
})


function getDynamic(that, first) {
  wx.request({
    url: app.globalData.myhost+"/Draghook/GetMyDraghooksByPage?curKey=" + app.globalData.openId + '&pageNum=' + that.data.pageNum + "&pageSize=" + that.data.pageSize,
    method: 'GET',
    success: function (res) {
      var oldData = that.data.dynamic
      var dyns = res.data.data
      var pageNum = that.data.pageNum
      if (dyns != null && dyns.length > 0) {
        pageNum++
        for (var i = 0; i < dyns.length; i++) {
          var dyn = dyns[i]
      
          var date = new Date(dyn.vartime)
          dyn.limitTime = util.timeago(date.getTime())
          oldData.push(dyn)
        }
      } else {
        that.setData({
          bottomLoadMsg: "我可是有底线的"
        })
      }
      that.setData({
        pageNum: pageNum,
        dynamic: oldData
      })
      if (first) {
        var firstLoadDataNum = 0
        if (dyns != null && dyns.length > 0) {
          firstLoadDataNum = dyns.length
        }
        that.setData({
          firstLoadDataNum: firstLoadDataNum
        })
      }
    }
  })
}
  //刷新拉钩
  function refreshDynamic(that, id) {
    wx.request({
      url: app.globalData.myhost+'/Draghook/UpdateDrahook?id=' + id + '&curKey=' + app.globalData.openId,
      method: 'GET',
      success: function (res1) {
        // 找到dynamic列表中的值进行替换
        var dynamics = that.data.dynamic
        if (dynamics != null && dynamics.length > 0) {
          for (var i = 0; i < dynamics.length; i++) {
            var dyn = dynamics[i]
            if (dyn.id == id) {
              if (res1.data.data.comments != null) {
                dyn.comments = res1.data.data.comments
              }

              if (res1.data.data.goods != null) {
                dyn.goods = res1.data.data.goods
              }

              console.log("刷新的id" + dyn.id)
              break
            }
          }
        }
        that.setData({
          dynamic: dynamics
        })
      },

    })
  }

