var Utils = require("../../utils/util.js");
var upload=require("../../../utils/upload.js")



var app =getApp()

const ctx = wx.createCanvasContext('myCanvas'); // 压缩图片

var datalist = {
  textareaFocus: true,                              // 文本域的自动调取键盘
  textareaVal: "",                                     // 文本域的val
  arrimg: [],           // 上传img的attr     => 页面显示的img                  
  len: 4,              // 上传的img的最大的length
  index: 0,         // 上传完成的个数
  successArr: [],      // 存储上传返回的img的url =>发送的数据
  questions: {},        // 提交数据存储到本地的josn
  bool: true,  // 是否通过上传的权限
  mun: 0,
  tempFilePath: "",
  "formMsgHidden": true,
  "openHelpHidden": true,
  open:false
}

Page({
  data: datalist,
  onLoad: function (options) {
 
  },

  submitFn: function () {   // 提交数据
   
    var _this = this;
    // 获取到  textarea的val
    var textareaVal = this.data.textareaVal;
    // 获取到上传成功返回的img的src the list
    var imgsList = this.data.successArr;
   
    var open =this.data.open
    console.log()

    if (textareaVal.trim() != "") {
      
      var now = new Date()
      var date = Utils.formatTime(now)
      var name
      var userIcon
      if ( open == true)
      {
       name="匿名用户";
       userIcon = '../../images/user.png';
      }else
      {
        name = app.globalData.userInfo.nickName;
        userIcon = app.globalData.userInfo.avatarUrl;
      }
      
      wx.request
        ({
          url: app.globalData.myhost+"/Notice/GreateNewNotice",
          method: "POST",
          header: {
            'content-type': 'application/json',
          },
          data: {
            name:name,
            userIcon:userIcon,
            date:date,
            content:textareaVal,
            images:imgsList

          },
          success: function (res) {
            var status = res.data.status;
            if(status==1)
            {
              wx.redirectTo({
                url: '../suggestionbox/suggestionbox'
              })
            }
            else
            {

              Utils.showModal("提交建议失败");
            }



          }
         
        })


       

      
    
    } else {
      Utils.showModal("问题不能空");
      return false
    }
  },
  openchange:function(e)
  {
  var open= e.detail.value
  
  this.setData(
    {
      open:open
    }
  )
  },
  showOpenHelp: function () {
    this.setData({
      openHelpHidden: false
    })
  },
  openHelpConfirm: function () {
    this.setData({
      openHelpHidden: true
    })
  },
  textareaFn: function (ev) {        // 输入动态获取textarea的value
    this.setData({
      textareaVal: ev.detail.value
    })
  },
  chooseimage: function (e) {
    this.chooseImageFn();   // 上传的fn
  },
  chooseImageFn: function () {   // 上传的fn
    var _this = this;
    var len = _this.data.len;   // 获取data的上传的总个数
    var mun = _this.data.index;  // 获取data的上传完成的个数
    var arr = _this.data.arrimg;         // 获取data的img的list 
    var suArr = _this.data.successArr; // 存储上传返回的img的src



    // 调取手机的上传
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {       // 成功
        console.log(res)
        var tempFilePaths = res.tempFilePaths[0].toString();
        len == mun ? mun = 4 : mun++;
        if (_this.data.index <= 3) {// 上传之前的验证个数
          arr.push(tempFilePaths);
          _this.setData({
            arrimg: arr,
            index: mun
          })
         
          upload(arr[arr.length - 1], 'vzhushou/upload/',
            function (result) {
              console.log("======上传成功图片地址为：", result);
              //做你具体的业务逻辑操作
              suArr.push(result);
              _this.setData({
                successArr: suArr
              })
              wx.hideLoading();
            }, function (result) {
              console.log("======上传失败======", result);
              //做你具体的业务逻辑操作

              wx.hideLoading()
            }
          )

      
       
         
            
       
        }
      }
    })
  },
  closeImgFn: function (e) {
    var doId = e.currentTarget.id;      // 对应的img的唯一id
    var doarrimg = this.data.arrimg;    // 页面显示的img the list    
    var doindex = this.data.index;   // 上传显示的个数
    var suArr = this.data.successArr;      // 发送的img的list的数组
    doarrimg.splice(doarrimg[doId], 1);     // 删除当前的下标的数组
    suArr.splice(suArr[doId], 1);
    doindex--;       // 删除一个上传的个数就递减
    this.setData({
      arrimg: doarrimg,
      index: doindex,
      successArr: suArr
    })
  },

});