/*
Navicat MySQL Data Transfer

Source Server         : 阿里云服务器
Source Server Version : 50642
Source Host           : 47.94.101.75:3306
Source Database       : comdb

Target Server Type    : MYSQL
Target Server Version : 50642
File Encoding         : 65001

Date: 2020-10-18 22:54:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for car_order
-- ----------------------------
DROP TABLE IF EXISTS `car_order`;
CREATE TABLE `car_order` (
  `id` varchar(255) NOT NULL,
  `end` varchar(255) DEFAULT NULL,
  `hours` int(11) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `park_id` int(11) DEFAULT NULL,
  `money` int(11) DEFAULT NULL,
  `plate_number` varchar(255) DEFAULT NULL,
  `start` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of car_order
-- ----------------------------
INSERT INTO `car_order` VALUES ('2BC3210584594C23928AFC39320A5ABE', '2019-05-20 13:03:14', '1', '1号停车场', '1', '1', '鄂UIDXIU', '2019-05-20 12:03:14', '1', '', '溪源');
INSERT INTO `car_order` VALUES ('3C050C1AD5074DB1BEE75E639F5A5835', '2019-05-29 12:35:18', '1', '风雨停车场', '2', '1', '甘OOCCZZ', '2019-05-29 11:35:18', '4', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源');
INSERT INTO `car_order` VALUES ('EB24524D3CCA4BAA8D265EF466086351', '2019-05-30 23:14:17', '1', '汉科停车场', '1', '1', '甘OOCCZZ', '2019-05-30 22:14:17', '4', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源');

-- ----------------------------
-- Table structure for car_park
-- ----------------------------
DROP TABLE IF EXISTS `car_park`;
CREATE TABLE `car_park` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `location` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `sparepark` int(11) DEFAULT NULL,
  `totalpark` int(11) DEFAULT NULL,
  `img_url` varchar(255) DEFAULT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of car_park
-- ----------------------------
INSERT INTO `car_park` VALUES ('1', '汉科学院内', '汉科停车场', '1', '10', '10', 'https://chengzong.top/img/hanke.jpg', '31.25774', '121.490787');
INSERT INTO `car_park` VALUES ('2', '风雨篮球场斜对面', '风雨停车场', '1', '50', '50', 'https://chengzong.top/img/fengyu.jpg', '30.335509', '112.215064');
INSERT INTO `car_park` VALUES ('3', '新风路', '新风停车场', '2', '50', '50', 'https://chengzong.top/img/xinfeng.jpg', '30.329694', '112.208884');

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `open_key` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `reply_key` varchar(255) DEFAULT NULL,
  `reply_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES ('68', '不错(*๓´╰╯`๓)♡', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '', '溪源', '', '');
INSERT INTO `comment` VALUES ('69', 'ss', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `comment` VALUES ('70', 'ww', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `comment` VALUES ('71', 'ss', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `comment` VALUES ('72', 'buc', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源');
INSERT INTO `comment` VALUES ('73', 'ss', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源');
INSERT INTO `comment` VALUES ('74', '不错', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `comment` VALUES ('75', 'OK', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '溪源');
INSERT INTO `comment` VALUES ('76', '哈哈', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '溪源');
INSERT INTO `comment` VALUES ('77', '一起来关注溪源吧', 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftXhzZjPDcwibhp98veAoPQQA/132', '', '漫步入海', '', '');

-- ----------------------------
-- Table structure for consumer
-- ----------------------------
DROP TABLE IF EXISTS `consumer`;
CREATE TABLE `consumer` (
  `open_id` varchar(255) NOT NULL,
  `avatar_url` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `created_at` bigint(20) DEFAULT NULL,
  `created_by` bigint(20) DEFAULT NULL,
  `deleted` bit(1) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `last_login_time` bigint(20) DEFAULT NULL,
  `nick_name` varchar(255) DEFAULT NULL,
  `phone` bigint(20) DEFAULT NULL,
  `updated_at` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `points` int(11) DEFAULT NULL,
  `gender_type_enum` int(11) DEFAULT NULL,
  PRIMARY KEY (`open_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of consumer
-- ----------------------------
INSERT INTO `consumer` VALUES ('oS4Vd5QL9_snb3iWyoYOe4-wJlxE', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLzLrP4iaQtyAGXtGf0uXBiava25EajX6icepVIlYuLPDjfojAO3Z2SEm3Kus7e9NXpXUrvHPjjIxpYA/132', '', null, null, null, null, '1', null, 'ratel', null, '1559311266007', '1', null, '100', null);
INSERT INTO `consumer` VALUES ('oS4Vd5U_VvTLBcqtHFjGmUadkXD8', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'Hefei', null, null, null, null, '1', null, '溪源', null, '1560849243367', '1', null, '100', null);
INSERT INTO `consumer` VALUES ('oS4Vd5VkVJ-E1L2oGnwmz82ViNJ8', 'https://wx.qlogo.cn/mmopen/vi_32/b1hSMkm6PMnQp2icibibVbsDb1E0wib4EpljM3VRBvKXFM8HKMOp5VW5vaxXBPUBXFd70S596ChIVMxv5lgbFaWeGA/132', 'Wuhan', null, null, null, null, '1', null, 'liuliang.info', null, '1559639340517', '1', null, '100', null);

-- ----------------------------
-- Table structure for document
-- ----------------------------
DROP TABLE IF EXISTS `document`;
CREATE TABLE `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img_url` varchar(255) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `PERSON_INDX_0` (`count`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of document
-- ----------------------------
INSERT INTO `document` VALUES ('1', 'https://image.chengzong.top/vzhushou/img/1.jpg', '13', 'https://image.chengzong.top/vzhushou/file/1.docx', '乡愁');
INSERT INTO `document` VALUES ('2', 'https://image.chengzong.top/vzhushou/img/2.jpg', '15', 'https://image.chengzong.top/vzhushou/file/2.docx', '新农村建设');
INSERT INTO `document` VALUES ('3', 'https://image.chengzong.top/vzhushou/img/3.jpg', '9', 'https://image.chengzong.top/vzhushou/file/3.docx', '城市的记忆');
INSERT INTO `document` VALUES ('4', 'https://image.chengzong.top/vzhushou/img/14.jpg', '13', 'https://image.chengzong.top/vzhushou/file/4.docx', '荆楚水乡');
INSERT INTO `document` VALUES ('5', 'https://image.chengzong.top/vzhushou/img/12.jpg', '10', 'https://image.chengzong.top/vzhushou/file/5.docx', '三国公园');
INSERT INTO `document` VALUES ('6', 'https://image.chengzong.top/vzhushou/img/8.jpg', '14', 'https://image.chengzong.top/vzhushou/file/5.docx', '荆州4');
INSERT INTO `document` VALUES ('7', 'https://image.chengzong.top/vzhushou/img/10.jpg', '5', 'https://image.chengzong.top/vzhushou/file/5.docx', '荆州3');
INSERT INTO `document` VALUES ('8', 'https://image.chengzong.top/vzhushou/img/9.jpg', '0', 'https://image.chengzong.top/vzhushou/file/5.docx', '荆州2');
INSERT INTO `document` VALUES ('9', 'https://image.chengzong.top/vzhushou/img/8.jpg', '1', 'https://image.chengzong.top/vzhushou/file/5.docx', '荆州1');
INSERT INTO `document` VALUES ('10', 'https://image.chengzong.top/vzhushou/img/13.jpg', '6', 'https://image.chengzong.top/vzhushou/file/5.docx', '长江大学3');
INSERT INTO `document` VALUES ('11', 'https://image.chengzong.top/vzhushou/img/6.jpg', '9', 'https://image.chengzong.top/vzhushou/file/5.docx', '长江大学2');
INSERT INTO `document` VALUES ('12', 'https://image.chengzong.top/vzhushou/img/7.jpg', '4', 'https://image.chengzong.top/vzhushou/5.docx', '长江大学1');

-- ----------------------------
-- Table structure for draghook
-- ----------------------------
DROP TABLE IF EXISTS `draghook`;
CREATE TABLE `draghook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `approval_pass_rate` varchar(255) DEFAULT NULL,
  `miaoshu` varchar(255) DEFAULT NULL,
  `end_date` varchar(255) DEFAULT NULL,
  `exc_rule` varchar(255) DEFAULT NULL,
  `biaoti` varchar(255) DEFAULT NULL,
  `open` varchar(255) DEFAULT NULL,
  `pass_rate` varchar(255) DEFAULT NULL,
  `start_date` varchar(255) DEFAULT NULL,
  `user_icon` varchar(255) DEFAULT NULL,
  `user_key` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  `create_time` date DEFAULT NULL,
  `string_create` varchar(255) DEFAULT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `vartime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `PERSON_INDX_0` (`create_time`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of draghook
-- ----------------------------
INSERT INTO `draghook` VALUES ('61', 'leastOne', '东校区', '2019-05-19 ', 'everyDay', '去跑步', 'true', '80', '2019-05-19 ', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '', '溪源', '2019-05-19', null, '30.337574', '112.203613', '2019/05/19 18:48:44 ');
INSERT INTO `draghook` VALUES ('62', 'leastOne', '1', '2019-06-17 ', 'everyDay', '1', null, '80', '2019-06-17 ', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '2019-06-17', null, '31.82057', '117.22901', '2019/06/17 11:12:02 ');
INSERT INTO `draghook` VALUES ('63', 'leastOne', '1', '2019-06-17 ', 'everyDay', '1', null, '80', '2019-06-17 ', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '2019-06-17', null, '31.82057', '117.22901', '2019/06/17 11:46:39 ');
INSERT INTO `draghook` VALUES ('64', 'leastOne', '2', '2019-06-17 ', 'everyDay', '2', null, '80', '2019-06-17 ', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '2019-06-17', null, '31.82057', '117.22901', '2019/06/17 16:11:56 ');
INSERT INTO `draghook` VALUES ('65', 'leastOne', 'z', '2019-06-17 ', 'everyDay', 'z', null, '80', '2019-06-17 ', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '2019-06-17', null, '31.82057', '117.22901', '2019/06/17 16:23:06 ');
INSERT INTO `draghook` VALUES ('66', 'leastOne', '1', '2019-06-18 ', 'everyDay', '1', null, '80', '2019-06-18 ', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '2019-06-18', null, '31.82057', '117.22901', '2019/06/18 13:54:53 ');
INSERT INTO `draghook` VALUES ('67', 'leastOne', '1', '2019-06-18 ', 'everyDay', '1', null, '80', '2019-06-18 ', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '2019-06-18', null, '31.82057', '117.22901', '2019/06/18 14:02:18 ');
INSERT INTO `draghook` VALUES ('68', 'leastOne', '1', '2019-06-18 ', 'everyDay', '1', null, '80', '2019-06-18 ', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '2019-06-18', null, '31.82057', '117.22901', '2019/06/18 13:58:25 ');
INSERT INTO `draghook` VALUES ('69', 'leastOne', '2', '2019-06-18 ', 'everyDay', '2', null, '80', '2019-06-18 ', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '2019-06-18', null, '31.82057', '117.22901', '2019/06/18 14:04:04 ');
INSERT INTO `draghook` VALUES ('70', 'leastOne', '333', '2019-06-18 ', 'everyDay', '33', null, '80', '2019-06-18 ', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '2019-06-18', null, '31.82057', '117.22901', '2019/06/18 14:04:38 ');
INSERT INTO `draghook` VALUES ('71', 'leastOne', '来呀', '2020-10-18 ', 'everyDay', '一起关注溪源吧', null, '80', '2020-10-18 ', 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftXhzZjPDcwibhp98veAoPQQA/132', '', '漫步入海', '2020-10-18', null, '31.23037', '121.4737', '2020-10-18 22:20:54');

-- ----------------------------
-- Table structure for draghook_exc_rule_value
-- ----------------------------
DROP TABLE IF EXISTS `draghook_exc_rule_value`;
CREATE TABLE `draghook_exc_rule_value` (
  `draghook_id` int(11) NOT NULL,
  `exc_rule_value` varchar(255) DEFAULT NULL,
  KEY `FKsm6iqjqcwnepw0dg11y355dbn` (`draghook_id`),
  CONSTRAINT `FKsm6iqjqcwnepw0dg11y355dbn` FOREIGN KEY (`draghook_id`) REFERENCES `draghook` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of draghook_exc_rule_value
-- ----------------------------

-- ----------------------------
-- Table structure for good
-- ----------------------------
DROP TABLE IF EXISTS `good`;
CREATE TABLE `good` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `good_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of good
-- ----------------------------
INSERT INTO `good` VALUES ('55', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('56', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('58', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '');
INSERT INTO `good` VALUES ('59', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '');
INSERT INTO `good` VALUES ('60', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('61', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('62', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('63', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('64', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('65', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('66', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('67', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('68', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('69', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('70', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('71', 'undefined', 'undefined', '');
INSERT INTO `good` VALUES ('72', 'undefined', 'undefined', '');
INSERT INTO `good` VALUES ('73', 'undefined', 'undefined', '');
INSERT INTO `good` VALUES ('74', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('75', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('76', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('77', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('78', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8');
INSERT INTO `good` VALUES ('79', 'ratel', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLzLrP4iaQtyAGXtGf0uXBiava25EajX6icepVIlYuLPDjfojAO3Z2SEm3Kus7e9NXpXUrvHPjjIxpYA/132', 'oS4Vd5QL9_snb3iWyoYOe4-wJlxE');
INSERT INTO `good` VALUES ('80', 'ratel', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLzLrP4iaQtyAGXtGf0uXBiava25EajX6icepVIlYuLPDjfojAO3Z2SEm3Kus7e9NXpXUrvHPjjIxpYA/132', 'oS4Vd5QL9_snb3iWyoYOe4-wJlxE');
INSERT INTO `good` VALUES ('81', 'ratel', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLzLrP4iaQtyAGXtGf0uXBiava25EajX6icepVIlYuLPDjfojAO3Z2SEm3Kus7e9NXpXUrvHPjjIxpYA/132', 'oS4Vd5QL9_snb3iWyoYOe4-wJlxE');
INSERT INTO `good` VALUES ('82', '漫步入海', 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftXhzZjPDcwibhp98veAoPQQA/132', '');
INSERT INTO `good` VALUES ('83', '漫步入海', 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftXhzZjPDcwibhp98veAoPQQA/132', '');
INSERT INTO `good` VALUES ('84', '漫步入海', 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftXhzZjPDcwibhp98veAoPQQA/132', '');

-- ----------------------------
-- Table structure for hibernate_sequence
-- ----------------------------
DROP TABLE IF EXISTS `hibernate_sequence`;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hibernate_sequence
-- ----------------------------
INSERT INTO `hibernate_sequence` VALUES ('2');

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `date` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_icon` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `solution` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES ('1', '我的主要意见是你为什么看了不关注一波', '2020-10-18 22:46:26', '漫步入海', 'https://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftXhzZjPDcwibhp98veAoPQQA/132', '0', null);
INSERT INTO `notice` VALUES ('13', '内有恶犬，请勿靠近。', '2019-05-21 22:38:58', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '1', '已通知有关部门');
INSERT INTO `notice` VALUES ('14', '7号楼的楼道灯坏了，请及时维修。', '2019-05-22 20:55:57', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '0', '');
INSERT INTO `notice` VALUES ('19', '1', '2019-05-29 11:34:04', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '2', '我们也没办法');
INSERT INTO `notice` VALUES ('20', '2', '2019-06-09 11:34:21', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '2', '');
INSERT INTO `notice` VALUES ('21', '3', '2019-06-09 11:36:22', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '0', null);
INSERT INTO `notice` VALUES ('22', '22', '2019-06-09 11:36:58', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '0', null);
INSERT INTO `notice` VALUES ('23', '3', '2019-06-09 11:37:21', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '0', null);
INSERT INTO `notice` VALUES ('24', '2', '2019-06-09 11:37:35', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '0', null);
INSERT INTO `notice` VALUES ('25', '1', '2019-06-09 12:16:55', '溪源', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '0', null);

-- ----------------------------
-- Table structure for notice_images
-- ----------------------------
DROP TABLE IF EXISTS `notice_images`;
CREATE TABLE `notice_images` (
  `notice_id` int(11) NOT NULL,
  `images` varchar(255) DEFAULT NULL,
  KEY `FK4o1qlkdf7xiqnknmyntq3h4ex` (`notice_id`),
  CONSTRAINT `FK4o1qlkdf7xiqnknmyntq3h4ex` FOREIGN KEY (`notice_id`) REFERENCES `notice` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice_images
-- ----------------------------
INSERT INTO `notice_images` VALUES ('13', 'https://www.chengzong.top/upload/190521023857-0.png');
INSERT INTO `notice_images` VALUES ('14', 'https://www.chengzong.top/upload/190522125557-0.png');
INSERT INTO `notice_images` VALUES ('19', 'https://www.chengzong.top/upload/190529033400-0.png');
INSERT INTO `notice_images` VALUES ('21', 'https://luocheng092248.oss-cn-hangzhou.aliyuncs.com/vzhushou/upload/156005137755456.png');
INSERT INTO `notice_images` VALUES ('22', 'https://luocheng092248.oss-cn-hangzhou.aliyuncs.com/vzhushou/upload/1560051399417106.png');
INSERT INTO `notice_images` VALUES ('25', 'https://image.chengzong.top/vzhushou/upload/156005381074467.png');

-- ----------------------------
-- Table structure for tb_comment
-- ----------------------------
DROP TABLE IF EXISTS `tb_comment`;
CREATE TABLE `tb_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `reply` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `reply_key` varchar(255) DEFAULT NULL,
  `reply_name` varchar(255) DEFAULT NULL,
  `commenter_id` varchar(255) DEFAULT NULL,
  `open_key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_comment
-- ----------------------------

-- ----------------------------
-- Table structure for tb_draghook_comment
-- ----------------------------
DROP TABLE IF EXISTS `tb_draghook_comment`;
CREATE TABLE `tb_draghook_comment` (
  `draghook_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  KEY `FKbtm9ffvtkglwtoa7evr9rh9h0` (`comment_id`),
  KEY `FK6rqpcbydglldsfx9qdu0m20m` (`draghook_id`),
  CONSTRAINT `FK6rqpcbydglldsfx9qdu0m20m` FOREIGN KEY (`draghook_id`) REFERENCES `draghook` (`id`),
  CONSTRAINT `FKbtm9ffvtkglwtoa7evr9rh9h0` FOREIGN KEY (`comment_id`) REFERENCES `comment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_draghook_comment
-- ----------------------------
INSERT INTO `tb_draghook_comment` VALUES ('61', '68');
INSERT INTO `tb_draghook_comment` VALUES ('61', '76');
INSERT INTO `tb_draghook_comment` VALUES ('71', '77');

-- ----------------------------
-- Table structure for tb_draghook_good
-- ----------------------------
DROP TABLE IF EXISTS `tb_draghook_good`;
CREATE TABLE `tb_draghook_good` (
  `draghook_id` int(11) NOT NULL,
  `good_id` int(11) NOT NULL,
  KEY `FKekui911y3kr1704ayv7y0qere` (`good_id`),
  KEY `FKc770b7oe22cxnvh641sukyf6s` (`draghook_id`),
  CONSTRAINT `FKc770b7oe22cxnvh641sukyf6s` FOREIGN KEY (`draghook_id`) REFERENCES `draghook` (`id`),
  CONSTRAINT `FKekui911y3kr1704ayv7y0qere` FOREIGN KEY (`good_id`) REFERENCES `good` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_draghook_good
-- ----------------------------
INSERT INTO `tb_draghook_good` VALUES ('61', '73');
INSERT INTO `tb_draghook_good` VALUES ('61', '81');
INSERT INTO `tb_draghook_good` VALUES ('62', '82');
INSERT INTO `tb_draghook_good` VALUES ('70', '83');
INSERT INTO `tb_draghook_good` VALUES ('71', '84');

-- ----------------------------
-- Table structure for tb_notice_comment
-- ----------------------------
DROP TABLE IF EXISTS `tb_notice_comment`;
CREATE TABLE `tb_notice_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `open_key` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `reply_key` varchar(255) DEFAULT NULL,
  `reply_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `PERSON_INDX_0` (`open_key`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_notice_comment
-- ----------------------------
INSERT INTO `tb_notice_comment` VALUES ('19', 'ss', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('20', 'qqq', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('21', '88', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('22', 'wwwww', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('23', 'qq', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源');
INSERT INTO `tb_notice_comment` VALUES ('24', 'sss', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'undefined', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('25', '可以', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('26', '在吗', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('27', '在吗', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('28', 'a', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('29', 'q', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('30', '是的', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('31', '不错', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('32', '不错不错', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('33', '赞同', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('34', '赞同', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '', '溪源', '', '');
INSERT INTO `tb_notice_comment` VALUES ('35', '我也赞同', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', '', '溪源', '', '溪源');

-- ----------------------------
-- Table structure for tb_noticegood
-- ----------------------------
DROP TABLE IF EXISTS `tb_noticegood`;
CREATE TABLE `tb_noticegood` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `icon` varchar(255) DEFAULT NULL,
  `good_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `PERSON_INDX_0` (`good_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_noticegood
-- ----------------------------
INSERT INTO `tb_noticegood` VALUES ('13', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源');
INSERT INTO `tb_noticegood` VALUES ('14', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源');
INSERT INTO `tb_noticegood` VALUES ('15', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源');
INSERT INTO `tb_noticegood` VALUES ('16', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源');
INSERT INTO `tb_noticegood` VALUES ('17', 'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTLSS606CNWoMGqiar3T0WDuia6iaHdCnj97rnUqQlqZ54RYibGRvLo78FftjJTzTibe6nIzicQtyud54YUQ/132', 'oS4Vd5U_VvTLBcqtHFjGmUadkXD8', '溪源');

-- ----------------------------
-- Table structure for tba_notice_good
-- ----------------------------
DROP TABLE IF EXISTS `tba_notice_good`;
CREATE TABLE `tba_notice_good` (
  `notice_id` int(11) NOT NULL,
  `good_id` int(11) NOT NULL,
  KEY `FK6qw4b1w0eygoam52ip1xqjo4o` (`good_id`),
  KEY `FKa0na4rgc3vb56pxc0xcqxbfqm` (`notice_id`),
  CONSTRAINT `FK6qw4b1w0eygoam52ip1xqjo4o` FOREIGN KEY (`good_id`) REFERENCES `tb_noticegood` (`id`),
  CONSTRAINT `FKa0na4rgc3vb56pxc0xcqxbfqm` FOREIGN KEY (`notice_id`) REFERENCES `notice` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tba_notice_good
-- ----------------------------
INSERT INTO `tba_notice_good` VALUES ('14', '16');
INSERT INTO `tba_notice_good` VALUES ('13', '17');

-- ----------------------------
-- Table structure for tbc_notice_comment
-- ----------------------------
DROP TABLE IF EXISTS `tbc_notice_comment`;
CREATE TABLE `tbc_notice_comment` (
  `notice_id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  KEY `FK6eqdnowfivo045x9m1emdru5b` (`comment_id`),
  KEY `FKgqvlc61s6va7bbgbdtodw9rmt` (`notice_id`),
  CONSTRAINT `FK6eqdnowfivo045x9m1emdru5b` FOREIGN KEY (`comment_id`) REFERENCES `tb_notice_comment` (`id`),
  CONSTRAINT `FKgqvlc61s6va7bbgbdtodw9rmt` FOREIGN KEY (`notice_id`) REFERENCES `notice` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tbc_notice_comment
-- ----------------------------
INSERT INTO `tbc_notice_comment` VALUES ('13', '34');
INSERT INTO `tbc_notice_comment` VALUES ('13', '35');
