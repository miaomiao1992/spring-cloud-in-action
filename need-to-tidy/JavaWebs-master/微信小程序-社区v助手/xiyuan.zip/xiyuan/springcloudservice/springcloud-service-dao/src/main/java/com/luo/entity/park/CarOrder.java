package com.luo.entity.park;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;
import java.io.Serializable;

@Entity
@Setter
@Getter
@ToString
public class CarOrder implements Serializable {

    private static final long serialVersionUID = 838601171031195733L;
    @Id
    private String id;//订单号

    private String userId;//用户openId

    private String username;//用户昵称

    @Column(name = "location")
    private String location;//停车场名称

    private Integer hours;//预约的时长

    @Column(name = "start")
    private String startDate;//开始时间
    @Column( name="end")
    private String endDate;//结束时间

    @Column(name = "money")
    private Integer parkPrice; //应收价格

    private String plateNumber;//车牌

    private Integer parkId;//停车场Id

    private Integer type;// 1.表示预约中 2.成功停车 3.已取车 4.过期失效 5.提示删除订单

    @Transient
    private String loadingtime;//用来进行倒计时

    public CarOrder() {
    }

}
