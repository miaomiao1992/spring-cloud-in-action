package com.luo.dao;


import com.luo.entity.park.CarOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.List;

@Component
@Transactional
public interface OrderDao extends JpaRepository<CarOrder,String> {

    @Query("from CarOrder o where o.userId =?1")
    List<CarOrder> getMoreByUserId(String userId);


    @Query("from CarOrder  o where o.id=?1")
    CarOrder getOneById(String id);

    @Query("from CarOrder o where o.plateNumber=?1 and o.type  in (1,2)" )
    List<CarOrder>findAllByPlateNumberAndType(String plateNumber);


    @Query("from CarOrder o where o.userId =?1  order by o.type " )
    List<CarOrder>findCarOrdersByUserIdtype(String openId);

    @Modifying
    @Query("delete from CarOrder o where o.id=?1")
    void removeOneById(String id);


}
