package com.luo.entity.notice;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;

@Entity(name = "tb_noticegood")
@Table(indexes = {@Index(name = "PERSON_INDX_0", columnList = "GoodId") })
@Setter
@Getter
@ToString
public class Good implements Serializable {

    private static final long serialVersionUID = -3487863588352195707L;
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "GoodId")
    private String key;//点赞人的openID
    private String name;//点赞人的昵称
    private String icon;//点赞人的头像

    public Good(String key, String name, String icon) {
        this.key = key;
        this.name = name;
        this.icon = icon;
    }

    public Good() {
    }

}
