package com.luo.entity.notice;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(indexes = {@Index(name = "PERSON_INDX_0", columnList = "count") })
@Setter
@Getter
@ToString
public class Document implements Serializable {


    private static final long serialVersionUID = 8284651131907753287L;
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer id;
    private String title;
    private String fileUrl;
    private String ImgUrl;
    private Integer count;

    public void addCount() {
        count++;
    }

}
