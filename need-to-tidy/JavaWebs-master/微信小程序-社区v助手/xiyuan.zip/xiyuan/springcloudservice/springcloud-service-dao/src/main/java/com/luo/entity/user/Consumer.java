package com.luo.entity.user;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.luo.enums.GenderTypeEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;

@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
@Setter
@Getter
@ToString
public class Consumer implements Serializable {

    private static final long serialVersionUID = -116423711777246476L;
    @Id
    private String openId;
    private String username;
    private Long phone;
    private String city;
    private String nickName;
    private String avatarUrl;
    private GenderTypeEnum genderTypeEnum;
    private String email;
    private Long lastLoginTime;
    private Boolean deleted;
    private Long createdBy;
    private Long createdAt;
    private Long updatedBy;
    private Long updatedAt;
    private Integer points=100;

}
