package com.luo.dao;


import com.luo.entity.user.Consumer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

@Component
public interface ConsumerDao extends JpaRepository<Consumer,String> {


    @Query("from Consumer c where c.openId = ?1")
    Consumer getByOpenId(String openid);
}
