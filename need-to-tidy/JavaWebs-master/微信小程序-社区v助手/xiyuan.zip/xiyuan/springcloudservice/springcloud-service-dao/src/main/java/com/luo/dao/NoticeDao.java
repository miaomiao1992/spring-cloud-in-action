package com.luo.dao;


import com.luo.entity.notice.Notice;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface NoticeDao extends JpaRepository<Notice,Integer> {

    //根据id获取公告
    @Query(" from Notice e where e.id=?1")
    Notice findByIdNOtice(Integer id);

    //分页查询
    @Query("from  Notice n order by n.id desc  ")
    List<Notice>findAllBy(Pageable pageable);


}
