package com.luo.entity.park;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Setter
@Getter
@ToString
public class Mark implements Serializable {
    private static final long serialVersionUID = -5722694928748601587L;
    private int id;
    private String iconPath = "/images/park.png";
    private double latitude;
    private double longitude;
    private Integer width = 40;
    private Integer height = 48;

    public Mark(int id, double latitude, double longitude) {
        this.id = id;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Mark(){

    }

}
