package com.luo.entity.notice;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Setter
@Getter
@ToString
public class Notice implements Serializable {

    private static final long serialVersionUID = 8252143691256883429L;

    @Id
    @GeneratedValue
    private int id;
    private String date;//创建建议的时间
    private String content;

    private String name;//存储用户nickname
    private String userIcon;//存储用户头像
    @Transient
    private String limitTime;
    @ElementCollection
    private List<String> images;

    private Integer status = 0;// 1表示已解决 0表示为解决  2表示官方拒绝

    private String solution;

    //如何利用JPA存储List 对象
    //利用中间表来进行表之间的对象的关联
    @ManyToMany(cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
    @JoinTable(name = "tbc_notice_comment", joinColumns = {@JoinColumn(name = "notice_id")}, inverseJoinColumns = {@JoinColumn(name = "comment_id")}
    )
    private List<Comment> Comments = new ArrayList<Comment>();//评论


    @ManyToMany(cascade = {CascadeType.ALL}, fetch = FetchType.EAGER)
    @Fetch(FetchMode.SELECT)
    @JoinTable(name = "tba_notice_good", joinColumns = {@JoinColumn(name = "notice_id")}, inverseJoinColumns = {@JoinColumn(name = "good_id")}
    )
    private List<Good> goods = new ArrayList<Good>();//点赞

    public Notice() {
    }

    //给意见task添加评论
    public void addComment(Comment comment) {
        if (Comments != null) {
            Comments.add(comment);
        }
    }

    //给意见task添加点赞
    public void addGood(Good good) {
        if (goods != null) {
            goods.add(good);
        }
    }


}
