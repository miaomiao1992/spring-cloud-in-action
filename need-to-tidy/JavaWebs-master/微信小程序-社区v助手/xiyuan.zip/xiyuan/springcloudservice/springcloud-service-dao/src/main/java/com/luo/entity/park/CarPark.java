package com.luo.entity.park;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Setter
@Getter
@ToString
public class CarPark implements Serializable {

    private static final long serialVersionUID = -1152873148281851633L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String name;//停车场名字
    private Integer price;//停车场价格
    private String location;//停车场位置
    private Integer totalpark;//总车位数
    private Integer sparepark;//剩余车位
    private String imgUrl;//图片
    private double latitude;//经度
    private double longitude;//维度
    @Transient
    private double dis;

    @Transient
    private String distance;
    public CarPark() {
    }

    public void parking() {
        sparepark--;
    }
    public void leave() {
        sparepark++;
    }

}
