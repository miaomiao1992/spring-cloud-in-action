package com.luo.entity.user;

import com.luo.enums.GenderTypeEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import java.io.Serializable;

@Setter
@Getter
@ToString
public class AccountDto implements Serializable {

    private static final long serialVersionUID = 8186020076130801358L;
    private Long id;
    private String username;
    private Long phone;
    private GenderTypeEnum gender;
    private String vcode;
    private String password;
    private String promotionCode;
    private String InvitationCode;
    private String clientAssertion;
    private String code;

}
