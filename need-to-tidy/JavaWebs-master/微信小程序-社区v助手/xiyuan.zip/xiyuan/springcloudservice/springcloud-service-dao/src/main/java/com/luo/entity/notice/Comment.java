package com.luo.entity.notice;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import javax.persistence.*;
import java.io.Serializable;

//用户评论
@Entity(name = "tb_noticeComment")
@JsonIgnoreProperties(ignoreUnknown = true)
@Table(indexes = {@Index(name = "PERSON_INDX_0", columnList = "openKey") })
@Setter
@Getter
@ToString
public class Comment implements Serializable {
    private static final long serialVersionUID = 7155772906354500695L;
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name ="openKey")
    private String key;//评论人的openId
    private String name;//评论人的昵称
    private String icon;//评论人的头像
    @Column(name = "replyName" )
    private String replyName;//被评论人的nickName
    private String replyKey;//被评论人的openId
    private String content;

    public Comment(String key, String name, String icon, String replyName, String replyKey, String content) {
        this.key = key;
        this.name = name;
        this.icon = icon;
        this.replyName = replyName;
        this.replyKey = replyKey;
        this.content = content;
    }

    public Comment() {
    }

}
