package com.luo.entity.draghook;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity(name = "Draghook")
@Table(indexes = {@Index(name = "PERSON_INDX_0", columnList = "createTime") })
@Setter
@Getter
@ToString
public class Draghook implements Serializable {

    private static final long serialVersionUID = -3802350527868868230L;
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private int id;
    @Column(name = "biaoti")
    private String name;//拉钩标题
    @Column(name="miaoshu")
    private String desc;//拉钩描述
    private String excRule;//执行频率
    @ElementCollection
    private List<String> excRuleValue;
    private String startDate;
    private String endDate;
    private String passRate;  //单次完成率
    private String approvalPassRate;  //目标完成率
    private String open;//是否公开
    private String userKey;//openId
    private String userName;
    private String userIcon;
    private Date createTime;
    private String vartime;
    private double latitude;//经度
    private double longitude;//维度

    @Transient
    private String distance;

    @Transient
    private String limitTime;
    //如何利用JPA存储List 对象
    //利用中间表来进行表之间的对象的关联
    @ManyToMany(cascade = { CascadeType.ALL},fetch = FetchType.EAGER)
    @JoinTable(name = "tb_draghook_comment" ,joinColumns = {@JoinColumn(name = "draghook_id")} ,inverseJoinColumns = {@JoinColumn(name = "comment_id")}
    )
    private List<Comment> Comments;//评论


    @ManyToMany(cascade = { CascadeType.ALL},fetch = FetchType.EAGER)
    @Fetch(FetchMode.SELECT)
    @JoinTable(name = "tb_draghook_good" ,joinColumns = {@JoinColumn(name = "draghook_id")} ,inverseJoinColumns = {@JoinColumn(name = "good_id")}
    )
    private List<Good>goods;//点赞

    //给拉钩task添加评论
    public void addComment(Comment comment)
    {
        Comments.add(comment);
    }

    //给拉钩task添加点赞
    public void addGood(Good good) {
        goods.add(good);
    }
}
