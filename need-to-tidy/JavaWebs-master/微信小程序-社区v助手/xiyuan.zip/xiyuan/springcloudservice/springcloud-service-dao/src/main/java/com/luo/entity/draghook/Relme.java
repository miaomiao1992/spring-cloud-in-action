package com.luo.entity.draghook;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;
import java.util.Set;

/*
* 存放在redis中 从而判定有没提醒
* */
@Setter
@Getter
@ToString
public class Relme implements Serializable {

    private static final long serialVersionUID = 9196696447904523177L;
    public String id; //Relme+openId

    public Set<Integer> synidlist;//任务的id

    public Integer flag=0; //标志位 1有未读消息 0无未读消息

    public Relme() {
    }

    public void addsyn(Integer id) {
        synidlist.add(id);
    }





}
