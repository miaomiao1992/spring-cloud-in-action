package com.luo.springcloudeurekaclientnotice.service;

import com.luo.entity.notice.Comment;
import com.luo.entity.notice.Good;
import com.luo.entity.notice.Notice;
import com.luo.model.ResponseResult;

public interface INoticeBiz {

    /**
     * 分页获取意见
     * @param offset
     * @return
     */
    ResponseResult getNoticeByPage(Integer offset);

    /**
     * 创建新的意见
     * @param notice
     * @return
     */
    ResponseResult greateNewNotice(Notice notice);

    /**
     * 根据id获取意见
     * @param id
     * @return
     */
    ResponseResult getNoticeById(Integer id);

    /**
     * 对意见进行评论
     * @param comment
     * @param id
     * @return
     */
    ResponseResult createComment(Comment comment, Integer id);

    /**
     * 查看是否被点赞
     * @param id
     * @param key
     * @return
     */
    ResponseResult lookIsGood(Integer id, String key);

    /**
     * 创建点赞
     * @param good
     * @param id
     * @return
     */
    ResponseResult goodNewOne(Good good, Integer id);

    /**
     * 回复意见
     * @param id
     * @param status
     * @param input
     * @return
     */
    ResponseResult manageNotice(Integer id, Integer status, String input);
}
