package com.luo.springcloudeurekaclientnotice.messages;


import com.luo.entity.notice.Notice;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.BusinessException;
import com.luo.model.ResponseResult;
import com.luo.utils.JacksonUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.AbstractJavaTypeMapper;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class NoticeMQProducer {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private Environment env;

    /**
     * 异步新建意见
     * @param notice
     * @return
     */
    public ResponseResult createNotice(Notice notice) {
        rabbitTemplate.setMessageConverter(new Jackson2JsonMessageConverter());
        rabbitTemplate.setExchange(env.getProperty("notice.exchange.name"));
        rabbitTemplate.setRoutingKey(env.getProperty("notice.routing.key.name"));
        try {
            Message message = MessageBuilder.withBody(JacksonUtils.toJson(notice).getBytes("UTF-8")).build();
            //设置请求编码格式
            message.getMessageProperties().setHeader(AbstractJavaTypeMapper.DEFAULT_CONTENT_CLASSID_FIELD_NAME, MessageProperties.CONTENT_TYPE_JSON);
            rabbitTemplate.convertAndSend(message);
            return ResponseResult.success();
        } catch (Exception e) {
            log.error("新建意见消息生产者发送消息失败" + e.getMessage(), e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "新建意见消息生产者发送消息失败:" + e.getMessage());
        }
    }
}
