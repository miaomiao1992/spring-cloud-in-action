package com.luo.springcloudeurekaclientnotice.controller;

import com.luo.annotation.ControllerMethodLog;
import com.luo.entity.notice.Comment;
import com.luo.entity.notice.Good;
import com.luo.entity.notice.Notice;
import com.luo.model.ResponseResult;
import com.luo.springcloudeurekaclientnotice.service.imp.NoticeBizImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@Slf4j
@Api(value = "意见箱-意见模块")
public class NoticeController {

    @Autowired
    NoticeBizImpl noticeBiz;

    //分页查询意见
    @GetMapping("/GetNoticeByPage")
    @ControllerMethodLog
    @ApiOperation(value = "分页查询意见")
    public ResponseResult getNoticeByPage(@RequestParam Integer offset)  {
        return  noticeBiz.getNoticeByPage(offset);

    }

    //创建新的意见
    @PostMapping("/GreateNewNotice")
    @ControllerMethodLog
    @ApiOperation(value = "创建新的意见")
    public ResponseResult greateNewNotice(@RequestBody Notice notice)  {
        return noticeBiz.greateNewNotice(notice);
    }

    //根据id获取建议
    @GetMapping("/GetNoticeById")
    @ControllerMethodLog
    @ApiOperation(value = "根据id获取建议")
    public ResponseResult getNoticeById(@RequestParam Integer id)  {
        return noticeBiz.getNoticeById(id);
    }

    //进行评论
    @PostMapping("/CommentNewOne")
    @ControllerMethodLog
    @ApiOperation(value = "进行评论")
    public ResponseResult createComment(
                                        @RequestParam Integer id,
                                        @RequestParam String key,
                                        @RequestParam String name,
                                        @RequestParam String icon,
                                        @RequestParam String content,
                                        @RequestParam String replyKey,
                                        @RequestParam String replyName
    ) {
        Comment comment = new Comment(key, name, icon, replyName, replyKey, content);
        return noticeBiz.createComment(comment,id);
    }


    //查看是否点赞过
    @GetMapping("/LookGood")
    @ControllerMethodLog
    @ApiOperation(value = "查看是否点赞过")
    public ResponseResult lookIsGood(@RequestParam Integer id, @RequestParam String key)  {
        return noticeBiz.lookIsGood(id,key);
    }


    //创建点赞
    @PostMapping("/GoodNewOne")
    @ControllerMethodLog
    @ApiOperation(value = "创建点赞")
    public ResponseResult goodNewOne(
                                        @RequestParam Integer id,
                                        @RequestParam String key,
                                        @RequestParam String name,
                                        @RequestParam String icon
    )  {
        Good good = new Good(key, name, icon);
        return noticeBiz.goodNewOne(good,id);
    }

    //撤回自己评论
    @GetMapping("/RemoveComment")
    @ControllerMethodLog
    @ApiOperation(value = "撤回自己评论")
    public ResponseResult removeComment(@RequestParam Integer noticeid, @RequestParam Integer commentid)  {
        return noticeBiz.removeComment(noticeid,commentid);
    }


    //回复意见
    @GetMapping("/ManageNotice")
    @ControllerMethodLog
    @ApiOperation(value = "回复意见")
    public ResponseResult manageNotice(
                             @RequestParam Integer id,
                             @RequestParam Integer status,
                             @RequestParam String input
    ) {
        return noticeBiz.manageNotice(id,status,input);
    }
}
