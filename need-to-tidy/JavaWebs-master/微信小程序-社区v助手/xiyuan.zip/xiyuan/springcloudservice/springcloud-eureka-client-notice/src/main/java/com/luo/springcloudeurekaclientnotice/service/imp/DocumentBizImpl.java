package com.luo.springcloudeurekaclientnotice.service.imp;

import com.luo.entity.notice.Document;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.BusinessException;
import com.luo.model.ResponseResult;
import com.luo.model.ServiceException;
import com.luo.services.notice.imp.DocumentServiceImpl;
import com.luo.springcloudeurekaclientnotice.service.IDocumentBiz;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class DocumentBizImpl implements IDocumentBiz {

    @Autowired
    private DocumentServiceImpl documentServiceImpl;

    /**
     * 分页获取文档
     *
     * @param page
     * @param size
     * @return
     */
    @Override
    public ResponseResult getNoticeByPage(Integer page, Integer size) {
        try {
            List<Document> list = documentServiceImpl.getDocumentByPage(page, size);
            ResponseResult resultMent = new ResponseResult();
            resultMent.setStatus(page + list.size());
            resultMent.setData(list);
            resultMent.setSuccess(true);
            return resultMent;
        } catch (ServiceException biz) {
            log.error("分页获取文档service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "分页获取文档service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("分页获取文档异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "分页获取文档异常" + e.getMessage());
        }
    }

    /**
     * 打开文档
     *
     * @param id
     * @return
     */
    @Override
    public ResponseResult getDocumentById(Integer id) {
        try {
            Document document = documentServiceImpl.getDocumentById(id);
            document.addCount();
            documentServiceImpl.saveDocument(document);
            ResponseResult resultMent = new ResponseResult();
            resultMent.setData(document);
            resultMent.setStatus(1);
            resultMent.setSuccess(true);
            return resultMent;
        } catch (ServiceException biz) {
            log.error("打开文档service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "打开文档service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("打开文档异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "打开文档异常" + e.getMessage());
        }
    }


    /**
     * 根据标题模糊查询文档
     *
     * @param title
     * @return
     */
    @Override
    public ResponseResult getDocumentBytitle(String title) {
        try {
            //这里使用Solr进行查询
            //List<Document> list = impSolrService.getProducts(title);

            //这里直接查询数据库
            List<Document> list =documentServiceImpl.getDocumentsByTitle(title);

            return ResponseResult.success(list, CouponTypeEnum.OPERATE_SUCCESS.getCouponTypeDesc());
        } catch (ServiceException biz) {
            log.error("根据标题模糊查询文档service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "根据标题模糊查询文档service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("根据标题模糊查询文档异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "根据标题模糊查询文档异常" + e.getMessage());
        }
    }
}
