package com.luo.springcloudeurekaclientnotice.service.imp;

import com.luo.entity.notice.Comment;
import com.luo.entity.notice.Good;
import com.luo.entity.notice.Notice;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.BusinessException;
import com.luo.model.ResponseResult;
import com.luo.model.ServiceException;
import com.luo.services.notice.imp.NoticeServiceImpl;
import com.luo.springcloudeurekaclientnotice.messages.NoticeMQProducer;
import com.luo.springcloudeurekaclientnotice.service.INoticeBiz;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class NoticeBizImpl implements INoticeBiz {

    @Autowired
    private NoticeServiceImpl noticeServiceImpl;

    @Autowired
    private NoticeMQProducer noticeMQProducer;

    /**
     * 分页获取意见
     *
     * @param offset
     * @return
     */
    @Override
    public ResponseResult getNoticeByPage(Integer offset) {
        try {
            List<Notice> list = noticeServiceImpl.listNoticeByPage(offset);
            ResponseResult resultMent = new ResponseResult();
            resultMent.setStatus(offset + list.size());
            resultMent.setData(list);
            resultMent.setSuccess(true);
            return resultMent;
        } catch (ServiceException biz) {
            log.error("分页获取意见service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "分页获取意见service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("分页获取意见异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "分页获取意见异常" + e.getMessage());
        }
    }

    /**
     * 创建新的意见(异步)
     *
     * @param notice
     * @return
     */
    @Override
    public ResponseResult greateNewNotice(Notice notice) {
        try {
            noticeMQProducer.createNotice(notice);
            return ResponseResult.isTrue();
        } catch (ServiceException biz) {
            log.error("创建新的意见service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "创建新的意见service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("创建新的意见异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "创建新的意见异常" + e.getMessage());
        }
    }

    /**
     * 根据id获取意见
     *
     * @param id
     * @return
     */
    @Override
    public ResponseResult getNoticeById(Integer id) {
        try {
            Notice notice = noticeServiceImpl.getNoticebyId(id);
            return ResponseResult.success(notice, CouponTypeEnum.OPERATE_SUCCESS.getCouponTypeDesc());
        } catch (ServiceException biz) {
            log.error("根据id获取意见service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "根据id获取意见service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("根据id获取意见异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "根据id获取意见异常" + e.getMessage());
        }
    }

    /**
     * 对意见进行评论
     *
     * @param comment
     * @param id
     * @return
     */
    @Override
    public ResponseResult createComment(Comment comment, Integer id) {
        try {
            Notice notice = noticeServiceImpl.getNoticebyId(id);
            notice.addComment(comment);
            //保持这次修改
            noticeServiceImpl.newNotice(notice);
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("对意见进行评论service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "对意见进行评论service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("对意见进行评论异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "对意见进行评论异常" + e.getMessage());
        }
    }

    /**
     * 查看是否被点赞
     *
     * @param id
     * @param key
     * @return
     */
    @Override
    public ResponseResult lookIsGood(Integer id, String key) {
        try {
            Notice notice = noticeServiceImpl.getNoticebyId(id);
            List<Good> list = notice.getGoods();
            for (Good good : list) {
                if (key.equals(good.getKey())) {
                    return ResponseResult.isFlase();
                }
            }
            return ResponseResult.isTrue();
        } catch (ServiceException biz) {
            log.error("查看是否被点赞service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看是否被点赞service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("查看是否被点赞异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看是否被点赞异常" + e.getMessage());
        }
    }

    /**
     * 创建点赞
     *
     * @param good
     * @param id
     * @return
     */
    @Override
    public ResponseResult goodNewOne(Good good, Integer id) {
        try {
            Notice notice = noticeServiceImpl.getNoticebyId(id);
            notice.addGood(good);
            //保持这次修改
            noticeServiceImpl.newNotice(notice);
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("创建点赞service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "创建点赞service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("创建点赞异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "创建点赞异常" + e.getMessage());
        }
    }

    /**
     * 撤回自己的评论
     *
     * @param noticeid
     * @param commentid
     * @return
     */
    public ResponseResult removeComment(Integer noticeid, Integer commentid) {
        try {
            Notice notice = noticeServiceImpl.getNoticebyId(noticeid);
            List<Comment> list = notice.getComments();
            if (list != null && list.size() != 0) {
                for (int i = list.size() - 1; i >= 0; i--) {
                    if (list.get(i).getId() == commentid) {
                        list.remove(list.get(i));
                    }
                }
            }
            notice.setComments(list);
            noticeServiceImpl.newNotice(notice);
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("撤回自己的评论service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "撤回自己的评论service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("撤回自己的评论异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "撤回自己的评论异常" + e.getMessage());
        }
    }

    /**
     * 回复意见
     *
     * @param id
     * @param status
     * @param input
     * @return
     */
    @Override
    public ResponseResult manageNotice(Integer id, Integer status, String input) {
        try {
            Notice notice = noticeServiceImpl.getNoticebyId(id);
            notice.setSolution(input);
            notice.setStatus(status);
            noticeServiceImpl.newNotice(notice);
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("回复意见service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "回复意见service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("回复意见异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "回复意见异常" + e.getMessage());
        }
    }
}
