package com.luo.springcloudeurekaclientnotice.messages;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.luo.entity.notice.Notice;
import com.luo.services.notice.imp.NoticeServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
@Slf4j
public class NoticeMQListener {

    @Autowired
    private NoticeServiceImpl noticeServiceImpl;

    private NoticeMQListener noticeMQListener;

    private static ObjectMapper objectMapper = new ObjectMapper();

    public NoticeMQListener(){

    }
    @PostConstruct
    public void init() {
        noticeMQListener = this;
        noticeMQListener.noticeServiceImpl = this.noticeServiceImpl;
    }

    /**
     * 以队列消息的方式 异步创建意见
     * 监听消费消息(新建拉钩活动)
     * @param message
     */
    @RabbitListener(queues = "${notice.queue.name}", containerFactory = "singleListenerContainer")
    public void consumeObjectQueue(@Payload byte[] message) {
        try {
            Notice notice = objectMapper.readValue(message, Notice.class);
            noticeServiceImpl.newNotice(notice);
            log.info("以队列消息的方式 异步创建意见： {} ", notice.toString());
        } catch (Exception e) {
            log.error("以队列消息的方式 异步创建意见异常{},{}",e.getStackTrace(), e);
        }
    }
}
