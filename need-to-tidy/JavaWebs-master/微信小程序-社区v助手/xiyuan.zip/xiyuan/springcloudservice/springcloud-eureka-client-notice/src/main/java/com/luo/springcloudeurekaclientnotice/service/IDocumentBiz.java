package com.luo.springcloudeurekaclientnotice.service;

import com.luo.model.ResponseResult;

public interface IDocumentBiz {

    /**
     * 分页获取文档
     * @param page
     * @param size
     * @return
     */
    ResponseResult getNoticeByPage(Integer page, Integer size);


    /**
     * 打开文档
     * @param id
     * @return
     */
    ResponseResult getDocumentById(Integer id);

    /**
     * 根据标题模糊查询文档
     * @param title
     * @return
     */
    ResponseResult getDocumentBytitle(String title);
}
