package com.luo.springcloudeurekaclientnotice.service;



import com.luo.entity.notice.Document;

import java.util.List;

public interface SolrService {
     List<Document> getProducts(String queryString) throws Exception;
}
