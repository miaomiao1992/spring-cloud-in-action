package com.luo.springcloudeurekaclientnotice.controller;

import com.luo.annotation.ControllerMethodLog;
import com.luo.model.ResponseResult;
import com.luo.springcloudeurekaclientnotice.service.imp.DocumentBizImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@Api(value = "意见箱-文档模块")
public class DocumentController {

    @Autowired
    DocumentBizImpl documentBiz;

    //分页获取文档
    @GetMapping("/GetDocumentByPage")
    @ControllerMethodLog
    @ApiOperation(value = "分页获取文档")
    public ResponseResult getNoticeByPage(@RequestParam Integer page, @RequestParam Integer size)  {
        return documentBiz.getNoticeByPage(page, size);
    }


    //根据Id获取文档
    //并且增加阅读数
    @GetMapping("/GetDocumentById")
    @ControllerMethodLog
    @ApiOperation(value = "根据Id获取文档")
    public ResponseResult getDocumentById(@RequestParam Integer id)  {
        return documentBiz.getDocumentById(id);
    }


    //根据标题 模糊查询获取文档
    @GetMapping("/GetDocumentBytitle")
    @ControllerMethodLog
    @ApiOperation(value = "根据标题模糊查询获取文档")
    public ResponseResult getDocumentBytitle(@RequestParam String title) throws Exception {
        return documentBiz.getDocumentBytitle(title);
    }


}
