package com.luo.model;

import com.luo.enums.CouponTypeEnum;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

/**
 * 〈响应实体类〉
 * 〈功能详细描述〉
 * 响应的封装类
 **/
@Setter
@Getter
@ToString
public class ResponseResult implements Serializable {
    private static final long serialVersionUID = 5229740359954021864L;

    private Boolean success = false; //响应的成功标识
    private Object data; //响应返回的Object
    private Object data2;//返回结果2
    private String errorCode;//错误编码
    private String errorMsg;//错误提示
    private int status;//用来表明是与否


    public ResponseResult() {

    }

    public ResponseResult(String errorCode, String errorMsg) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public ResponseResult(CouponTypeEnum couponTypeEnum) {
        this.errorCode = couponTypeEnum.getcouponTypeStr();
        this.errorMsg = couponTypeEnum.getCouponTypeDesc();
    }

    public static ResponseResult isTrue(){
        ResponseResult responseResult = new ResponseResult();
        responseResult.setSuccess(true);
        responseResult.setStatus(1);
        return responseResult;
    }

    public static ResponseResult isFlase(){
        ResponseResult responseResult = new ResponseResult();
        responseResult.setSuccess(true);
        responseResult.setStatus(0);
        return responseResult;
    }

    public static ResponseResult success() {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setSuccess(true);
        return responseResult;
    }

    public static ResponseResult success(String message) {
        ResponseResult responseResult = success();
        responseResult.setErrorMsg(message);
        return responseResult;
    }

    public static ResponseResult success(Object data, String message) {
        ResponseResult responseResult = success();
        responseResult.setData(data);
        responseResult.setErrorMsg(message);
        return responseResult;
    }

    public ResponseResult success(Object data, String message, String str) {
        ResponseResult responseResult = success();
        responseResult.setData(data);
        responseResult.setErrorMsg(message);
        return responseResult;
    }


    public static ResponseResult error() {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setSuccess(false);
        return responseResult;
    }

    public static ResponseResult error(String message) {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setSuccess(false);
        responseResult.setErrorMsg(message);
        return responseResult;
    }

    public static ResponseResult error(String message, String str) {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setSuccess(false);
        responseResult.setErrorMsg(message);
        return responseResult;
    }

    public static ResponseResult error(Object data, String message) {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setSuccess(false);
        responseResult.setErrorMsg(message);
        responseResult.setData(data);
        return responseResult;
    }

    public static ResponseResult error(CouponTypeEnum couponTypeEnum) {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setSuccess(false);
        responseResult.setErrorCode(couponTypeEnum.getcouponTypeStr());
        responseResult.setErrorMsg(couponTypeEnum.getCouponTypeDesc());
        return responseResult;
    }
}