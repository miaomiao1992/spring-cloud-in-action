package com.luo.model;

import com.luo.enums.CouponTypeEnum;
import lombok.Setter;

@Setter
public class ServiceException extends RuntimeException {
    private static final long serialVersionUID = -7239548466349436040L;

    private final CouponTypeEnum errorCode;

    public ServiceException(CouponTypeEnum errorCode, String message) {
        super(message);
        this.errorCode = errorCode;
    }

}
