package com.luo.model;


import org.springframework.stereotype.Component;

import java.io.Serializable;

//用这个类来管理返回结果
@Component
public class ResultMent implements Serializable {

    private static final long serialVersionUID = 34451926559491821L;
    private int status;
    private Object data;
    private Object data2;
    private String message="操作成功";

    public ResultMent() {}

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData2() {
        return data2;
    }

    public void setData2(Object data2) {
        this.data2 = data2;
    }

    public static ResultMent operate(Object o ){
        ResultMent resultMent =new ResultMent();
        resultMent.setData(o);
        return resultMent;
    }

    public static ResultMent operate(Object o,int status ){
        ResultMent resultMent =new ResultMent();
        resultMent.setData(o);
        resultMent.setStatus(status);
        return resultMent;
    }

    public static ResultMent operate(Object o,int status,String message){
        ResultMent resultMent =new ResultMent();
        resultMent.setData(o);
        resultMent.setStatus(status);
        resultMent.setMessage(message);
        return resultMent;
    }

    public static ResultMent operate(Object o,Object b,int status,String message){
        ResultMent resultMent =new ResultMent();
        resultMent.setData(o);
        resultMent.setData2(b);
        resultMent.setStatus(status);
        resultMent.setMessage(message);
        return resultMent;
    }







}
