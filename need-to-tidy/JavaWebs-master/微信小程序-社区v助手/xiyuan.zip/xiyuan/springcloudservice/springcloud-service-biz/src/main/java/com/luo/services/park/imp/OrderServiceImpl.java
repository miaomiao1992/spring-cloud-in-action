package com.luo.services.park.imp;

import com.luo.dao.OrderDao;
import com.luo.entity.park.CarOrder;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.ServiceException;
import com.luo.services.park.IOrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
@Slf4j
public class OrderServiceImpl implements IOrderService {

    @Autowired
    private OrderDao orderDao;

    /**
     * 保存订单
     * @param carOrder
     */
    @Override
    public void saveOrder(CarOrder carOrder) {
        try {
            orderDao.save(carOrder);
        } catch (Exception e) {
            log.error("保存订单异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "保存订单异常");
        }
    }

    /**
     * 获取自己的订单
     * @param userId
     * @return
     */
    @Override
    public List<CarOrder> getMyOrders(String userId) {
        try {
            return orderDao.findCarOrdersByUserIdtype(userId);
        } catch (Exception e) {
            log.error("获取自己的订单异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "获取自己的订单异常");
        }
    }

    /**
     * 根据订单号获取订单
     * @param id
     * @return
     */
    @Override
    public CarOrder getOrderById(String id) {
        try {
            return orderDao.getOneById(id);
        } catch (Exception e) {
            log.error("根据订单号获取订单异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "根据订单号获取订单异常");
        }
    }

    /**
     * 根据订单号删除订单
     * @param id
     */
    @Override
    public void removeOrderById(String id) {
        try {
            orderDao.removeOneById(id);
        } catch (Exception e) {
            log.error("根据订单号删除订单异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "根据订单号删除订单异常");
        }
    }

}
