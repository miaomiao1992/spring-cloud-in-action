package com.luo.services.user.imp;


import com.luo.dao.ConsumerDao;
import com.luo.entity.user.Consumer;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.ServiceException;
import com.luo.services.user.IConsumerService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ConsumerServiceImpl implements IConsumerService {


    @Autowired
    private ConsumerDao consumerDao;

    /**
     * 保存用户信息到数据库
     * @param consumer
     */
    @Override
    public void saveConsumer(Consumer consumer) {
        try {
            consumerDao.save(consumer);
        } catch (Exception e) {
            log.error("保存用户信息到数据库异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "保存用户信息到数据库异常");
        }
    }

    /**
     * 根据用户的openId获取用户信息
     * @param openId
     * @return
     */
    @Override
    public Consumer getConsumerById(String openId) {
        try {
            return consumerDao.getByOpenId(openId);
        } catch (Exception e) {
            log.error("根据用户的openId获取用户信息异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "根据用户的openId获取用户信息异常");
        }
    }
}
