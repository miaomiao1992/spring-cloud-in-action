package com.luo.services.notice.imp;


import com.luo.dao.DocumentDao;
import com.luo.entity.notice.Document;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.ServiceException;
import com.luo.services.notice.IDucumentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class DocumentServiceImpl implements IDucumentService {

   @Autowired
   private DocumentDao documentDao;


    /**
     * 分页获取文件
     * @param page
     * @param size
     * @return
     */
    @Override
   public List<Document> getDocumentByPage(Integer page, Integer size) {
        try {
            Pageable pageable =new PageRequest(page,size);
            return documentDao.getAllByPage(pageable);
        } catch (Exception e) {
            log.error("分页获取文件异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "分页获取文件异常");
        }
    }

    /**
     * 根据Id获取文档
     * @param id
     * @return
     */
    @Override
    public Document getDocumentById(Integer id) {
        try {
            return documentDao.getOneById(id);
        } catch (Exception e) {
            log.error("根据Id获取文档异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "根据Id获取文档异常");
        }
    }

    /**
     * 保存
     * @param document
     */
    @Override
    public void saveDocument(Document document) {
        try {
            documentDao.save(document);
        } catch (Exception e) {
            log.error("保存文档异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "保存文档异常");
        }
    }

    /**
     * 根据标题模糊查询
     * @param title
     * @return
     */
    @Override
    public List<Document> getDocumentsByTitle(String title) {
        try {
            return documentDao.getMoreBytitle(title);
        } catch (Exception e) {
            log.error("根据标题模糊查询异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "根据标题模糊查询异常");
        }
    }


}
