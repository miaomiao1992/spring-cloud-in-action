package com.luo.services.park.imp;


import com.luo.dao.CarParkDao;
import com.luo.dao.OrderDao;
import com.luo.entity.park.CarOrder;
import com.luo.entity.park.CarPark;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.ServiceException;
import com.luo.services.draghook.imp.DistanceServiceImpl;
import com.luo.services.park.ICarParkService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class CarParkServiceImpl implements ICarParkService {

    @Autowired
    private CarParkDao carParkDao;

    @Autowired
    private OrderDao orderDao;

    @Autowired
    private DistanceServiceImpl distanceServiceImpl;

    /**
     * 获取所有停车场
     * @param latitude
     * @param longitude
     * @return
     */
    @Override
    public List<CarPark> getAllCarPark(double latitude, double longitude) {
        try {
            List<CarPark> list = carParkDao.getAllBy(latitude, longitude);
            return distanceServiceImpl.carParksDistance(list, latitude, longitude);
        } catch (Exception e) {
            log.error("获取所有停车场异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "获取所有停车场异常");
        }
    }

    /**
     * 根据Id获取停车场详情
     * @param id
     * @return
     */
    @Override
    public CarPark getCarParkDetail(Integer id) {
        try {
            return carParkDao.getCarParkById(id);
        } catch (Exception e) {
            log.error("根据Id获取停车场详情异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "根据Id获取停车场详情异常");
        }
    }

    /**
     * 预约、停车
     * @param id
     */
    @Override
    public void parking(Integer id) {
        try {
            CarPark carPark = carParkDao.getCarParkById(id);
            carPark.parking();
            carParkDao.save(carPark);
        } catch (Exception e) {
            log.error("预约、停车异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "预约、停车异常");
        }
    }

    /**
     * 离开、取消
     * @param id
     */
    @Override
    public void leave(Integer id) {
        try {
            CarPark carPark = carParkDao.getCarParkById(id);
            carPark.leave();
            carParkDao.save(carPark);
        } catch (Exception e) {
            log.error("离开、取消异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "离开、取消异常");
        }
    }

    /**
     * 预约是查看是已预约
     * @param platNumber
     * @return
     */
    @Override
    public Boolean isPreOrder(String platNumber) {
        try {
            List<CarOrder> list = orderDao.findAllByPlateNumberAndType(platNumber);
            if (list != null && list.size() > 0)
                return true;
            return false;
        } catch (Exception e) {
            log.error("预约是查看是已预约异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "预约是查看是已预约异常");
        }
    }

}
