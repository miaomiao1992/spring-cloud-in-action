package com.luo.services.park;

import com.luo.entity.park.CarPark;

import java.util.List;

public interface ICarParkService {
    /**
     * 获取所有停车场
     * @param latitude
     * @param longitude
     * @return
     */
    List<CarPark> getAllCarPark(double latitude, double longitude);

    /**
     * 根据Id获取停车场详情
     * @param id
     * @return
     */
    CarPark getCarParkDetail(Integer id);

    /**
     * 预约、停车
     * @param id
     */
    void parking(Integer id);

    /**
     * 离开、取消
     * @param id
     */
    void leave(Integer id);

    /**
     * 预约是查看是已预约
     * @param platNumber
     * @return
     */
    Boolean isPreOrder(String platNumber);
}
