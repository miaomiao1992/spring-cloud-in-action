package com.luo.services.notice.imp;


import com.luo.dao.NoticeDao;
import com.luo.entity.notice.Notice;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.ServiceException;
import com.luo.services.notice.INoticeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class NoticeServiceImpl implements INoticeService {

    @Autowired
    private NoticeDao noticeDao;

    /**
     * 分页查询意见
     * @param offset
     * @return
     */
    @Override
    public List<Notice> listNoticeByPage(Integer offset) {
        try {
            Pageable pageable = new PageRequest(offset / 10, 10);
            return noticeDao.findAllBy(pageable);
        } catch (Exception e) {
            log.error("分页查询意见异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "分页查询意见异常");
        }
    }

    /**
     * 创建新的意见
     * @param notice
     */
    @Override
    public void newNotice(Notice notice) {
        try {
            noticeDao.save(notice);
        } catch (Exception e) {
            log.error("创建新的意见异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "创建新的意见异常");
        }
    }

    /**
     * 根据id获取意见
     * @param id
     * @return
     */
    @Override
    public Notice getNoticebyId(Integer id) {
        try {
            return noticeDao.findByIdNOtice(id);
        } catch (Exception e) {
            log.error("根据id获取意见异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "根据id获取意见异常");
        }
    }
}
