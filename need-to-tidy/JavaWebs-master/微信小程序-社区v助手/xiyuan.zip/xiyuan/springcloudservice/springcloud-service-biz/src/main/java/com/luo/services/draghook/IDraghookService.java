package com.luo.services.draghook;

import com.luo.entity.draghook.Draghook;

import java.util.List;
import java.util.Set;

public interface IDraghookService {
    /**
     * 保存一次拉钩活动
     * @param draghook
     */
    void saveNewDraghook(Draghook draghook);

    /**
     * 分页查询所有附近拉钩活动
     * @param offset
     * @param limit
     * @param latitude
     * @param longitude
     * @return
     */
    List<Draghook> getDraghooksbyPage(Integer offset, Integer limit, double latitude, double longitude);

    /**
     * 分页查询单一用户的拉钩活动
     * @param pageNum
     * @param pageSize
     * @param openId
     * @return
     */
    List<Draghook> getMyDraghooksbyPage(Integer pageNum, Integer pageSize, String openId);

    /**
     * 根据id获取拉钩活动
     * @param id
     * @return
     */
    Draghook getDraghookbyIdAndOpenId(Integer id);

    /**
     * 周围的拉钩活动
     * @param openId
     * @param latitude
     * @param longitude
     * @return
     */
    List<Draghook> getLastestDraghooks(String openId, double latitude, double longitude);

    /**
     * 根据id获取拉手任务
     * @param id
     * @return
     */
    Draghook getDraghooksById(Integer id);

    /**
     * 通过id集合获取task
     * @param set
     * @return
     */
    List<Draghook> getDraghooksByIds(Set<Integer> set);

    /**
     * 根据ID删除拉钩任务
     * @param id
     */
    void removebydynId(Integer id);
}
