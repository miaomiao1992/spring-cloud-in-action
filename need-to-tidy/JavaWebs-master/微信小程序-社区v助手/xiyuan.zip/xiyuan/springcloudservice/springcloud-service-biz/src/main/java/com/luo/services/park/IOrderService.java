package com.luo.services.park;

import com.luo.entity.park.CarOrder;
import java.util.List;

public interface IOrderService {

    /**
     * 保存订单
     * @param carOrder
     */
    void saveOrder(CarOrder carOrder);

    /**
     * 获取自己的订单
     * @param userId
     * @return
     */
    List<CarOrder> getMyOrders(String userId);

    /**
     * 根据订单号获取订单
     * @param id
     * @return
     */
    CarOrder getOrderById(String id);

    /**
     * 根据订单号删除订单
     * @param id
     */
    void removeOrderById(String id);


}
