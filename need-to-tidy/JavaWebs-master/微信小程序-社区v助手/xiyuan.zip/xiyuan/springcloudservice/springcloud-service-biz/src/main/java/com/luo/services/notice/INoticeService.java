package com.luo.services.notice;

import com.luo.entity.notice.Notice;

import java.util.List;

public interface INoticeService {

    /**
     * 分页查询意见
     * @param offset
     * @return
     */
    List<Notice> listNoticeByPage(Integer offset);

    /**
     * 创建新的意见
     * @param notice
     */
    void newNotice(Notice notice);

    /**
     * 根据id获取意见
     * @param id
     * @return
     */
    Notice getNoticebyId(Integer id);
}
