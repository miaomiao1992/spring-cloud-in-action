package com.luo.services.user;

import com.luo.entity.user.Consumer;

public interface IConsumerService {

    /**
     * 保存用户信息到数据库
     * @param consumer
     */
    void saveConsumer(Consumer consumer);

    /**
     * 根据用户的openId获取用户信息
     * @param openId
     * @return
     */
    Consumer getConsumerById(String openId);
}
