package com.luo.services.draghook.imp;

import com.luo.dao.DraghookDao;
import com.luo.entity.draghook.Draghook;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.ServiceException;
import com.luo.services.draghook.IDraghookService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
@Slf4j
public class DraghookServiceImpl implements IDraghookService {

    @Autowired
    private DraghookDao draghookDao;

    @Autowired
    private DistanceServiceImpl distanceServiceImpl;

    /**
     * 保存一次拉钩活动
     * @param draghook
     */
    @Override
    public void saveNewDraghook(Draghook draghook) {
        try {
            draghookDao.save(draghook);
        } catch (Exception e) {
            log.error("保存一次拉钩活动异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "保存一次拉钩活动异常");
        }
    }

    /**
     * 分页查询所有附近拉钩活动
     * @param offset
     * @param limit
     * @param latitude
     * @param longitude
     * @return
     */
    @Override
    public List<Draghook> getDraghooksbyPage(Integer offset, Integer limit, double latitude, double longitude) {
        try {
            Pageable pageable = new PageRequest(offset / limit, limit);
            List<Draghook> list = draghookDao.getDraghooksByPage(pageable);
            return distanceServiceImpl.draghooksDistance(list, latitude, longitude);
        } catch (Exception e) {
            log.error("分页查询所有附近拉钩活动异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "分页查询所有附近拉钩活动异常");
        }
    }

    /**
     * 分页查询单一用户的拉钩活动
     * @param pageNum
     * @param pageSize
     * @param openId
     * @return
     */
    @Override
    public List<Draghook> getMyDraghooksbyPage(Integer pageNum, Integer pageSize, String openId) {
        try {
            //分页查询PageNum从0开始
            Pageable pageable = new PageRequest(pageNum - 1, pageSize);
            return draghookDao.getDraghooksByOpenId(openId, pageable);
        } catch (Exception e) {
            log.error("分页查询单一用户的拉钩活动异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "分页查询单一用户的拉钩活动异常");
        }
    }

    /**
     * 根据id获取拉钩活动
     * @param id
     * @return
     */
    @Override
    public Draghook getDraghookbyIdAndOpenId(Integer id) {
        try {
            return draghookDao.getDraghooksByIdAnduserKey(id);
        } catch (Exception e) {
            log.error("根据id获取拉钩活动动异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "根据id获取拉钩活动异常");
        }
    }

    /**
     * 周围的拉钩活动
     * @param openId
     * @param latitude
     * @param longitude
     * @return
     */
    @Override
    public List<Draghook> getLastestDraghooks(String openId, double latitude, double longitude) {
        try {
            Pageable pageable = new PageRequest(0, 10);
            List<Draghook> list = draghookDao.getLastDrahooks(openId, pageable);
            return distanceServiceImpl.draghooksDistance(list, latitude, longitude);
        } catch (Exception e) {
            log.error("获取周围的拉钩活动异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "获取周围的拉钩活动异常");
        }
    }

    /**
     * 根据id获取拉手任务
     * @param id
     * @return
     */
    @Override
    public Draghook getDraghooksById(Integer id) {
        try {
            return draghookDao.getDraghooksById(id);
        } catch (Exception e) {
            log.error("根据id获取拉手任务异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "根据id获取拉手任务异常");
        }
    }

    /**
     * 通过id集合获取task
     * @param set
     * @return
     */
    @Override
    public List<Draghook> getDraghooksByIds(Set<Integer> set) {
        try {
            return draghookDao.getDraghooksByIds(set);
        } catch (Exception e) {
            log.error("通过id集合获取task异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "通过id集合获取task异常");
        }
    }

    /**
     * 根据ID删除拉钩任务
     * @param id
     */
    @Override
    public void removebydynId(Integer id) {
        try {
            draghookDao.deleteById(id);
        } catch (Exception e) {
            log.error("根据ID删除拉钩任务异常，异常信息:", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "根据ID删除拉钩任务异常");
        }
    }


}
