package com.luo.services.draghook.imp;

import com.luo.entity.draghook.Draghook;
import com.luo.entity.park.CarPark;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.ServiceException;
import com.luo.services.draghook.IDistanceService;
import com.luo.utils.DistanceUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.util.List;

@Service
@Slf4j
public class DistanceServiceImpl implements IDistanceService {

    /**
     * 计算拉钩活动的距离（批量）
     * @param list
     * @param latitude
     * @param longitude
     * @return
     */
    @Override
    public List<Draghook> draghooksDistance(List<Draghook> list, double latitude, double longitude) {
        try {
            DecimalFormat df = new DecimalFormat("0.0");
            DecimalFormat df1 = new DecimalFormat("0");
            double dis = 0;
            if (list != null) {
                for (Draghook draghook : list) {
                    dis = DistanceUtils.getDistance(latitude, longitude, draghook.getLatitude(), draghook.getLongitude());
                    if (dis / 1000 < 100 && dis > 1000) {
                        draghook.setDistance(df.format(dis / 1000) + "km");
                    } else if (dis < 1000) {
                        draghook.setDistance(df1.format(dis) + "m");
                    } else {
                        draghook.setDistance("在远方");
                    }
                }
            }
            return list;
        } catch (Exception e) {
            log.error("计算拉钩活动的距离批量异常，异常信息", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "计算拉钩活动的距离（批量）异常");
        }
    }

    /**
     * 计算拉钩活动的距离
     * @param draghook
     * @param latitude
     * @param longitude
     * @return
     */
    @Override
    public Draghook draghookDistance(Draghook draghook, double latitude, double longitude) {
        try {
            DecimalFormat df = new DecimalFormat("0.0");
            double dis = 0;
            dis = DistanceUtils.getDistance(latitude, longitude, draghook.getLatitude(), draghook.getLongitude());
            if (dis / 1000 < 100) {
                draghook.setDistance(df.format(dis / 1000) + "km");
            } else {
                draghook.setDistance("在远方");
            }
            return draghook;
        } catch (Exception e) {
            log.error("计算拉钩活动的距离异常，异常信息", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "计算拉钩活动的距离异常");
        }
    }

    /**
     * 计算停车活动的距离(批量)
     * @param list
     * @param latitude
     * @param longitude
     * @return
     */
    @Override
    public List<CarPark> carParksDistance(List<CarPark> list, double latitude, double longitude) {
        try {
            DecimalFormat df = new DecimalFormat("0.0");
            DecimalFormat df1 = new DecimalFormat("0");
            double dis = 0;
            if (list != null) {
                for (int i = list.size() - 1; i >= 0; i--) {
                    dis = DistanceUtils.getDistance(latitude, longitude, list.get(i).getLatitude(), list.get(i).getLongitude());
                    if (dis > 1000 && dis < 5000) {
                        list.get(i).setDistance(df.format(dis / 1000) + "km");
                    } else if (dis < 1000) {
                        list.get(i).setDistance(df1.format(dis) + "m");
                    } else {
                        list.remove(list.get(i));
                    }

                }
            }
            return list;
        } catch (Exception e) {
            log.error("计算停车活动的距离(批量)异常，异常信息", e);
            throw new ServiceException(CouponTypeEnum.OPERATE_ERROR, "计算停车活动的距离(批量)");
        }
    }
}
