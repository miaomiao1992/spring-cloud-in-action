package com.luo.services.draghook;

import com.luo.entity.draghook.Draghook;
import com.luo.entity.park.CarPark;

import java.util.List;

public interface IDistanceService {

    /**
     * 计算拉钩活动的距离（批量）
     * @param list
     * @param latitude
     * @param longitude
     * @return
     */
    List<Draghook> draghooksDistance(List<Draghook> list, double latitude, double longitude);


    /**
     * 计算拉钩活动的距离
     * @param draghook
     * @param latitude
     * @param longitude
     * @return
     */
    Draghook draghookDistance(Draghook draghook, double latitude, double longitude);

    /**
     * 计算停车活动的距离(批量)
     * @param list
     * @param latitude
     * @param longitude
     * @return
     */
    List<CarPark> carParksDistance(List<CarPark> list, double latitude, double longitude);
}
