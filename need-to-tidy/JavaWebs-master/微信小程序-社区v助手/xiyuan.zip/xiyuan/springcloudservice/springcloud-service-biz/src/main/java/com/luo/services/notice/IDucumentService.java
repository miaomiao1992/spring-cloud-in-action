package com.luo.services.notice;

import com.luo.entity.notice.Document;

import java.util.List;

public interface IDucumentService {

    /**
     * 分页获取文件
     * @param page
     * @param size
     * @return
     */
    List<Document> getDocumentByPage(Integer page, Integer size);

    /**
     * 根据Id 获取
     * @param id
     * @return
     */
    Document getDocumentById(Integer id);

    /**
     * 保存
     * @param document
     */
    void saveDocument(Document document);

    /**
     * 根据标题模糊查询
     * @param title
     * @return
     */
    List<Document> getDocumentsByTitle(String title);

}
