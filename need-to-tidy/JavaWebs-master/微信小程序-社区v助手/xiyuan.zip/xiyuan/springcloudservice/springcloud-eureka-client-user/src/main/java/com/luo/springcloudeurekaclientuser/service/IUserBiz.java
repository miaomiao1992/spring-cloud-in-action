package com.luo.springcloudeurekaclientuser.service;

import com.luo.entity.user.Consumer;
import com.luo.model.ResponseResult;
import com.luo.springcloudeurekaclientuser.tools.springsecurity.WechatAuthenticationResponse;

import javax.servlet.http.HttpServletRequest;

public interface IUserBiz {
    /**
     * 获取登录凭证
     * @param code
     * @return
     */
    WechatAuthenticationResponse wechatLogin(String code);

    /**
     * 将微信提供的用户信息入库
     * @param consumer
     * @return
     */
    ResponseResult updateConsumerInfo(Consumer consumer);

    /**
     * 用户注销
     * @param request
     * @return
     */
    ResponseResult consumerInfologout(HttpServletRequest request);
}
