package com.luo.springcloudeurekaclientuser.service.imp;

import com.luo.entity.user.Consumer;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.BusinessException;
import com.luo.model.ResponseResult;
import com.luo.model.ServiceException;
import com.luo.springcloudeurekaclientuser.service.IUserBiz;
import com.luo.springcloudeurekaclientuser.tools.springsecurity.WechatAuthenticationResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

@Slf4j
@Service
public class UserBizImpl implements IUserBiz {

    @Autowired
    private WechatService wechatService;

    /**
     * 获取登录凭证
     *
     * @param code
     * @return
     */
    @Override
    public WechatAuthenticationResponse wechatLogin(String code) {
        try {
            return wechatService.wechatLogin(code);
        } catch (ServiceException biz) {
            log.error("获取登录凭证service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "获取登录凭证service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("获取登录凭证异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "获取登录凭证异常" + e.getMessage());
        }
    }

    /**
     * 将微信提供的用户信息入库
     *
     * @param consumer
     * @return
     */
    @Override
    public ResponseResult updateConsumerInfo(Consumer consumer) {
        try {
            wechatService.updateConsumerInfo(consumer);
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("将微信提供的用户信息入库service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "将微信提供的用户信息入库service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("将微信提供的用户信息入库异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "将微信提供的用户信息入库异常" + e.getMessage());
        }
    }

    /**
     * 用户注销
     *
     * @param request
     * @return
     */
    @Override
    public ResponseResult consumerInfologout(HttpServletRequest request) {
        try {
            //获取请求头中的数据 进行删除vxSession
            wechatService.cleanConsumerInfo(request);
            return ResponseResult.isTrue();
        } catch (ServiceException biz) {
            log.error("用户注销service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "用户注销service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("用户注销异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "用户注销异常" + e.getMessage());
        }
    }
}
