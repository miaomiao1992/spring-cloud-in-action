package com.luo.springcloudeurekaclientuser.controller;

import com.luo.annotation.ControllerMethodLog;
import com.luo.entity.user.AccountDto;
import com.luo.entity.user.Consumer;
import com.luo.model.ResponseResult;
import com.luo.springcloudeurekaclientuser.service.imp.UserBizImpl;
import com.luo.springcloudeurekaclientuser.tools.springsecurity.WechatAuthenticationResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.AuthenticationException;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;

@RestController
@Slf4j
@Api(value = "用户模板")
public class UserController {

    @Autowired
    private UserBizImpl userBiz;

    //通过request.code 生产sessionID 获取登录凭证
    @PostMapping("/auth")
    @ControllerMethodLog
    @ApiOperation(value = "获取登录凭证")
    public ResponseEntity<WechatAuthenticationResponse> createAuthenticationToken(@RequestBody AccountDto accountDto)
            throws AuthenticationException {
        WechatAuthenticationResponse jwtResponse = userBiz.wechatLogin(accountDto.getCode());
        return ResponseEntity.ok(jwtResponse);
    }


    //将微信提供的用户信息入库
    @PostMapping("/updateConsumerInfo")
    @ControllerMethodLog
    @ApiOperation(value = "用户信息入库")
    public ResponseResult updateConsumerInfo( @RequestBody Consumer consumer)  {
        return userBiz.updateConsumerInfo(consumer);
    }


    //在这里进行用户注销操作
    //根据openID清空redis内容
    @PostMapping("/ConsumerInfologout")
    @ControllerMethodLog
    @ApiOperation(value = "用户注销")
    public ResponseResult consumerInfologout(HttpServletRequest request){
        return  userBiz.consumerInfologout(request);
    }
}
