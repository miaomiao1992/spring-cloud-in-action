package com.luo.springcloudeurekaclientuser.messages;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.luo.entity.user.Consumer;
import com.luo.services.user.imp.ConsumerServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
@Slf4j
public class ConsumerMQListener {

    @Autowired
    private ConsumerServiceImpl consumerServiceImpl;

    private ConsumerMQListener consumerMQListener;

    private static ObjectMapper objectMapper = new ObjectMapper();

    public ConsumerMQListener(){

    }
    @PostConstruct
    public void init() {
        consumerMQListener = this;
        consumerMQListener.consumerServiceImpl = this.consumerServiceImpl;
    }

    /**
     * 以队列消息的方式 将用户信息入库
     * 监听消费消息(新建拉钩活动)
     * @param message
     */
    @RabbitListener(queues = "${consumer.queue.name}", containerFactory = "singleListenerContainer")
    public void consumeObjectQueue(@Payload byte[] message) {
        try {
            Consumer consumer = objectMapper.readValue(message, Consumer.class);
            consumerServiceImpl.saveConsumer(consumer);
            log.info("以队列消息的方式 异步将用户信息入库： {} ", consumer.toString());
        } catch (Exception e) {
            log.error("以队列消息的方式 异步将用户信息入库异常{},{}",e.getStackTrace(), e);
        }
    }
}
