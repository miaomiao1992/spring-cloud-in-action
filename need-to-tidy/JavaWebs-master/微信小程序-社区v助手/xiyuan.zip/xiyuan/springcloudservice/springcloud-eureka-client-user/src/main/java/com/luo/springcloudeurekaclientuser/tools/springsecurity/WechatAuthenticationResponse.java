package com.luo.springcloudeurekaclientuser.tools.springsecurity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;


/*
* 用这个类 返回access_token
*
* */
@Setter
@Getter
@ToString
public class WechatAuthenticationResponse implements Serializable {

    private static final long serialVersionUID = 1250166508152483573L;

    @JsonProperty("access_token")
    private final String accessToken;

    private  String openId;

    public WechatAuthenticationResponse(String accessToken) {
        this.accessToken = accessToken;
    }



}
