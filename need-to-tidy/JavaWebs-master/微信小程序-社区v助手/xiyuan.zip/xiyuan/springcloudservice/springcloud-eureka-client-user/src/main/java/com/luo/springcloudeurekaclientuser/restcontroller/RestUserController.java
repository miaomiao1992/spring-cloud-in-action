package com.luo.springcloudeurekaclientuser.restcontroller;


import com.luo.entity.user.Consumer;
import com.luo.services.user.imp.ConsumerServiceImpl;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
public class RestUserController {


    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private ConsumerServiceImpl consumerServiceImpl;


    //减去用户信用值
    @GetMapping("/Reduce/{id}")
    public void reduce(@PathVariable String id) {

        Consumer consumer = consumerServiceImpl.getConsumerById(id);
        consumer.setPoints(consumer.getPoints() - 5);
        consumerServiceImpl.saveConsumer(consumer);

    }

    //获取用户信用值
    @GetMapping("/GetUser/{id}")
    @HystrixCommand(fallbackMethod = "fallbackInfo")
    public String getUser(@PathVariable String id) {
        return consumerServiceImpl.getConsumerById(id).getPoints().toString();
    }
    //降级方法
    public String fallbackInfo(@PathVariable String id) {
        return "101";
    }


}
