package com.luo.springcloudeurekaclientdraghook.controller;

import com.luo.annotation.ControllerMethodLog;
import com.luo.entity.draghook.Draghook;
import com.luo.model.ResponseResult;
import com.luo.springcloudeurekaclientdraghook.service.imp.DraghookBizImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@Slf4j
@Api(value = "拉钩-活动模板")
public class DraghookController {


    @Autowired
    DraghookBizImpl draghookBiz;


    //创建新的拉钩task
    @PostMapping("/CreateNewDraghook")
    @ControllerMethodLog
    @ApiOperation(value = "创建新的拉钩")
    public ResponseResult createDraghook(@RequestBody Draghook draghook)  {
        return draghookBiz.createDraghook(draghook);
    }


    //查看附近的拉钩活动
    @GetMapping("/GetDraghooksByPage")
    @ControllerMethodLog
    @ApiOperation(value = "查看附近的拉钩活动")
    public ResponseResult getDraghooksByPage(
                                   @RequestParam Integer offset,
                                   @RequestParam Integer limit,
                                   @RequestParam double latitude,
                                   @RequestParam double longitude
    )  {
        return draghookBiz.getDraghooksByPage(offset, limit, latitude, longitude);
    }


    //查看被@自己的拉钩
    @GetMapping("/GetAboutMyDraghooks")
    @ControllerMethodLog
    @ApiOperation(value = "查看被@自己的拉钩")
    public ResponseResult getAboutMyDraghooks(@RequestParam String curKey)  {
        return draghookBiz.getAboutMyDraghooks(curKey);
    }


    //查看自己发布的拉钩
    @GetMapping("/GetMyDraghooksByPage")
    @ControllerMethodLog
    @ApiOperation(value = "查看自己发布的拉钩")
    public ResponseResult getMyDraghooksByPage(
                                     @RequestParam Integer pageNum,
                                     @RequestParam Integer pageSize,
                                     @RequestParam String curKey
    )  {
        return draghookBiz.getMyDraghooksByPage(pageNum, pageSize, curKey);
    }


    //刷新单个task
    @GetMapping("/UpdateDrahook")
    @ControllerMethodLog
    @ApiOperation(value = "刷新单个task")
    public ResponseResult getDraghookbyIdAndOpenId(@RequestParam Integer id)  {
        return draghookBiz.getDraghookbyIdAndOpenId(id);
    }

    //获得当前最近的拉钩
    @GetMapping("/latestDraghookDao")
    @ControllerMethodLog
    @ApiOperation(value = "获得当前最近的拉钩")
    public ResponseResult getlatestDraghookbyOpenId(
                                          @RequestParam String curKey,
                                          @RequestParam double latitude,
                                          @RequestParam double longitude
    ) {
        return draghookBiz.getlatestDraghookbyOpenId(curKey, latitude, longitude);
    }

    //获取task详情
    @GetMapping("/GetDraghookDaoDetail")
    @ControllerMethodLog
    @ApiOperation(value = "获取task详情")
    public ResponseResult getDraghookDaoDetail(@RequestParam Integer id)  {
        return draghookBiz.getDraghookDaoDetail(id);
    }

    //删除自己的task
    @GetMapping("/RemoveDyn")
    @ControllerMethodLog
    @ApiOperation(value = "删除task")
    public ResponseResult removeDyn(@RequestParam Integer dynid) {
        return draghookBiz.removeDyn(dynid);
    }
}