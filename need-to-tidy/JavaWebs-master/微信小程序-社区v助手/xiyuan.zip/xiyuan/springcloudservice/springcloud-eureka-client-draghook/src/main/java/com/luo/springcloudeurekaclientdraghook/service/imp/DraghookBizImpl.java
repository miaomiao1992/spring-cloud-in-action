package com.luo.springcloudeurekaclientdraghook.service.imp;

import com.luo.entity.draghook.Draghook;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.BusinessException;
import com.luo.model.ResponseResult;
import com.luo.model.ServiceException;
import com.luo.services.draghook.imp.DraghookServiceImpl;
import com.luo.springcloudeurekaclientdraghook.messages.DraghookMQProducer;
import com.luo.springcloudeurekaclientdraghook.service.IDraghookBiz;
import com.luo.utils.DateUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@Service
@Slf4j
public class DraghookBizImpl implements IDraghookBiz {

    @Autowired
    private DraghookServiceImpl draghookServiceImpl;

    @Autowired
    private RelmeService relmeService;

    @Autowired
    private DraghookMQProducer draghookMQProducer;

    /**
     * 创建拉钩活动
     *
     * @param draghook
     */
    @Override
    public ResponseResult createDraghook(Draghook draghook) {
        //对时间格式进行设置
        draghook.setVartime(DateUtils.getDateTimeStamp(draghook.getCreateTime()));
        try {
            draghookMQProducer.createDraghook(draghook);
            return ResponseResult.isTrue();
        } catch (ServiceException biz) {
            log.error("新建拉钩service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "新建拉钩service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("新建拉钩异常{}", draghook, e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "新建拉钩异常" + e.getMessage());
        }
    }

    /**
     * 查看附近的拉钩活动
     *
     * @param offset
     * @param limit
     * @param latitude
     * @param longitude
     * @return
     */
    @Override
    public ResponseResult getDraghooksByPage(Integer offset, Integer limit, double latitude, double longitude) {
        try {
            List<Draghook> list = draghookServiceImpl.getDraghooksbyPage(offset, limit, latitude, longitude);
            ResponseResult resultMent = new ResponseResult();
            resultMent.setStatus(offset + list.size());
            resultMent.setData(list);
            resultMent.setSuccess(true);
            return resultMent;
        } catch (ServiceException biz) {
            log.error("查看附近的拉钩活动service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看附近的拉钩活动service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("查看附近的拉钩活动异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看附近的拉钩活动" + e.getMessage());
        }
    }

    /**
     * 查看被@自己的拉钩活动
     *
     * @param curKey
     * @return
     */
    @Override
    public ResponseResult getAboutMyDraghooks(String curKey) {
        try {
            Set<Integer> set = relmeService.getDraghookSet(curKey);
            List<Draghook> list = draghookServiceImpl.getDraghooksByIds(set);
            return ResponseResult.success(list, CouponTypeEnum.OPERATE_SUCCESS.getCouponTypeDesc());
        } catch (ServiceException biz) {
            log.error("查看被@自己的拉钩活动service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看被@自己的拉钩活动service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("查看被@自己的拉钩活动异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看被@自己的拉钩异常" + e.getMessage());
        }
    }

    /**
     * 查看自己发布的拉钩
     *
     * @param pageNum
     * @param pageSize
     * @param curKey
     * @return
     */
    @Override
    public ResponseResult getMyDraghooksByPage(Integer pageNum, Integer pageSize, String curKey) {
        try {
            List<Draghook> list = draghookServiceImpl.getMyDraghooksbyPage(pageNum, pageSize, curKey);
            return ResponseResult.success(list, CouponTypeEnum.OPERATE_SUCCESS.getCouponTypeDesc());
        } catch (ServiceException biz) {
            log.error("查看自己发布的拉钩service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看自己发布的拉钩service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("查看自己发布的拉钩异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看自己发布的拉钩活动异常" + e.getMessage());
        }
    }


    /**
     * 刷新单个task
     *
     * @param id
     * @return
     */
    @Override
    public ResponseResult getDraghookbyIdAndOpenId(Integer id) {
        try {
            Draghook draghook = draghookServiceImpl.getDraghookbyIdAndOpenId(id);
            return ResponseResult.success(draghook, CouponTypeEnum.OPERATE_SUCCESS.getCouponTypeDesc());
        } catch (ServiceException biz) {
            log.error("刷新拉钩service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "刷新拉钩service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("刷新拉钩异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "刷新拉钩异常" + e.getMessage());
        }
    }


    /**
     * 获得当前时间最近的拉钩
     *
     * @param curKey
     * @param latitude
     * @param longitude
     * @return
     */
    @Override
    public ResponseResult getlatestDraghookbyOpenId(String curKey, double latitude, double longitude) {
        try {
            List<Draghook> list = draghookServiceImpl.getLastestDraghooks(curKey, latitude, longitude);
            return ResponseResult.success(list, CouponTypeEnum.OPERATE_SUCCESS.getCouponTypeDesc());
        } catch (ServiceException biz) {
            log.error("获得当前时间最近的拉钩service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "获得当前时间最近的拉钩service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("获得当前时间最近的拉钩异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "获得当前时间最近的拉钩异常" + e.getMessage());
        }
    }

    /**
     * 获取task详情
     *
     * @param id
     * @return
     */
    @Override
    public ResponseResult getDraghookDaoDetail(Integer id) {
        try {
            Draghook draghook = draghookServiceImpl.getDraghooksById(id);
            return ResponseResult.success(draghook, CouponTypeEnum.OPERATE_SUCCESS.getCouponTypeDesc());
        } catch (ServiceException biz) {
            log.error("获取task详情service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "获取task详情service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("获取task详情异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "获取task详情异常" + e.getMessage());
        }
    }

    /**
     * 删除自己的task
     *
     * @param dynid
     * @return
     */
    @Override
    public ResponseResult removeDyn(Integer dynid) {
        try {
            draghookServiceImpl.removebydynId(dynid);
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("删除自己的task service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "删除自己的task service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("删除自己的task异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "删除自己的task异常" + e.getMessage());
        }
    }
}
