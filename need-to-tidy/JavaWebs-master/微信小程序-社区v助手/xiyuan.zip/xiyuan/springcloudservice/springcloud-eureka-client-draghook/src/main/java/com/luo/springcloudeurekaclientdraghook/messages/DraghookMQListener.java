package com.luo.springcloudeurekaclientdraghook.messages;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.luo.entity.draghook.Draghook;
import com.luo.services.draghook.imp.DraghookServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
@Slf4j
public class DraghookMQListener {

    @Autowired
    private DraghookServiceImpl draghookServiceImpl;

    private DraghookMQListener draghookMQListener;

    private static ObjectMapper objectMapper = new ObjectMapper();

    public DraghookMQListener(){

    }
    @PostConstruct
    public void init() {
        draghookMQListener = this;
        draghookMQListener.draghookServiceImpl = this.draghookServiceImpl;
    }

    /**
     * 以队列消息的方式 异步创建拉钩活动
     * 监听消费消息(新建拉钩活动)
     * @param message
     */
    @RabbitListener(queues = "${draghook.queue.name}", containerFactory = "singleListenerContainer")
    public void consumeObjectQueue(@Payload byte[] message) {
        try {
            Draghook draghook = objectMapper.readValue(message, Draghook.class);
            draghookServiceImpl.saveNewDraghook(draghook);
            log.info("以队列消息的方式 异步创建拉钩活动： {} ", draghook.toString());
        } catch (Exception e) {
            log.error("以队列消息的方式 异步创建拉钩活动异常{},{}",e.getStackTrace(), e);
        }
    }
}
