package com.luo.springcloudeurekaclientdraghook.service.imp;

import com.luo.entity.draghook.Comment;
import com.luo.entity.draghook.Draghook;
import com.luo.entity.draghook.Good;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.BusinessException;
import com.luo.model.ResponseResult;
import com.luo.model.ServiceException;
import com.luo.services.draghook.imp.DraghookServiceImpl;
import com.luo.springcloudeurekaclientdraghook.messages.DraghookMQListener;
import com.luo.springcloudeurekaclientdraghook.service.ICommentAndGoodBiz;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class CommentAndGoodBizImpl implements ICommentAndGoodBiz {

    @Autowired
    private DraghookServiceImpl draghookServiceImpl;

    @Autowired
    private RelmeService relmeService;

    @Autowired
    private DraghookMQListener draghookMQListener;

    /**
     * 统计是否有与我有关的新消息
     *
     * @param curKey
     * @return
     */
    @Override
    public ResponseResult commentAndGoodcount(String curKey) {
        try {
            return relmeService.lookRelme(curKey) ? ResponseResult.isTrue()
                    : ResponseResult.isFlase();
        } catch (ServiceException biz) {
            log.error("统计是否有与我有关的新消息service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "统计是否有与我有关的新消息service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("统计是否有与我有关的新消息异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "统计是否有与我有关的新消息异常" + e.getMessage());
        }
    }

    /**
     * 取消提醒
     *
     * @param curKey
     */
    @Override
    public ResponseResult removeRelme(String curKey) {
        try {
            relmeService.readedRelme(curKey);
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("取消提醒异常(标记已读)service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "取消提醒异常(标记已读)service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.info("取消提醒异常(标记已读)", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "取消提醒异常" + e.getMessage());
        }
    }


    /**
     * 创建评论
     *
     * @param comment
     * @param id
     */
    @Override
    public ResponseResult createCommentr(Comment comment, Integer id) {
        try {
            Draghook draghook = draghookServiceImpl.getDraghooksById(id);
            draghook.addComment(comment);
            //在redis中生成提示
            relmeService.setRelme(comment.getReplyKey(), id);
            //保持这次修改
            draghookServiceImpl.saveNewDraghook(draghook);
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("创建评论service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "创建评论service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("创建评论异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "创建评论异常" + e.getMessage());
        }

    }

    /**
     * 查看是否被点赞
     *
     * @param id
     * @param key
     * @return
     */
    @Override
    public ResponseResult lookIsGood(Integer id, String key) {

        try {
            Draghook draghook = draghookServiceImpl.getDraghooksById(id);
            List<Good> list = draghook.getGoods();
            for (Good good : list) {
                if (key.equals(good.getKey())) {
                    return ResponseResult.isFlase();
                }
            }
            return ResponseResult.isTrue();
        } catch (ServiceException biz) {
            log.error("查看是否被点赞service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看是否被点赞service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("查看是否被点赞异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看是否被点赞异常" + e.getMessage());
        }
    }

    /**
     * 创建点赞
     *
     * @param id
     * @param key
     * @param name
     * @param icon
     * @param type
     */
    @Override
    public ResponseResult createComment(Integer id, String key, String name, String icon, Integer type) {
        try {
            Draghook draghook = draghookServiceImpl.getDraghooksById(id);
            if (type == 1) { //进行点赞
                Good good = new Good(key, name, icon);
                draghook.addGood(good);
            } else {//取消点赞
                List<Good> goods = draghook.getGoods();
                if (goods != null && goods.size() != 0) {
                    for (int i = goods.size() - 1; i >= 0; i--) {
                        if (goods.get(i).getKey().equals(key)) {
                            goods.remove(goods.get(i));
                        }
                    }
                    draghook.setGoods(goods);
                }
            }
            //保持这次修改
            draghookServiceImpl.saveNewDraghook(draghook);
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("创建点赞service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "创建点赞service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("创建点赞异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "创建点赞异常" + e.getMessage());
        }

    }

    /**
     * 撤回自己的评论
     *
     * @param dynid
     * @param commentid
     */
    @Override
    public ResponseResult removeComment(Integer dynid, Integer commentid) {
        try {
            Draghook draghook = draghookServiceImpl.getDraghooksById(dynid);
            List<Comment> list = draghook.getComments();
            if (list != null && list.size() != 0) {
                for (int i = list.size() - 1; i >= 0; i--) {
                    if (list.get(i).getId() == commentid) {
                        list.remove(list.get(i));
                    }
                }
            }
            draghook.setComments(list);
            draghookServiceImpl.saveNewDraghook(draghook);
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("撤回自己的评论service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "撤回自己的评论service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("撤回自己的评论异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "撤回自己的评论异常" + e.getMessage());
        }
    }
}
