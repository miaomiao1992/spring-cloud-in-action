package com.luo.springcloudeurekaclientdraghook.service;


import com.luo.entity.draghook.Comment;
import com.luo.model.ResponseResult;

public interface ICommentAndGoodBiz {

    /**
     * 统计是否有与我有关的新消息
     * @param curKey
     * @return
     */
    ResponseResult commentAndGoodcount (String curKey);


    /**
     * 取消提醒
     * @param curKey
     */
    ResponseResult removeRelme(String curKey);

    /**
     * 创建评论
     * @param comment
     * @param id
     */
    ResponseResult createCommentr(Comment comment, Integer id);

    /**
     * 查看是否被点赞
     * @param id
     * @param key
     * @return
     */
    ResponseResult lookIsGood(Integer id, String key);

    /**
     * 创建评论
     * @param id
     * @param key
     * @param name
     * @param icon
     * @param type
     */
    ResponseResult createComment(Integer id, String key, String name, String icon, Integer type);

    /**
     * 撤回自己的评论
     * @param dynid
     * @param commentid
     */
    ResponseResult removeComment(Integer dynid, Integer commentid);
}
