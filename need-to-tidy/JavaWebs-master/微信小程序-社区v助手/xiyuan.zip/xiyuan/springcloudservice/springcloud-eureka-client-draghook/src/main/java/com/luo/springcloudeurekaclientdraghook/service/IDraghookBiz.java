package com.luo.springcloudeurekaclientdraghook.service;

import com.luo.entity.draghook.Draghook;
import com.luo.model.ResponseResult;

public interface IDraghookBiz {
    /**
     * 创建拉钩活动
     * @param draghook
     */
    ResponseResult createDraghook(Draghook draghook);

    /**
     * 查看附件的拉钩活动
     * @param offset
     * @param limit
     * @param latitude
     * @param longitude
     * @return
     */
    ResponseResult getDraghooksByPage(Integer offset, Integer limit, double latitude, double longitude);

    /**
     * 查看被@自己的拉钩活动
     * @param curKey
     * @return
     */
    ResponseResult getAboutMyDraghooks(String curKey);

    /**
     * 查看自己发布的拉钩
     * @param pageNum
     * @param pageSize
     * @param curKey
     * @return
     */
    ResponseResult getMyDraghooksByPage(Integer pageNum, Integer pageSize, String curKey);

    /**
     * 刷新单个task
     * @param id
     * @return
     */
    ResponseResult getDraghookbyIdAndOpenId(Integer id);

    /**
     * 获得当前时间最近的拉钩
     * @param curKey
     * @param latitude
     * @param longitude
     * @return
     */
    ResponseResult getlatestDraghookbyOpenId(String curKey, double latitude, double longitude);

    /**
     * 获取task详情
     * @param id
     * @return
     */
    ResponseResult getDraghookDaoDetail(Integer id);

    /**
     * 删除自己的task
     * @param dynid
     * @return
     */
    ResponseResult removeDyn(Integer dynid);
}
