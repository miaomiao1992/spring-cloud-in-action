package com.luo.springcloudeurekaclientdraghook.controller;

import com.luo.annotation.ControllerMethodLog;
import com.luo.entity.draghook.Comment;
import com.luo.model.ResponseResult;
import com.luo.springcloudeurekaclientdraghook.service.imp.CommentAndGoodBizImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;



@RestController
@Api(value = "拉钩-点评模板")
public class CommentAndGoodController {


    @Autowired
    private CommentAndGoodBizImpl commentAndGoodBiz;

    //统计是否有与我有关的新消息
    @GetMapping("/CommentAndGoodcount")
    @ControllerMethodLog
    @ApiOperation(value = "是否有的新消息")
    public ResponseResult commentAndGoodcount(@RequestParam String curKey) {
        return commentAndGoodBiz.commentAndGoodcount(curKey);

    }

    //取消提醒
    @GetMapping("/RemoveRelme")
    @ControllerMethodLog
    @ApiOperation(value = "取消提醒")
    public ResponseResult removeRelme(@RequestParam String curKey)  {
        return commentAndGoodBiz.removeRelme(curKey);

    }


    //创建评论
    @PostMapping("/CommentNewOne")
    @ControllerMethodLog
    @ApiOperation(value = "创建评论")
    public ResponseResult createCommentr(
                                        @RequestParam Integer id,
                                        @RequestParam String key,
                                        @RequestParam String name,
                                        @RequestParam String icon,
                                        @RequestParam String content,
                                        @RequestParam String replyKey,
                                        @RequestParam String replyName
    )  {
        Comment comment = new Comment(key, name, icon, replyName, replyKey, content);
        return commentAndGoodBiz.createCommentr(comment,id);
    }


    //查看是否点赞过
    @GetMapping("/LookGood")
    @ControllerMethodLog
    @ApiOperation(value = "查看是否点赞过")
    public ResponseResult lookIsGood(@RequestParam Integer id, @RequestParam String key)  {
        return  commentAndGoodBiz.lookIsGood(id,key);
    }


    //创建点赞
    @PostMapping("/GoodNewOne")
    @ControllerMethodLog
    @ApiOperation(value = "创建点赞")
    public ResponseResult createComment(
                                        @RequestParam Integer id,
                                        @RequestParam String key,
                                        @RequestParam String name,
                                        @RequestParam String icon,
                                        @RequestParam Integer type
    )  {
       return commentAndGoodBiz.createComment(id,key,name,icon,type);
    }


    //撤回自己评论
    @GetMapping("/RemoveComment")
    @ControllerMethodLog
    @ApiOperation(value = "撤回自己评论")
    public ResponseResult removeComment(@RequestParam Integer dynid, @RequestParam Integer commentid)  {
       return commentAndGoodBiz.removeComment(dynid,commentid);

    }

}
