package com.luo.springcloudeurekaclientpark.service.imp;

import com.luo.entity.park.CarPark;
import com.luo.entity.park.Mark;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.BusinessException;
import com.luo.model.ResponseResult;
import com.luo.model.ServiceException;
import com.luo.services.park.imp.CarParkServiceImpl;
import com.luo.springcloudeurekaclientpark.service.ICarParkBiz;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class CarParkBizImpl implements ICarParkBiz {

    @Autowired
    private CarParkServiceImpl carParkServiceImpl;

    /**
     * 查看附近停车场
     *
     * @param latitude
     * @param longitude
     * @return
     */
    @Override
    public ResponseResult getParks(double latitude, double longitude) {
        try {
            List<CarPark> list = carParkServiceImpl.getAllCarPark(latitude, longitude);
            ResponseResult resultMent = new ResponseResult();
            List<Mark> marks = new ArrayList<>();
            if (list != null) {
                for (CarPark carPark : list) {
                    Mark mark = new Mark(carPark.getId(), carPark.getLatitude(), carPark.getLongitude());
                    marks.add(mark);
                }
            }
            resultMent.setSuccess(true);
            resultMent.setData(list);
            resultMent.setData2(marks);
            resultMent.setStatus(1);
            return resultMent;
        } catch (ServiceException biz) {
            log.error("查看附近停车场service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看附近停车场service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("查看附近停车场异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看附近停车场异常" + e.getMessage());
        }
    }

    /**
     * 查看停车场信息
     *
     * @param id
     * @return
     */
    @Override
    public ResponseResult getPark(Integer id) {
        try {
            CarPark carPark = carParkServiceImpl.getCarParkDetail(id);
            ResponseResult resultMent = new ResponseResult();
            resultMent.setSuccess(true);
            resultMent.setData(carPark);
            resultMent.setStatus(1);
            return resultMent;
        } catch (ServiceException biz) {
            log.error("查看停车场信息service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看停车场信息service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("查看停车场信息异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看停车场信息异常" + e.getMessage());
        }
    }


}
