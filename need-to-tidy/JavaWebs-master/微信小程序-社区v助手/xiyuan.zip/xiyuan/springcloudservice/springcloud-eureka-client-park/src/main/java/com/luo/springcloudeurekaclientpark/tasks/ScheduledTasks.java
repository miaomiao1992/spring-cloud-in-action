package com.luo.springcloudeurekaclientpark.tasks;


import com.luo.springcloudeurekaclientpark.service.imp.CarOrderBizImpl;
import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;


/**
 * 定时任务-让订单过期失效
 */
@Component
public class ScheduledTasks implements Job {

    @Autowired
    private CarOrderBizImpl biz;

    @Override
    public void execute(JobExecutionContext context)  {
        JobDataMap jobDataMap = context.getMergedJobDataMap();
        String name = jobDataMap.getString("name");
        Integer parkId = jobDataMap.getIntValue("parkId");
        scheduledTasks.biz.disableOrder(name, parkId);
    }


    public static ScheduledTasks scheduledTasks;

    public ScheduledTasks() {
    }

    @PostConstruct
    public void init() {
        scheduledTasks = this;
        scheduledTasks.biz = this.biz;
    }
}