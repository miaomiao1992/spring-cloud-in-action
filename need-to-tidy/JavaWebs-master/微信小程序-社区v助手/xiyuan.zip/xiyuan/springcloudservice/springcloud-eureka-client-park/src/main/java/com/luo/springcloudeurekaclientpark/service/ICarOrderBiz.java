package com.luo.springcloudeurekaclientpark.service;

import com.luo.entity.park.CarOrder;
import com.luo.model.ResponseResult;

public interface ICarOrderBiz {

    /**
     * 进行车位预约
     * @param carOrder
     * @return
     */
    ResponseResult createNewCarOrder(CarOrder carOrder);

    /**
     * 查看自己的订单
     * @param openId
     * @return
     */
    ResponseResult myOrders(String openId);

    /**
     * 停车或离开停车场
     * @param id
     * @param type
     * @param park
     * @param ord
     * @return
     */
    ResponseResult alterOrders(String id, Integer type, Integer park, Integer ord);

    /**
     * 创建新订单
     * @param carOrder
     * @return
     */
    ResponseResult createNewOrder(CarOrder carOrder);

    /**
     * 使订单失败
     * @param ordId
     * @param parkId
     */
    void disableOrder(String ordId, Integer parkId);
}
