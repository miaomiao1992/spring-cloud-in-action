package com.luo.springcloudeurekaclientpark.controller;
import com.luo.annotation.ControllerMethodLog;
import com.luo.entity.park.CarOrder;
import com.luo.model.ResponseResult;
import com.luo.springcloudeurekaclientpark.service.imp.CarOrderBizImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@Api(value = "停车-订单模块")
@RestController
public class CarOrderController {

    @Autowired
    private CarOrderBizImpl carOrderBiz;


    //进行车位预约
    @PostMapping("/CreateNewCarOrder")
    @ControllerMethodLog
    @ApiOperation(value = "车位预约")
    public ResponseResult createNewCarOrder(@RequestBody CarOrder carOrder) {
        return carOrderBiz.createNewCarOrder(carOrder);
    }


    //查看订单
    @PostMapping("/MyOrders")
    @ControllerMethodLog
    @ApiOperation(value = "查看订单")
    public ResponseResult myOrders(@RequestParam String openId)  {
        return carOrderBiz.myOrders(openId);
    }


    //停车或离开停车场
    @PostMapping("/AlterOrders")
    @ControllerMethodLog
    @ApiOperation(value = "停车或离开停车场")
    public ResponseResult alterOrders(
                         @RequestParam String id,
                         @RequestParam Integer type,
                         @RequestParam Integer park,
                         @RequestParam Integer ord
    )  {
        return carOrderBiz.alterOrders(id,type,park,ord);
    }
}
