package com.luo.springcloudeurekaclientpark.service.imp;

import com.luo.entity.park.CarOrder;
import com.luo.enums.CouponTypeEnum;
import com.luo.model.BusinessException;
import com.luo.model.ResponseResult;
import com.luo.model.ServiceException;
import com.luo.services.park.imp.CarParkServiceImpl;
import com.luo.services.park.imp.OrderServiceImpl;
import com.luo.springcloudeurekaclientpark.messages.ParkMQProducer;
import com.luo.springcloudeurekaclientpark.service.ICarOrderBiz;
import com.luo.springcloudeurekaclientpark.tasks.ScheduledTasks;
import com.luo.utils.DateUtils;
import com.luo.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import static org.quartz.JobBuilder.newJob;

@Service
@Slf4j
public class CarOrderBizImpl implements ICarOrderBiz {

    @Autowired
    private OrderServiceImpl orderServiceImpl;

    @Autowired
    private CarParkServiceImpl carParkServiceImpl;

    @Autowired
    private ParkMQProducer parkMQProducer;

    @Autowired
    private RestTemplate restTemplate;


    /**
     * 进行车位预约
     *
     * @param carOrder
     * @return
     */
    @Override
    public ResponseResult createNewCarOrder(CarOrder carOrder) {
        try {
            ResponseResult resultMent = new ResponseResult();
            resultMent.setSuccess(true);
            Integer points = getUserPoints(carOrder.getUserId());
            if (points >= 60) {
                if (carParkServiceImpl.isPreOrder(carOrder.getPlateNumber())) {//已预约
                    resultMent.setStatus(-2);
                } else {//未预约
                    carOrder.setType(1);
                    parkMQProducer.createCarOrder(carOrder);
                    //减少车位数
                    carParkServiceImpl.parking(carOrder.getParkId());
                    resultMent.setStatus(-1);
                }
            } else {
                resultMent.setStatus(points);
            }
            return resultMent;
        } catch (ServiceException biz) {
            log.error("进行车位预约service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "进行车位预约service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("进行车位预约异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "进行车位预约异常" + e.getMessage());
        }
    }

    /**
     * 查看自己的订单
     *
     * @param openId
     * @return
     */
    @Override
    public ResponseResult myOrders(String openId) {
        try {
            List<CarOrder> list = orderServiceImpl.getMyOrders(openId);
            Integer points = getUserPoints(openId);
            //获取用户的信誉分
            ResponseResult resultMent = new ResponseResult();
            resultMent.setData(list);
            resultMent.setSuccess(true);
            resultMent.setStatus(points);
            return resultMent;
        } catch (ServiceException biz) {
            log.error("查看自己的订单service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看自己的订单service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("查看自己的订单异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "查看自己的订单异常" + e.getMessage());
        }
    }

    /**
     * 停车或离开停车场
     *
     * @param id
     * @param type
     * @param park
     * @param ord
     * @return
     */
    @Override
    public ResponseResult alterOrders(String id, Integer type, Integer park, Integer ord) {
        try {
            if (type == 5) {
                orderServiceImpl.removeOrderById(id);
                if (ord != 3 && ord != 4) {
                    carParkServiceImpl.leave(park);
                }
            } else {
                CarOrder carOrder = orderServiceImpl.getOrderById(id);
                carOrder.setType(type);
                //在这里同步车库的车位数量
                if (type == 3) {
                    carParkServiceImpl.leave(park);
                }
                orderServiceImpl.saveOrder(carOrder);
            }
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("停车或离开停车场service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "停车或离开停车场service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("停车或离开停车场异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "停车或离开停车场异常" + e.getMessage());
        }
    }

    /**
     * 创建新订单(异步)
     * @param carOrder
     */
    @Override
    public ResponseResult createNewOrder(CarOrder carOrder) {
        try {

            String endTime = carOrder.getEndDate().replace('-', '/');
            Date date = new Date(endTime);
            //通过UUID生成唯一的订单号
            carOrder.setId(StringUtils.randomUUID());
            orderServiceImpl.saveOrder(carOrder);
            remove(carOrder.getId(),carOrder.getParkId(), DateUtils.getCron(date));
            return ResponseResult.success();
        } catch (ServiceException biz) {
            log.error("创建新订单service层异常", biz);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "创建新订单service层异常" + biz.getMessage());
        } catch (Exception e) {
            log.error("创建新订单异常", e);
            throw new BusinessException(CouponTypeEnum.OPERATE_ERROR, "创建新订单异常" + e.getMessage());
        }
    }

    /**
     * 使订单失败
     * @param ordId
     * @param parkId
     */
    @Override
    public void disableOrder(String ordId, Integer parkId) {
        CarOrder carOrder = orderServiceImpl.getOrderById(ordId);
        if (carOrder != null && carOrder.getType() == 1) {
            carParkServiceImpl.leave(parkId);
            carOrder.setType(4);
            orderServiceImpl.saveOrder(carOrder);
            reduce(carOrder.getUserId());
        }
    }

    /**
     * 通过定时器来删除
     * @param ordID
     * @param parkId
     * @param time
     * @throws ParseException
     * @throws SchedulerException
     */
    private void remove(String ordID, Integer parkId, String time) throws ParseException, SchedulerException {

        //定义一个JobDetail
        JobDetail job = newJob(ScheduledTasks.class) //定义Job类为HelloQuartz类，这是真正的执行逻辑所在
                .withIdentity(ordID, "group1") //定义name/group
                .usingJobData("name", ordID) //定义属性
                .usingJobData("parkId", parkId)
                .build();

        //作业的触发器
        CronTrigger cronTrigger = TriggerBuilder.newTrigger()
                .startNow()
                .withIdentity(ordID, "group1")
                .withSchedule(CronScheduleBuilder.cronSchedule(time)). //在任务调度器中，使用任务调度器的 CronScheduleBuilder 来生成一个具体的 CronTrigger 对象
                build();

        //得到默认的调度器
        Scheduler scheduler = StdSchedulerFactory.getDefaultScheduler();
        scheduler.scheduleJob(job, cronTrigger);
        scheduler.start();

    }


    /**
     * 获取用户信誉值
     * @param id
     * @return
     */

    private Integer getUserPoints(String id) {
        return new Integer(this.restTemplate.getForObject("http://139.196.137.129:8000/GetUser/" + id, String.class));
    }

    //预约过期 减少其信誉分
    private void reduce(String id) {
        this.restTemplate.getForObject("http://139.196.137.129:8000/Reduce/" + id, String.class);
    }




}
