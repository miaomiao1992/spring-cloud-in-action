package com.luo.springcloudeurekaclientpark.service;

import com.luo.model.ResponseResult;

public interface ICarParkBiz {

    /**
     * 查看附近停车场
     * @param latitude
     * @param longitude
     * @return
     */
    ResponseResult getParks(double latitude, double longitude);

    /**
     * 查看停车场信息
     * @param id
     * @return
     */
    ResponseResult getPark(Integer id);
}
