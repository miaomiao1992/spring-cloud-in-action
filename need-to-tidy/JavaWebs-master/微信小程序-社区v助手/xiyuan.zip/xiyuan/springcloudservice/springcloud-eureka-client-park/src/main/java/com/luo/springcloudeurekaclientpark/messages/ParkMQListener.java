package com.luo.springcloudeurekaclientpark.messages;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.luo.entity.park.CarOrder;
import com.luo.springcloudeurekaclientpark.service.imp.CarOrderBizImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

@Component
@Slf4j
public class ParkMQListener {

    @Autowired
    private CarOrderBizImpl carOrderBiz;

    private ParkMQListener parkMQListener;

    private static ObjectMapper objectMapper = new ObjectMapper();

    public ParkMQListener(){

    }
    @PostConstruct
    public void init() {
        parkMQListener = this;
        parkMQListener.carOrderBiz = this.carOrderBiz;
    }

    /**
     * 以队列消息的方式 异步停车订单
     * 监听消费消息(新建拉钩活动)
     * @param message
     */
    @RabbitListener(queues = "${park.queue.name}", containerFactory = "singleListenerContainer")
    public void consumeObjectQueue(@Payload byte[] message) {
        try {
            CarOrder carOrder = objectMapper.readValue(message, CarOrder.class);
            carOrderBiz.createNewOrder(carOrder);
            log.info("以队列消息的方式 异步创建停车订单： {} ", carOrder.toString());
        } catch (Exception e) {
            log.error("以队列消息的方式 异步创建停车订单异常{},{}",e.getStackTrace(), e);
        }
    }
}
