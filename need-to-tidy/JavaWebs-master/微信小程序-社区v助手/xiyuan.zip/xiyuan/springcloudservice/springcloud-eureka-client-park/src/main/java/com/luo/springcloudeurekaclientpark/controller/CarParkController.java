package com.luo.springcloudeurekaclientpark.controller;

import com.luo.annotation.ControllerMethodLog;
import com.luo.model.ResponseResult;
import com.luo.springcloudeurekaclientpark.service.imp.CarParkBizImpl;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Api(value = "停车-停车场模块")
public class CarParkController {


    @Autowired
    private CarParkBizImpl carParkBiz;

    //查看附近停车场
    @GetMapping("/GetParks")
    @ControllerMethodLog
    @ApiOperation(value = "查看附近停车场")
    public ResponseResult getParks(@RequestParam double latitude, @RequestParam double longitude)  {
        return carParkBiz.getParks(latitude,longitude);
    }


    //查看停车场信息
    @GetMapping("/GetPark")
    @ControllerMethodLog
    @ApiOperation(value = "查看停车场信息")
    public ResponseResult getPark(@RequestParam Integer id)  {
        return carParkBiz.getPark(id);
    }

}
