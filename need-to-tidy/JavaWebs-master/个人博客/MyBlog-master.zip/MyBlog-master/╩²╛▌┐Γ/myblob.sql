/*
Navicat MySQL Data Transfer

Source Server         : 阿里云服务器
Source Server Version : 50642
Source Host           : 47.94.101.75:3306
Source Database       : myblob

Target Server Type    : MYSQL
Target Server Version : 50642
File Encoding         : 65001

Date: 2020-07-01 17:35:06
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tb_article
-- ----------------------------
DROP TABLE IF EXISTS `tb_article`;
CREATE TABLE `tb_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article_typeID` smallint(6) NOT NULL,
  `article_title` varchar(40) DEFAULT NULL,
  `article_content` text,
  `article_sdTime` varchar(30) DEFAULT NULL,
  `article_create` varchar(10) DEFAULT NULL,
  `article_info` text,
  `article_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_article
-- ----------------------------
INSERT INTO `tb_article` VALUES ('2', '4', '保护环境！爱护地球！', '人类好比瞬间流星，<br>自然才是永远夜空。<br>当我们炫耀着不属于自己的光亮<br>一一坠落时，<br>请留下一片干净的天空！<br>人类好比瞬间流星，<br>自然才识永远夜空。<br>当我们炫耀着不属于自己的光亮<br>一一坠落时，<br>请留下一片干净的天空！<br>人类好比瞬间流星，<br>自然才识永远夜空。<br>当我们炫耀着不属于自己的光亮<br>一一坠落时，<br>请留下一片干净的天空！<br>人类好比瞬间流星，<br>自然才识永远夜空。<br>当我们炫耀着不属于自己的光亮<br>一一坠落时，<br>请留下一片干净的天空！', '2008年02月13日 17:04:29', '原创', '绝对原创！', '1');
INSERT INTO `tb_article` VALUES ('3', '3', '心中最向往的生活方式！', '是衣来伸手、饭来张口；还是日出而作、日落而息？<br>是远离文明世界中的是是非非；还是继续追求昙花一显的那份虚荣？<br>每天都期待着发生什么，街上、商场、餐厅、公司和家里；<br>每天都在这种期待中一无所获的度过。<br>到今天，之前的每一天过的充实人们，<br>也许是为了实现他的目标、也许是想从这个世界找回点公平、也许是一种习惯。<br>满足你所有的要求，你会生存多久？<br>从今天，坚定一种信念，才会体会生存的意义！<br>是衣来伸手、饭来张口；还是日出而作、日落而息？<br>是远离文明世界中的是是非非；还是继续追求昙花一显的那份虚荣？<br>每天都期待着发生什么，街上、商场、餐厅、公司和家里；<br>每天都在这种期待中一无所获的度过。<br>到今天，之前的每一天过的充实人们，<br>也许是为了实现他的目标、也许是想从这个世界找回点公平、也许是一种习惯。<br>满足你所有的要求，你会生存多久？<br>从今天，坚定一种信念，才会体会生存的意义！', '2008年02月13日 16:50:12', '原创', '绝对原创！', '0');
INSERT INTO `tb_article` VALUES ('4', '4', '爱护环境！保护地球！', '人类好比瞬间流星，<br>自然才识永远夜空。<br>当我们炫耀着不属于自己的光亮<br>一一坠落时，<br>请留下一片干净的天空！<br>人类好比瞬间流星，<br>自然才识永远夜空。<br>当我们炫耀着不属于自己的光亮<br>一一坠落时，<br>请留下一片干净的天空！<br>人类好比瞬间流星，<br>自然才识永远夜空。<br>当我们炫耀着不属于自己的光亮<br>一一坠落时，<br>请留下一片干净的天空！', '2008年02月12日 09:15:09', '原创', '绝对原创！', '1');
INSERT INTO `tb_article` VALUES ('5', '1', '心中最向往的居住田园！', '山山水水，绿绿清清；树树草草，郁郁匆匆！<br>小溪流水，鱼儿静游；林间明暗，鸟儿幽闲！<br>微风、流水、淡黑、自然的味道！<br>鸟儿、树语、湿润、万物的生存！<br>山山水水，绿绿清清；树树草草，郁郁匆匆！<br>小溪流水，鱼儿静游；林间明暗，鸟儿幽闲！<br>微风、流水、淡黑、自然的味道！<br>鸟儿、树语、湿润、万物的生存！<br>山山水水，绿绿清清；树树草草，郁郁匆匆！<br>小溪流水，鱼儿静游；林间明暗，鸟儿幽闲！<br>微风、流水、淡黑、自然的味道！<br>鸟儿、树语、湿润、万物的生存！<br>山山水水，绿绿清清；树树草草，郁郁匆匆！<br>小溪流水，鱼儿静游；林间明暗，鸟儿幽闲！<br>微风、流水、淡黑、自然的味道！<br>鸟儿、树语、湿润、万物的生存！<br>山山水水，绿绿清清；树树草草，郁郁匆匆！<br>小溪流水，鱼儿静游；林间明暗，鸟儿幽闲！<br>微风、流水、淡黑、自然的味道！<br>鸟儿、树语、湿润、万物的生存！', '2008年02月13日 16:51:14', '原创', '绝对原创！', '4');
INSERT INTO `tb_article` VALUES ('6', '2', '心中最向往的一顿大餐！', '天上飞的、地上跑的、水里游的！<br>鱼和熊掌、天鹅肉，再加一瓶二锅头！<br>天上飞的、地上跑的、水里游的！<br>鱼和熊掌、天鹅肉，再加一瓶二锅头！<br>天上飞的、地上跑的、水里游的！<br>鱼和熊掌、天鹅肉，再加一瓶二锅头！<br>天上飞的、地上跑的、水里游的！<br>鱼和熊掌、天鹅肉，再加一瓶二锅头！<br>天上飞的、地上跑的、水里游的！<br>鱼和熊掌、天鹅肉，再加一瓶二锅头！<br>天上飞的、地上跑的、水里游的！<br>鱼和熊掌、天鹅肉，再加一瓶二锅头！', '2008年02月13日 16:57:56', '原创', '绝对原创！', '0');
INSERT INTO `tb_article` VALUES ('7', '1', '11', '21', '2020年07月01日 17:18:22', '原创', '22', '0');

-- ----------------------------
-- Table structure for tb_articleType
-- ----------------------------
DROP TABLE IF EXISTS `tb_articleType`;
CREATE TABLE `tb_articleType` (
  `articleType_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `articleType_name` varchar(20) DEFAULT NULL,
  `articleType_info` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`articleType_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_articleType
-- ----------------------------
INSERT INTO `tb_articleType` VALUES ('1', '个人随想', '记录心里所想');
INSERT INTO `tb_articleType` VALUES ('2', '个人日记', '记录一天所发生的事情');
INSERT INTO `tb_articleType` VALUES ('3', '人生感悟', '记录生活中所发生的事情');
INSERT INTO `tb_articleType` VALUES ('4', '推荐文章', '推荐好的文章');

-- ----------------------------
-- Table structure for tb_friend
-- ----------------------------
DROP TABLE IF EXISTS `tb_friend`;
CREATE TABLE `tb_friend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `friend_name` varchar(20) DEFAULT NULL,
  `friend_sex` varchar(2) DEFAULT NULL,
  `friend_OICQ` varchar(20) DEFAULT NULL,
  `friend_blog` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_friend
-- ----------------------------

-- ----------------------------
-- Table structure for tb_master
-- ----------------------------
DROP TABLE IF EXISTS `tb_master`;
CREATE TABLE `tb_master` (
  `master_name` varchar(50) NOT NULL,
  `master_password` varchar(10) DEFAULT NULL,
  `master_sex` varchar(2) DEFAULT NULL,
  `master_oicq` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`master_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_master
-- ----------------------------
INSERT INTO `tb_master` VALUES ('123', '123', '1', '2');

-- ----------------------------
-- Table structure for tb_photo
-- ----------------------------
DROP TABLE IF EXISTS `tb_photo`;
CREATE TABLE `tb_photo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photo_addr` text,
  `photo_sdTime` varchar(30) DEFAULT NULL,
  `photo_desc` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_photo
-- ----------------------------
INSERT INTO `tb_photo` VALUES ('1', 'front/photo/pic/0.jpg', '2008年02月14日 08:57:59', '超越');
INSERT INTO `tb_photo` VALUES ('2', 'front/photo/pic/1.jpg', '2008年02月14日 08:59:11', '水中倒影');
INSERT INTO `tb_photo` VALUES ('3', 'front/photo/pic/2.jpg', '2008年02月14日 08:59:44', '假山、瀑布1');
INSERT INTO `tb_photo` VALUES ('4', 'front/photo/pic/3.jpg', '2008年02月14日 08:59:11', '水中倒影2');
INSERT INTO `tb_photo` VALUES ('5', 'front/photo/pic/4.jpg', '2008年02月14日 08:59:44', '假山、瀑布3');

-- ----------------------------
-- Table structure for tb_review
-- ----------------------------
DROP TABLE IF EXISTS `tb_review`;
CREATE TABLE `tb_review` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `review_articleId` int(11) DEFAULT NULL,
  `review_author` varchar(50) DEFAULT NULL,
  `review_content` text,
  `review_sdTime` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_review
-- ----------------------------

-- ----------------------------
-- Table structure for tb_word
-- ----------------------------
DROP TABLE IF EXISTS `tb_word`;
CREATE TABLE `tb_word` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word_title` varchar(50) DEFAULT NULL,
  `word_content` text,
  `word_sdTime` varchar(30) DEFAULT NULL,
  `word_author` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_word
-- ----------------------------
