package com.luo.imagerepair.service;

import com.alibaba.csp.sentinel.annotation.SentinelResource;
import org.springframework.stereotype.Service;

@Service
public class UserService {


    @SentinelResource(value = "sayHello",fallback = "sayHellofail")
    public String sayHello(){
        return "Hello,World";

    }

    public  String sayHellofail(){
        return "I'am sorry";
    }

}
