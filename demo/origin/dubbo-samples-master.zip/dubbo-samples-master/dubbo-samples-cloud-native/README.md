# Showcasing smooth upgrading of Dubbo3

## Start Dubbo3 Provider

Test both interface-level and application-level are registered successfully and are ready for subscription.

## Start Dubbo2 Consumer

Test Dubbo2 Consumer using version 2.7.15 can find interface-level addresses provided by Dubbo3 provider.

## Start Dubbo3 Consumer

Test Dubbo3 Consumer can find application-level addresses provided by Dubbo3 provider.




