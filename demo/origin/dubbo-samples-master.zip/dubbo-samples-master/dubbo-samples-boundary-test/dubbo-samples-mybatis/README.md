# Dubbo + Mybatis

This is a dubbo + mybatis sample.

In this sample, provider is using @ComponentScan and consumer is using xml configuration.

