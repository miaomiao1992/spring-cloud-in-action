# Dubbo + Hibernate

This is a dubbo + hibernate sample.

In this sample, both provider and consumer are using xml as configuration. 

Please aware that dubbo doesn't require
special hibernate version, but spring and hibernate does have some version requirement. So please make sure you are
using right version in your own project.

