This Sub-Module is for integration test only.
Including some boundary test cases.