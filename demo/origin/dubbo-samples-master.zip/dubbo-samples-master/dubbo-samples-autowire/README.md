### Dubbo Reference is injected once, quoted everywhere

This sample shows how to combine Dubbo and Spring, inject reference object once, and reference everywhere.