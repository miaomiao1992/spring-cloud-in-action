package com.goodskill.chat.vo;

/**
 * 用户信息
 */
public class UserInfo {
    /**
     * 用户id
     */
    private String userId;
    /**
     * 用户名
     */
    private String userName;
    /**
     * 用户账号
     */
    private String account;
}
