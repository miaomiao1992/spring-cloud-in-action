package com.goodskill.mp.dao.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.goodskill.entity.User;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author heng
 * @since 2019-09-07
 */
public interface UserMapper extends BaseMapper<User> {

}
