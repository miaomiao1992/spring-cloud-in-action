package com.goodskill.api.dto;

import lombok.Data;

import java.io.Serializable;

/**
 *
 * @author techa03
 * @date 2020/8/8
 */
@Data
public class SeckillResponseDTO implements Serializable {
    private byte[] data;

}
