package com.goodskill.service.common.constant;

public class CommonConstant {
    public static final String DEFAULT_BINDING_NAME = "seckilResult-out-0";
    public static final String DEFAULT_BINDING_NAME_MONGO_SAVE = "seckillMongoSave-out-0";
}
