package com.goodskill.service.common;

import com.baomidou.mybatisplus.extension.service.IService;
import com.goodskill.entity.SuccessKilled;

/**
 * @author heng
 */
public interface SuccessKilledService extends IService<SuccessKilled> {
}
