package com.goodskill.service.common;

import com.baomidou.mybatisplus.extension.service.IService;
import com.goodskill.entity.User;

/**
 * @author heng
 */
public interface UserService extends IService<User> {
}
