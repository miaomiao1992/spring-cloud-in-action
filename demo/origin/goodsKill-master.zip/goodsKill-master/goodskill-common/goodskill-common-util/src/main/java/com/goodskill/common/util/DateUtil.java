package com.goodskill.common.util;

import java.util.Date;

/**
 * Created by heng on 2017/7/3.
 */
public class DateUtil {
    public static Date getNowTime() {
        return new Date();
    }
}
