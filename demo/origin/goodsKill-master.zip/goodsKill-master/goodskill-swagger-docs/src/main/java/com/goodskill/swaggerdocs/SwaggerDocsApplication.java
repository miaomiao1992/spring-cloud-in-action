package com.goodskill.swaggerdocs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwaggerDocsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SwaggerDocsApplication.class, args);
    }

}
