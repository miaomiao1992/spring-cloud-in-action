package org.seckill.service.test.base;

import org.junit.Test;

/**
 * Created by heng on 2017/6/28.
 */
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration({
//        "classpath:META-INF/spring/spring-dao.xml",
//        "classpath:META-INF/spring/spring-service.xml"})
//@Transactional
public class BaseServiceConfigForTest {
    @Test
    public void test(){

    }
}
