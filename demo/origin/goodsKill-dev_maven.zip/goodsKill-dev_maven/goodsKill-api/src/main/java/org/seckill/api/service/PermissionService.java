package org.seckill.api.service;

import org.seckill.entity.Permission;
import org.seckill.entity.PermissionExample;

public interface PermissionService extends CommonService<PermissionExample, Permission> {
}
