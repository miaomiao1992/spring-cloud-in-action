package org.seckill.api.annotation;

public @interface BaseService {
}
