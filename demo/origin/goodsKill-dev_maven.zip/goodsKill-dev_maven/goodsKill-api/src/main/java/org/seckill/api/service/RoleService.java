package org.seckill.api.service;

import org.seckill.entity.Role;
import org.seckill.entity.RoleExample;

public interface RoleService extends CommonService<RoleExample, Role> {
}
