package org.seckill.api.service;

import org.seckill.entity.UserRole;
import org.seckill.entity.UserRoleExample;

public interface UserRoleService extends CommonService<UserRoleExample, UserRole> {
}
