package org.seckill.api.service;

import org.seckill.entity.RolePermission;
import org.seckill.entity.RolePermissionExample;

public interface RolePermissionService extends CommonService<RolePermissionExample, RolePermission> {
}
