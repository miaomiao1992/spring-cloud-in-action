package org.seckill.util.common.util;

import java.util.Date;

/**
 *
 * @author heng
 * @date 2017/7/3
 */
public class DateUtil {
    public static Date getNowTime() {
        return new Date();
    }
}
