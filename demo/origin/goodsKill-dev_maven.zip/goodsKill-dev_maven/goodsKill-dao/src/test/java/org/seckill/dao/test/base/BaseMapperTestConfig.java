package org.seckill.dao.test.base;

/**
 * Created by heng on 2017/6/24.
 */
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration({"classpath:spring-dao-test.xml"})
//@Transactional
public class BaseMapperTestConfig {
//    @Autowired
//    ExtSeckillMapper extSeckillMapper;

//    @Test
//    public void testSelectByPrimaryKey() throws Exception {
//        SuccessKilled map= new SuccessKilled();
//        map.setSeckillId(1002L);
//        map.setUserPhone("133");
//        map.setCreateTime(new Date());
//        map.setServerIp("");
//        extSeckillMapper.reduceNumberByProcedure(map);
//        System.out.println(map.toString());
//    }
}
