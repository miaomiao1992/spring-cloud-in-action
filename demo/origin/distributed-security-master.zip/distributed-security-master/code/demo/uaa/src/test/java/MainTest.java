import com.uaa.UaaApplication;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @Description:
 * @Author: zhurongsheng
 * @Date: 2020/7/20 21:38
 */
@RunWith(SpringRunner.class)
//主application方法
@SpringBootTest(classes= UaaApplication.class)
public class MainTest {


    @Test
    public void mainTest(){



    }

}
