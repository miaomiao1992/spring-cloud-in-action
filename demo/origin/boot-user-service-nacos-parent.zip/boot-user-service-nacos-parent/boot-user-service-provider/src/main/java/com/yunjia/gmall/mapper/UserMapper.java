package com.yunjia.gmall.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.yunjia.gmall.bean.User;

public interface UserMapper extends BaseMapper<User> {
}
