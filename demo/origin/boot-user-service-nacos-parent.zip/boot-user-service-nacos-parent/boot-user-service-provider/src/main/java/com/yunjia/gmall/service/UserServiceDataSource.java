package com.yunjia.gmall.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.yunjia.gmall.bean.User;

public interface UserServiceDataSource extends IService<User> { }
