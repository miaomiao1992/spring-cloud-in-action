package com.yunjia.gmall;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootUserInterfaceApplicationTests {

    @Test
    void contextLoads() {
    }

}
