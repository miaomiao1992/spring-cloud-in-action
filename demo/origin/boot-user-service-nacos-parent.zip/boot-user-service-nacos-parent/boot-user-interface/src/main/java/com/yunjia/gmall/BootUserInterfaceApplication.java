package com.yunjia.gmall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootUserInterfaceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BootUserInterfaceApplication.class, args);
    }

}
