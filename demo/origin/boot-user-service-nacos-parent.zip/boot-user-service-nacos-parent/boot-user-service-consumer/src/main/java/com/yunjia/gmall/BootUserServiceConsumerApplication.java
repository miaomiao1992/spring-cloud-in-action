package com.yunjia.gmall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootUserServiceConsumerApplication {
    public static void main(String[] args) {
        SpringApplication.run(BootUserServiceConsumerApplication.class, args);
    }
}
