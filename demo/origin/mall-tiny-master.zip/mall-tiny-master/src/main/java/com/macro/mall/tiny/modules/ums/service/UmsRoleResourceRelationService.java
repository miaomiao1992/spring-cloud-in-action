package com.macro.mall.tiny.modules.ums.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.macro.mall.tiny.modules.ums.model.UmsRoleResourceRelation;

/**
 * 角色资源关系管理Service
 * Created by macro on 2020/8/21.
 */
public interface UmsRoleResourceRelationService extends IService<UmsRoleResourceRelation> {
}
