package com.macro.mall.tiny.modules.ums.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.macro.mall.tiny.modules.ums.model.UmsAdminRoleRelation;

/**
 * 管理员角色关系管理Service
 * Created by macro on 2020/8/21.
 */
public interface UmsAdminRoleRelationService extends IService<UmsAdminRoleRelation> {
}
