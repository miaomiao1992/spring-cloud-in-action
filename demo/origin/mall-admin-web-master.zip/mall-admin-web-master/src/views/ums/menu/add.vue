<template> 
  <menu-detail :is-edit='false'></menu-detail>
</template>
<script>
  import MenuDetail from './components/MenuDetail'
  export default {
    name: 'addMenu',
    components: { MenuDetail }
  }
</script>
<style>
</style>


