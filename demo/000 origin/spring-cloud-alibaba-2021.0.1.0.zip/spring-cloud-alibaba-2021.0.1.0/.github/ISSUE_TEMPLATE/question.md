---
name: Question
about: how to ask an valid question
title: ''
labels: ''
assignees: ''

---

我们鼓励使用英文，如果不能直接使用，可以使用翻译软件，您仍旧可以保留中文原文。
We recommend using English. If you are non-native English speaker, you can use the translation software. 


**Which Component**
eg. Nacos Discovery, Sentinel

**Describe what problem you have encountered**
A clear and concise description of what you want to do.

**Describe what information you have read**
eg. I have read the reference doc of Sentinel
