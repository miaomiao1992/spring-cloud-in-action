package com.springboot.cloud.common.web.exception;

import org.junit.Test;

public class DefaultGlobalExceptionHandlerAdviceTest {

    @Test
    public void testMethod() {

    }

}