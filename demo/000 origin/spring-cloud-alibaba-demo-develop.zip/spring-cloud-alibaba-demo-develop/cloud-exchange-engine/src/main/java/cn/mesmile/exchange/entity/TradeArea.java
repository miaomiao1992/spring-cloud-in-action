package cn.mesmile.exchange.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 交易区
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
@Data
@TableName("trade_area")
@ApiModel(value = "TradeArea对象", description = "交易区")
public class TradeArea implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("交易区名称")
    private String name;

    @ApiModelProperty("交易区代码")
    private String code;

    @ApiModelProperty("类型：1-数字货币交易；2-创新交易使用；")
    private Integer type;

    @ApiModelProperty("结算币种（仅创新交易需要使用）")
    private Long coinId;

    @ApiModelProperty("结算币种名称（仅创新交易需要使用）")
    private String coinName;

    @ApiModelProperty("排序")
    private Integer sort;

    @ApiModelProperty("状态")
    private Integer status;

    @ApiModelProperty("是否作为基础结算货币,0否1是 供统计个人账户使用")
    private Long baseCoin;

    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;

    @ApiModelProperty("创建时间")
    private Date created;


}
