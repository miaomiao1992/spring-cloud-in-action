package cn.mesmile.exchange.service.impl;

import cn.mesmile.exchange.entity.TurnoverOrder;
import cn.mesmile.exchange.mapper.TurnoverOrderMapper;
import cn.mesmile.exchange.service.TurnoverOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 成交订单 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class TurnoverOrderServiceImpl extends ServiceImpl<TurnoverOrderMapper, TurnoverOrder> implements TurnoverOrderService {

    @Override
    public Page<TurnoverOrder> findTurnoverOrderPage(Page<TurnoverOrder> page) {
        Page<TurnoverOrder> result = page(page);
        return result;
    }
}
