package cn.mesmile.exchange.mapper;

import cn.mesmile.exchange.entity.TurnoverOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 成交订单 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
public interface TurnoverOrderMapper extends BaseMapper<TurnoverOrder> {

}
