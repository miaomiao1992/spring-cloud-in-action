package cn.mesmile.exchange.rocket;

import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;

/**
 * @author zb
 * @date 2022/3/22 16:57
 * @Description
 */
public interface Source {

    /**
     *   @Input("order_in")     消费者
     *   @Output("order_out")   生产者
     */
    @Output("order_out")
    MessageChannel sendOutMessage();
}
