package cn.mesmile.exchange.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.exchange.service.TradeAreaService;
import cn.mesmile.exchange.entity.TradeArea;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 交易区 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
@Api(value = "交易区相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/exchange/trade-area")
public class TradeAreaController {

    private final TradeAreaService tradeAreaService;

    @ApiOperation("分页查询交易区")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<TradeArea>> findTradeAreaPage(@ApiIgnore Page<TradeArea> page){
        Page<TradeArea> result = tradeAreaService.findTradeAreaPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增交易区")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "tradeArea", value = "tradeArea对象的json数据")
    })
    public R save(@RequestBody TradeArea tradeArea){
        boolean save = tradeAreaService.save(tradeArea);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改交易区")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "tradeArea", value = "tradeArea对象的json数据")
    })
    public R update(@RequestBody TradeArea tradeArea){
        boolean update = tradeAreaService.updateById(tradeArea);
        return R.status(update);
    }

    @ApiOperation("删除交易区")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = tradeAreaService.removeByIds(ids);
        return R.data(delete);
    }
}
