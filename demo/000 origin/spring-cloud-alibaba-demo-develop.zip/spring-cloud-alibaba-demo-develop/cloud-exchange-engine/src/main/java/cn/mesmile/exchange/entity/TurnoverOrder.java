package cn.mesmile.exchange.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 成交订单
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
@Data
@TableName("turnover_order")
@ApiModel(value = "TurnoverOrder对象", description = "成交订单")
public class TurnoverOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("市场ID")
    private Long marketId;

    @ApiModelProperty("交易对类型：1-币币交易；2-创新交易；")
    private Integer marketType;

    @ApiModelProperty("交易类型:1 买 2卖")
    private Boolean tradeType;

    @ApiModelProperty("交易对标识符")
    private String symbol;

    @ApiModelProperty("交易对名称")
    private String marketName;

    @ApiModelProperty("卖方用户ID")
    private Long sellUserId;

    @ApiModelProperty("卖方币种ID")
    private Long sellCoinId;

    @ApiModelProperty("卖方委托订单ID")
    private Long sellOrderId;

    @ApiModelProperty("卖方委托价格")
    private BigDecimal sellPrice;

    @ApiModelProperty("卖方手续费率")
    private BigDecimal sellFeeRate;

    @ApiModelProperty("卖方委托数量")
    private BigDecimal sellVolume;

    @ApiModelProperty("买方用户ID")
    private Long buyUserId;

    @ApiModelProperty("买方币种ID")
    private Long buyCoinId;

    @ApiModelProperty("买方委托订单ID")
    private Long buyOrderId;

    @ApiModelProperty("买方委托数量")
    private BigDecimal buyVolume;

    @ApiModelProperty("买方委托价格")
    private BigDecimal buyPrice;

    @ApiModelProperty("买方手续费率")
    private BigDecimal buyFeeRate;

    @ApiModelProperty("委托订单ID")
    private Long orderId;

    @ApiModelProperty("成交总额")
    private BigDecimal amount;

    @ApiModelProperty("成交价格")
    private BigDecimal price;

    @ApiModelProperty("成交数量")
    private BigDecimal volume;

    @ApiModelProperty("成交卖出手续费")
    private BigDecimal dealSellFee;

    @ApiModelProperty("成交卖出手续费率")
    private BigDecimal dealSellFeeRate;

    @ApiModelProperty("成交买入手续费")
    private BigDecimal dealBuyFee;

    @ApiModelProperty("成交买入成交率费")
    private BigDecimal dealBuyFeeRate;

    @ApiModelProperty("状态0待成交，1已成交，2撤销，3.异常")
    private Boolean status;

    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @ApiModelProperty("创建时间")
    private Date created;


}
