package cn.mesmile.exchange.mapper;

import cn.mesmile.exchange.entity.TradeArea;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 交易区 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
public interface TradeAreaMapper extends BaseMapper<TradeArea> {

}
