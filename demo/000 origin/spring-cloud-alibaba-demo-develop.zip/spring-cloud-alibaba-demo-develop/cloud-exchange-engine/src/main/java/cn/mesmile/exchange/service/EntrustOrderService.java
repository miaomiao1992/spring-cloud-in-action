package cn.mesmile.exchange.service;

import cn.mesmile.exchange.entity.EntrustOrder;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 委托订单信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
public interface EntrustOrderService extends IService<EntrustOrder> {

    /**
     * 分页查找委托订单信息
     * @param page 分页信息
     * @return
     */
    Page<EntrustOrder> findEntrustOrderPage(Page<EntrustOrder> page);
}

