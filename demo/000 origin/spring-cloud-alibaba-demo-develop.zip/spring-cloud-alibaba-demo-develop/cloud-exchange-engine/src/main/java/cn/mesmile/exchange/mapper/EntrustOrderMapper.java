package cn.mesmile.exchange.mapper;

import cn.mesmile.exchange.entity.EntrustOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 委托订单信息 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
public interface EntrustOrderMapper extends BaseMapper<EntrustOrder> {

}
