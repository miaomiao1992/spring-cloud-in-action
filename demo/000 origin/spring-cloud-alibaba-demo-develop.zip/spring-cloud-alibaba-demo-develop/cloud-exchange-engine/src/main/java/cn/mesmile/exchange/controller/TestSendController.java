package cn.mesmile.exchange.controller;

import cn.hutool.core.util.RandomUtil;
import cn.mesmile.common.result.R;
import cn.mesmile.exchange.rocket.Source;
import io.swagger.annotations.Api;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * @author zb
 * @date 2022/3/22 17:55
 * @Description
 */
@Slf4j
@Api(value = "交易对配置信息相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/exchange/test")
public class TestSendController {

    @Autowired
    private Source source;

    @GetMapping("/send")
    public R send(){
        ArrayList<EntrustOrder> orders = new ArrayList<>();
        List<String> strings = Arrays.asList("BTCGCN", "ETHGCN", "FOFTGCN", "ANGELGCN", "ESDCGCN", "KJLGCN", "TRXGCN", "QTUMGCN", "LTCGCN", "AEGCN", "CEOCGCN", "PCNFGCN");
        for (int j = 0; j < 3 ; j++) {
            int size = strings.size();
            int i = RandomUtil.randomInt(0, size);
            EntrustOrder entrustOrder = new EntrustOrder();
            entrustOrder.setId(Long.valueOf(RandomUtil.randomNumbers(10)));
            entrustOrder.setUserId(123456L);
            entrustOrder.setMarketId(Long.valueOf(RandomUtil.randomNumbers(10)));
            entrustOrder.setMarketType(1);
            entrustOrder.setSymbol(strings.get(i));
            entrustOrder.setPrice(BigDecimal.valueOf(RandomUtil.randomInt(100, 3000)));
            entrustOrder.setMergeLowPrice(BigDecimal.valueOf(RandomUtil.randomInt(100, 3000)));
            entrustOrder.setMergeHighPrice(BigDecimal.valueOf(RandomUtil.randomInt(100, 3000)));
            entrustOrder.setVolume(new BigDecimal(i));
            entrustOrder.setAmount(new BigDecimal(i));
            entrustOrder.setFeeRate(new BigDecimal(i));
            entrustOrder.setFee(new BigDecimal(i));
            entrustOrder.setContractUnit(2);
            entrustOrder.setDeal(new BigDecimal(i));
            entrustOrder.setFreeze(new BigDecimal(i));
            entrustOrder.setMarginRate(new BigDecimal(i));
            entrustOrder.setBaseCoinRate(new BigDecimal(i));
            entrustOrder.setPriceCoinRate(new BigDecimal(i));
            entrustOrder.setLockMargin(new BigDecimal(i));
            entrustOrder.setPriceType(RandomUtil.randomInt(1, 3));
            entrustOrder.setTradeType(RandomUtil.randomInt(1, 3));
            entrustOrder.setType(RandomUtil.randomInt(1, 3));
            entrustOrder.setOpenOrderId(1L);
            entrustOrder.setStatus(1);
            entrustOrder.setLastUpdateTime(new Date());
            entrustOrder.setCreated(new Date());

            MessageBuilder<EntrustOrder> messageBuilder = MessageBuilder.withPayload(entrustOrder)
                    .setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON);
            // 发送数据到消息队列
            log.info(">>>>>>>>>>>>>>>>>>>>>start>>>>>>>>>>>>>>>>>>>>>>>>");
            boolean send = source.sendOutMessage().send(messageBuilder.build());
            log.info("发送结果："+ send +" 第 【"+j+"】条"+ "数据为："+ entrustOrder);
            log.info(">>>>>>>>>>>>>>>>>>>>>end>>>>>>>>>>>>>>>>>>>>>>>>");
            orders.add(entrustOrder);
        }
        return R.data(orders);
    }
}
