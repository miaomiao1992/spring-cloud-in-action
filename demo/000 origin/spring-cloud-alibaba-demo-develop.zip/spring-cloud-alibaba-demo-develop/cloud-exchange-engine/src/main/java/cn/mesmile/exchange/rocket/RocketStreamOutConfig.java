package cn.mesmile.exchange.rocket;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.context.annotation.Configuration;

/**
 * @author zb
 * @date 2022/3/22 16:59
 * @Description 开启 stream 开发
 */
@Configuration
@EnableBinding(value = Source.class)
public class RocketStreamOutConfig {

}
