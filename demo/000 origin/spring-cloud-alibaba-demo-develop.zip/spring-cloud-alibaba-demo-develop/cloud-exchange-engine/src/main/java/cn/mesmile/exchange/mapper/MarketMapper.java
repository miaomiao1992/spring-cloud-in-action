package cn.mesmile.exchange.mapper;

import cn.mesmile.exchange.entity.Market;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 交易对配置信息 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
public interface MarketMapper extends BaseMapper<Market> {

}
