package cn.mesmile.exchange.service;

import cn.mesmile.exchange.entity.TurnoverRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 成交数据 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
public interface TurnoverRecordService extends IService<TurnoverRecord> {

    /**
     * 分页查找成交数据
     * @param page 分页信息
     * @return
     */
    Page<TurnoverRecord> findTurnoverRecordPage(Page<TurnoverRecord> page);
}

