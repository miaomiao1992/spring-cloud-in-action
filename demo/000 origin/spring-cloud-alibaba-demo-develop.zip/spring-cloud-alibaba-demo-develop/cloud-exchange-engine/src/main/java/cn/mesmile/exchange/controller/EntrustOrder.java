package cn.mesmile.exchange.controller;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 临时测试 委托单发送参数
 */
@Data
public class EntrustOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("订单ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户ID")
    private Long userId;

    @ApiModelProperty("市场ID")
    private Long marketId;

    @ApiModelProperty("市场类型（1：币币交易，2：创新交易）")
    private Integer marketType;

    @ApiModelProperty("交易对标识符")
    private String symbol;

    @ApiModelProperty("交易市场")
    private String marketName;

    @ApiModelProperty("委托价格")
    private BigDecimal price;

    @ApiModelProperty("合并深度价格1")
    private BigDecimal mergeLowPrice;

    @ApiModelProperty("合并深度价格2")
    private BigDecimal mergeHighPrice;

    @ApiModelProperty("委托数量")
    private BigDecimal volume;

    @ApiModelProperty("委托总额")
    private BigDecimal amount;

    @ApiModelProperty("手续费比率")
    private BigDecimal feeRate;

    @ApiModelProperty("交易手续费")
    private BigDecimal fee;

    @ApiModelProperty("合约单位")
    private Integer contractUnit;

    @ApiModelProperty("成交数量")
    private BigDecimal deal;

    @ApiModelProperty("冻结量")
    private BigDecimal freeze;

    @ApiModelProperty("保证金比例")
    private BigDecimal marginRate;

    @ApiModelProperty("基础货币对（USDT/BTC）兑换率")
    private BigDecimal baseCoinRate;

    @ApiModelProperty("报价货币对（USDT/BTC)兑换率")
    private BigDecimal priceCoinRate;

    @ApiModelProperty("占用保证金")
    private BigDecimal lockMargin;

    @ApiModelProperty("价格类型：1-市价；2-限价")
    private Integer priceType;

    @ApiModelProperty("交易类型：1-开仓；2-平仓")
    private Integer tradeType;

    @ApiModelProperty("买卖类型：1-买入；2-卖出	2 卖出	")
    private Integer type;

    @ApiModelProperty("平仓委托关联单号")
    private Long openOrderId;

    @ApiModelProperty("status	0未成交	1已成交	2已取消	4异常单")
    private Integer status;

    @TableField(value = "last_update_time", fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @TableField(value = "created", fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;


}