package cn.mesmile.exchange.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.exchange.service.TurnoverOrderService;
import cn.mesmile.exchange.entity.TurnoverOrder;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 成交订单 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
@Api(value = "成交订单相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/exchange/turnover-order")
public class TurnoverOrderController {

    private final TurnoverOrderService turnoverOrderService;

    @ApiOperation("分页查询成交订单")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<TurnoverOrder>> findTurnoverOrderPage(@ApiIgnore Page<TurnoverOrder> page){
        Page<TurnoverOrder> result = turnoverOrderService.findTurnoverOrderPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增成交订单")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "turnoverOrder", value = "turnoverOrder对象的json数据")
    })
    public R save(@RequestBody TurnoverOrder turnoverOrder){
        boolean save = turnoverOrderService.save(turnoverOrder);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改成交订单")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "turnoverOrder", value = "turnoverOrder对象的json数据")
    })
    public R update(@RequestBody TurnoverOrder turnoverOrder){
        boolean update = turnoverOrderService.updateById(turnoverOrder);
        return R.status(update);
    }

    @ApiOperation("删除成交订单")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = turnoverOrderService.removeByIds(ids);
        return R.data(delete);
    }
}
