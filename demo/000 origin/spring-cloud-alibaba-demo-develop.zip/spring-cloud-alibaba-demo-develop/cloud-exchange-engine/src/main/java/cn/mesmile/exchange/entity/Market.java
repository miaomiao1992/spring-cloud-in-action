package cn.mesmile.exchange.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 交易对配置信息
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
@Data
@TableName("market")
@ApiModel(value = "Market对象", description = "交易对配置信息")
public class Market implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("市场ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("类型：1-数字货币；2：创新交易")
    private Integer type;

    @ApiModelProperty("交易区域ID")
    private Long tradeAreaId;

    @ApiModelProperty("卖方市场ID")
    private Long sellCoinId;

    @ApiModelProperty("买方币种ID")
    private Long buyCoinId;

    @ApiModelProperty("交易对标识")
    private String symbol;

    @ApiModelProperty("名称")
    private String name;

    @ApiModelProperty("标题")
    private String title;

    @ApiModelProperty("市场logo")
    private String img;

    @ApiModelProperty("开盘价格")
    private BigDecimal openPrice;

    @ApiModelProperty("买入手续费率")
    private BigDecimal feeBuy;

    @ApiModelProperty("卖出手续费率")
    private BigDecimal feeSell;

    @ApiModelProperty("保证金占用比例")
    private BigDecimal marginRate;

    @ApiModelProperty("单笔最小委托量")
    private BigDecimal numMin;

    @ApiModelProperty("单笔最大委托量")
    private BigDecimal numMax;

    @ApiModelProperty("单笔最小成交额")
    private BigDecimal tradeMin;

    @ApiModelProperty("单笔最大成交额")
    private BigDecimal tradeMax;

    @ApiModelProperty("价格小数位")
    private Integer priceScale;

    @ApiModelProperty("数量小数位")
    private Integer numScale;

    @ApiModelProperty("合约单位")
    private Integer contractUnit;

    @ApiModelProperty("点")
    private BigDecimal pointValue;

    @ApiModelProperty("合并深度（格式：4,3,2）4:表示为0.0001；3：表示为0.001")
    private String mergeDepth;

    @ApiModelProperty("交易时间")
    private String tradeTime;

    @ApiModelProperty("交易周期")
    private String tradeWeek;

    @ApiModelProperty("排序列")
    private Integer sort;

    @ApiModelProperty("状态	0禁用	1启用")
    private Boolean status;

    @ApiModelProperty("福汇API交易对")
    private String fxcmSymbol;

    @ApiModelProperty("对应雅虎金融API交易对")
    private String yahooSymbol;

    @ApiModelProperty("对应阿里云API交易对")
    private String aliyunSymbol;

    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @ApiModelProperty("创建时间")
    private Date created;


}
