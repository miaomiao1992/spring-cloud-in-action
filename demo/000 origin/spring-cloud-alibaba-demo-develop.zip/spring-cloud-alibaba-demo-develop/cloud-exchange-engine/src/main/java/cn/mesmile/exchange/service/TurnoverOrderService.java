package cn.mesmile.exchange.service;

import cn.mesmile.exchange.entity.TurnoverOrder;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 成交订单 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
public interface TurnoverOrderService extends IService<TurnoverOrder> {

    /**
     * 分页查找成交订单
     * @param page 分页信息
     * @return
     */
    Page<TurnoverOrder> findTurnoverOrderPage(Page<TurnoverOrder> page);
}

