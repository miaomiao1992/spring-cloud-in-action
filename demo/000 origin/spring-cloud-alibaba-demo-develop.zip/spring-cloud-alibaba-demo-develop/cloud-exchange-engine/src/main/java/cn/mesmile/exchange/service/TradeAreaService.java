package cn.mesmile.exchange.service;

import cn.mesmile.exchange.entity.TradeArea;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 交易区 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
public interface TradeAreaService extends IService<TradeArea> {

    /**
     * 分页查找交易区
     * @param page 分页信息
     * @return
     */
    Page<TradeArea> findTradeAreaPage(Page<TradeArea> page);
}

