package cn.mesmile.exchange.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.exchange.service.EntrustOrderService;
import cn.mesmile.exchange.entity.EntrustOrder;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 委托订单信息 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
@Api(value = "委托订单信息相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/exchange/entrust-order")
public class EntrustOrderController {

    private final EntrustOrderService entrustOrderService;

    @ApiOperation("分页查询委托订单信息")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<EntrustOrder>> findEntrustOrderPage(@ApiIgnore Page<EntrustOrder> page){
        Page<EntrustOrder> result = entrustOrderService.findEntrustOrderPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增委托订单信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "entrustOrder", value = "entrustOrder对象的json数据")
    })
    public R save(@RequestBody EntrustOrder entrustOrder){
        boolean save = entrustOrderService.save(entrustOrder);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改委托订单信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "entrustOrder", value = "entrustOrder对象的json数据")
    })
    public R update(@RequestBody EntrustOrder entrustOrder){
        boolean update = entrustOrderService.updateById(entrustOrder);
        return R.status(update);
    }

    @ApiOperation("删除委托订单信息")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = entrustOrderService.removeByIds(ids);
        return R.data(delete);
    }
}
