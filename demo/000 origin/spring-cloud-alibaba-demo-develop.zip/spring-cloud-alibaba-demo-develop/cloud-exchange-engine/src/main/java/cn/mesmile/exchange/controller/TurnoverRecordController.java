package cn.mesmile.exchange.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.exchange.service.TurnoverRecordService;
import cn.mesmile.exchange.entity.TurnoverRecord;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 成交数据 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-21
 */
@Api(value = "成交数据相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/exchange/turnover-record")
public class TurnoverRecordController {

    private final TurnoverRecordService turnoverRecordService;

    @ApiOperation("分页查询成交数据")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<TurnoverRecord>> findTurnoverRecordPage(@ApiIgnore Page<TurnoverRecord> page){
        Page<TurnoverRecord> result = turnoverRecordService.findTurnoverRecordPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增成交数据")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "turnoverRecord", value = "turnoverRecord对象的json数据")
    })
    public R save(@RequestBody TurnoverRecord turnoverRecord){
        boolean save = turnoverRecordService.save(turnoverRecord);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改成交数据")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "turnoverRecord", value = "turnoverRecord对象的json数据")
    })
    public R update(@RequestBody TurnoverRecord turnoverRecord){
        boolean update = turnoverRecordService.updateById(turnoverRecord);
        return R.status(update);
    }

    @ApiOperation("删除成交数据")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = turnoverRecordService.removeByIds(ids);
        return R.data(delete);
    }
}
