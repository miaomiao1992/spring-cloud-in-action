package cn.mesmile.product.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * @author zb
 * @date 2022/2/20 20:35
 * @Description
 */
@ApiModel(value = "订单", description = "订单信息")
@Data
@TableName("t_product")
public class Product implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(type = IdType.ASSIGN_ID)
    private Long id;

    @ApiModelProperty(value = "产品名称", example = "名称", notes = "分布式", required = false)
    private String productName;

    @ApiModelProperty(value = "库存", example = "1", notes = "商品库存", required = false)
    private Long stock;

    @ApiModelProperty(value = "单价", example = "1", notes = "总计金额，单位分", required = false)
    private Long price;

    /**
     * DateTimeFormat 入参格式化
     * JsonFormat     出参格式化
     */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @ApiModelProperty(value = "创建时间", example = "", notes = "1标识支付，0标识未支付", required = false)
    private Date createTime;

}
