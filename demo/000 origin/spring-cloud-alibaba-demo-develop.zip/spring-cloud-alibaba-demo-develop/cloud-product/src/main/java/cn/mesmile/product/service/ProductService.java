package cn.mesmile.product.service;


import cn.mesmile.product.entity.Product;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @author zb
 * @date 2022/2/20 20:44
 * @Description
 */
public interface ProductService extends IService<Product> {


    /**
     * 更新库存
     * @param productId
     * @param number
     * @return
     */
    boolean updateStockById(Long productId, Long number);
}
