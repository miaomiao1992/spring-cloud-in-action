package cn.mesmile.product.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.product.entity.Product;
import cn.mesmile.product.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

/**
 * @author zb
 * @date 2022/2/20 20:44
 * @Description
 */
@RequestMapping("/v1/product")
@RequiredArgsConstructor
@RestController
public class ProductController {

    private final ProductService productService;

    @PostMapping("/save")
    public R saveOrder(@RequestBody Product product){
        product.setCreateTime(new Date());
        boolean save = productService.save(product);
        return R.status(save);
    }

    @GetMapping("/list")
    public R listProduct(){
        List<Product> list = productService.list();
        return R.data(list);
    }

    @GetMapping("/get/{productId}")
    public R<Product> getProduct(@PathVariable("productId")Long productId){
        Product product = productService.getById(productId);
        return R.data(product);
    }

    @PostMapping("/update/{productId}/{number}")
    public R updateProduct(@PathVariable("productId")Long productId,@PathVariable("number")Long number){
        boolean b = productService.updateStockById(productId, number);
        return R.status(b);
    }



}
