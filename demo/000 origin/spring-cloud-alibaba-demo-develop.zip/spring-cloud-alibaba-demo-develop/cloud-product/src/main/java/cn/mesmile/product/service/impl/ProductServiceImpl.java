package cn.mesmile.product.service.impl;

import cn.mesmile.product.entity.Product;
import cn.mesmile.product.mapper.ProductMapper;
import cn.mesmile.product.service.ProductService;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.seata.spring.annotation.GlobalTransactional;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author zb
 * @date 2022/2/20 20:44
 * @Description
 */
@Transactional(propagation = Propagation.SUPPORTS,rollbackFor = Exception.class,readOnly = true)
@Service
public class ProductServiceImpl extends ServiceImpl<ProductMapper, Product> implements ProductService {

//    @GlobalTransactional(rollbackFor = Exception.class)
    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updateStockById(Long productId, Long number) {
        LambdaUpdateWrapper<Product> productLambdaUpdateWrapper = Wrappers.<Product>lambdaUpdate()
                .eq(Product::getId, productId)
                .setSql("stock = stock - " + number);
        boolean update = update(productLambdaUpdateWrapper);
//        int a = 1/0;
        return update;
    }

}
