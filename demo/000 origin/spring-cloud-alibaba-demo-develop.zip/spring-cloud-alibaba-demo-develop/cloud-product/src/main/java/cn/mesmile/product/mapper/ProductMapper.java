package cn.mesmile.product.mapper;


import cn.mesmile.product.entity.Product;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author zb
 * @date 2022/2/20 20:45
 * @Description
 */
public interface ProductMapper extends BaseMapper<Product> {

}
