package cn.mesmile.product.config;

/**
 * @author zb
 * @date 2022/2/20 20:48
 * @Description
 */
public class ProductConfig {
}
