package cn.mesmile.system.feign;

import cn.mesmile.common.constant.ApplicationConstant;
import cn.mesmile.common.result.R;
import cn.mesmile.system.entity.User;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Set;

/**
 * @author zb
 * @date 2022/3/14 10:26
 * @Description
 */
@FeignClient(value = ApplicationConstant.SYSTEM_APPLICATION_NAME, fallback = SystemFeignClientFallback.class)
public interface SystemFeignClient {

    String API_PREFIX = "/client";
    String LIST_PERMISSION = API_PREFIX + "/listPermission";
    String GET_USER_BY_NAME = API_PREFIX + "/getUserByName";

    /**
     * 根据用户id获取权限列表
     * @param userId 用户id
     * @return 权限列表
     */
    @GetMapping(LIST_PERMISSION)
    R<Set<String>> listPermission(@RequestParam("userId") Long userId);

    /**
     * 根据登录用户名获取用户
     * @param username 登录用户名
     * @return 用户
     */
    @GetMapping(GET_USER_BY_NAME)
    R<User> getUserByName(@RequestParam("username")String username);


}
