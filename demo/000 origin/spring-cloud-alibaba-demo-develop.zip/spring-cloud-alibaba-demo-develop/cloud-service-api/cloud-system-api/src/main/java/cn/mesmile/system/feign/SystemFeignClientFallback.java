package cn.mesmile.system.feign;

import cn.mesmile.common.result.R;
import cn.mesmile.system.entity.User;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * @author zb
 * @date 2022/3/14 10:26
 * @Description
 */
@Component
public class SystemFeignClientFallback implements SystemFeignClient{

    @Override
    public R<Set<String>> listPermission(Long userId) {
        return R.fail("查询权限失败");
    }

    @Override
    public R<User> getUserByName(String username) {
        return R.fail("查询用户失败");
    }

}
