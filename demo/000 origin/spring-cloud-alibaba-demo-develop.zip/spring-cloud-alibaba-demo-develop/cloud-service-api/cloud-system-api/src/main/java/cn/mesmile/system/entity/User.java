package cn.mesmile.system.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * @author zb
 * @date 2022/2/20 19:29
 * @Description
 */
@ApiModel(value = "用户", description = "用户信息")
@Data
@TableName(value = "cloud_user")
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    @JsonSerialize(using = ToStringSerializer.class)
    @TableId(type = IdType.ASSIGN_ID)
    private Long id;

    @ApiModelProperty(value = "用户名", example = "张三", notes = "用户名", required = true)
    private String username;

    @ApiModelProperty(value = "密码", example = "123456", notes = "用户名", required = true)
    private String password;

    @ApiModelProperty(value = "昵称", example = "张三", notes = "昵称", required = true)
    private String nickname;

    @ApiModelProperty(value = "真实姓名", example = "张三", notes = "真实姓名", required = true)
    private String realName;

    @ApiModelProperty(value = "性别", example = "1", notes = "性别 0女 1男 2未知", required = false)
    private Integer sex;

    @ApiModelProperty(value = "部门id", example = "12312321", notes = "用户名", required = false)
    private Long deptId;

    @ApiModelProperty(value = "是否可用", example = "", notes = "是否可用", required = false)
    private Boolean enabled;

    @ApiModelProperty(value = "电话号码", example = "15760081234", notes = "电话号码", required = false)
    private String phone;

    @ApiModelProperty(value = "邮箱", example = "wechat123", notes = "微信号", required = false)
    private String email;

    /**
     * DateTimeFormat 入参格式化
     * JsonFormat     出参格式化
     */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @ApiModelProperty(value = "创建时间", example = "张三", notes = "创建时间", required = false)
    private Date createTime;

    /**
     * DateTimeFormat 入参格式化
     * JsonFormat     出参格式化
     */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @ApiModelProperty(value = "修改时间", example = "张三", notes = "修改时间", required = false)
    private Date updateTime;

}
