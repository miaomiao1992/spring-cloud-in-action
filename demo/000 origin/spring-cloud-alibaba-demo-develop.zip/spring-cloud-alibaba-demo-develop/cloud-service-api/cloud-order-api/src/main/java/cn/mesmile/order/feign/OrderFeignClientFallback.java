package cn.mesmile.order.feign;

import cn.mesmile.common.result.R;
import org.springframework.stereotype.Component;

/**
 * @author zb
 * @date 2022/3/14 10:50
 * @Description
 */
@Component
public class OrderFeignClientFallback implements OrderFeignClient {

    @Override
    public R listOrder() {
        // 请求另外服务出错就会进入到这里的兜底方法
        return R.fail("获取数据失败了，这是兜底数据哦。。。");
    }

}
