package cn.mesmile.order.feign;

import cn.mesmile.common.constant.ApplicationConstant;
import cn.mesmile.common.result.R;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author zb
 * @date 2022/3/14 10:50
 * @Description
 * *  服务降级-》进而熔断-》恢复调用链路
 * *  服务降级 fallback
 */
@FeignClient(value = ApplicationConstant.ORDER_APPLICATION_NAME, fallback = OrderFeignClientFallback.class)
public interface OrderFeignClient {

    /**
     *  获取订单列表
     * @return
     */
    @GetMapping("/v1/order/list")
    R listOrder();

}
