package cn.mesmile.auth.feign;

import org.springframework.cloud.openfeign.FeignClient;

/**
 * @author zb
 * @date 2022/3/13 21:35
 * @Description
 */
//@FeignClient
public interface UserFeignClient {


}
