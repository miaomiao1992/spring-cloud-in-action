package cn.mesmile.auth.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * @author zb
 * @date 2022/3/13 14:57
 * @Description
 */
@Configuration
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }

    @Bean
    @Override
    public AuthenticationManager authenticationManager() throws Exception {
        return super.authenticationManager();
    }

//    @Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http.requestMatcher(EndpointRequest.toAnyEndpoint())
//                .authorizeRequests((requests) -> requests.anyRequest().hasRole("ENDPOINT_ADMIN"));
//        http.httpBasic();
//        return http.build();
//    }


    @Override
    protected void configure(HttpSecurity http) throws Exception {
//        super.configure(http);
        http.csrf().disable()
                .authorizeRequests().anyRequest().authenticated();
    }

    // 内存中存放一个用户
    // @Bean
    // @Override
    // public UserDetailsService userDetailsService(){
    //     InMemoryUserDetailsManager userDetailsManager = new InMemoryUserDetailsManager();
    //     User user = new User("test",passwordEncoder().encode("123"),new ArrayList<>());
    //     userDetailsManager.createUser(user);
    //     return userDetailsManager;
    // }

}
