package cn.mesmile.auth.constant;

/**
 * @author zb
 * @date 2022/3/14 14:18
 * @Description
 */
public interface LoginConstant {

    String LOGIN_TYPE = "login_type";

    String ADMIN_TYPE = "admin";

    String MEMBER_TYPE = "member";


}
