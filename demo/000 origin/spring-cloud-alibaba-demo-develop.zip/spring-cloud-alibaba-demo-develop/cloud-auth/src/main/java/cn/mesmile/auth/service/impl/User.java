package cn.mesmile.auth.service.impl;

import lombok.Data;

/**
 * @author zb
 * @date 2022/3/15 15:26
 * @Description
 */
@Data
public class User {

    private String username;

    private String password;

}
