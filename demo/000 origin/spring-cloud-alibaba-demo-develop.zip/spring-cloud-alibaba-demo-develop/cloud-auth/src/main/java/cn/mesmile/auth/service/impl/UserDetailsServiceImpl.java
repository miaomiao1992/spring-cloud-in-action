package cn.mesmile.auth.service.impl;

import cn.mesmile.auth.constant.LoginConstant;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.HashSet;
import java.util.Set;

/**
 * @author zb
 * @date 2022/3/13 21:20
 * @Description
 */
@Primary
@RequiredArgsConstructor
@Service("userDetailsServiceImpl")
public class UserDetailsServiceImpl implements UserDetailsService {

    // private final SystemFeignClient systemFeignClient;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes)RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = requestAttributes.getRequest();
        String loginType = request.getParameter(LoginConstant.LOGIN_TYPE);
        // if (StringUtils.isEmpty(loginType)){
        //     throw new ServiceException("登录类型不能为空");
        // }
        // 查询用户
//        R<User> userResult = systemFeignClient.getUserByName(username);
//        if (userResult.getCode() != ResultCode.SUCCESS.getCode()) {
//            throw new ServiceException("查询用户异常");
//        }
//        User user = userResult.getData();
//        if (user == null) {
//            throw new ServiceException("用户名或密码错误");
//        }
//        // 查询权限
//        R<Set<String>> permissionR = systemFeignClient.listPermission(user.getId());
//        if (permissionR.getCode() != ResultCode.SUCCESS.getCode()){
//            throw new ServiceException("登录异常");
//        }
//        Set<String> permissionSet = permissionR.getData();
        User user = new User();
        user.setUsername(username);
        user.setPassword(new BCryptPasswordEncoder().encode("123"));
        Set<String> permissionSet = new HashSet<>();
        permissionSet.add("admin:add");
        permissionSet.add("admin:select");
        return new LoginUserImpl(user, permissionSet);
    }

}
