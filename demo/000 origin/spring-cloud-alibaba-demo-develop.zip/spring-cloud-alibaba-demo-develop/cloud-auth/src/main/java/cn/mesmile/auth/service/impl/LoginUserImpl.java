package cn.mesmile.auth.service.impl;

import com.alibaba.fastjson.annotation.JSONField;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author zb
 * @date 2022/3/13 21:20
 * @Description
 */
@NoArgsConstructor
@Data
public class LoginUserImpl implements UserDetails {

    /**
     * 用户
     */
    private User user;

    /**
     * 权限集合
     */
    private Set<String> permissionSet;

    public LoginUserImpl(User user, Set<String> permissionSet){
        this.user = user;
        this.permissionSet = permissionSet;
    }

    /**
     * 此变量无需序列化
     */
    @JSONField(serialize = false)
    private Set<SimpleGrantedAuthority> grantedAuthorities;

    /**
     * 返回用户的授权信息
     * @return
     */
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        if (grantedAuthorities != null){
            return grantedAuthorities;
        }
        grantedAuthorities = permissionSet.stream()
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toSet());
        return grantedAuthorities;
    }

    /**
     *  返回用户密码
     * @return
     */
    @Override
    public String getPassword() {
        return user.getPassword();
    }

    /**
     * 返回用户名
     * @return
     */
    @Override
    public String getUsername() {
        return user.getUsername();
    }

    /**
     * 判断账号是否 没过期
     * @return
     */
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    /**
     * 判断账号是否 没锁定
     * @return
     */
    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    /**
     * 证书是否 没过期
     * @return
     */
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    /**
     * 是否可用
     * @return
     */
    @Override
    public boolean isEnabled() {
        return true;
    }
}