package cn.mesmile.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @author zb
 * @date 2022/3/5 12:29
 * @Description  认证服务器
 *          post  localhost:8003/oauth/token?grant_type=password&username=test&password=123
 *          Basic Auth   username    password
 *
 *          {
 *              "access_token": "0797fb33-026f-4a26-9e60-02bc247376e7",
 *              "token_type": "bearer",
 *              "expires_in": 3542,
 *              "scope": "all"
 *          }
 *
 *         https://gitee.com/Orzxl/coinexchange
 */
// @MapperScan("cn.mesmile.auth.mapper")
@EnableFeignClients(basePackages = {"cn.mesmile"})
@EnableDiscoveryClient
@SpringBootApplication(scanBasePackages = {"cn.mesmile"})
public class AuthApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuthApplication.class, args);
    }

}
