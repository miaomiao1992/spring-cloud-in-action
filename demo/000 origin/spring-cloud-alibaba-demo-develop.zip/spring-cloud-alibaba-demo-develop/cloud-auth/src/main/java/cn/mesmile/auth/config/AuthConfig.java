package cn.mesmile.auth.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.security.oauth2.provider.token.store.KeyStoreKeyFactory;

import java.security.KeyPair;

/**
 * @author zb
 * @date 2022/3/13 14:44
 * @Description  标识此服务为  授权服务器
 */
// @SuppressWarnings("all")
@Configuration
@EnableAuthorizationServer
public class AuthConfig extends AuthorizationServerConfigurerAdapter {

    public AuthConfig(AuthenticationManager authenticationManager, UserDetailsService userDetailsService, PasswordEncoder passwordEncoder) {
        this.authenticationManager = authenticationManager;
        this.userDetailsService = userDetailsService;
        this.passwordEncoder = passwordEncoder;
    }

    private final AuthenticationManager authenticationManager;

    @Qualifier("userDetailsServiceImpl")
    private final UserDetailsService userDetailsService;

    private final PasswordEncoder passwordEncoder;

//    private final RedisConnectionFactory redisConnectionFactory;

    /**
     * 添加第三方客户端
     * @param clients
     * @throws Exception
     */
    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
        clients.inMemory()
                .withClient("icon-app") //第三方客户端名称
                .secret(passwordEncoder.encode("icon-secret")) //第三方客户端的秘钥
                .scopes("all") // 第三方客户端的授权范围
                .authorizedGrantTypes("password","refresh_token") // 支持认证授权类型，默认为 password
                .accessTokenValiditySeconds(7 * 24 * 3600) //token有效期
                .refreshTokenValiditySeconds(15 * 24 * 3600) // refresh_token的有效期
                .and()
                .withClient("inside-app")
                .secret(passwordEncoder.encode("inside-secret")) //第三方客户端的秘钥
                .scopes("all") // 第三方客户端的授权范围
                .authorizedGrantTypes("client_credentials") // 支持认证授权类型，默认为 password
                .accessTokenValiditySeconds(7 * 24 * 3600) //token有效期
                .refreshTokenValiditySeconds(15 * 24 * 3600); // refresh_token的有效期
        super.configure(clients);
    }

    /**
     * 配置验证管理器
     * @param endpoints
     * @throws Exception
     */
    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
        endpoints.authenticationManager(authenticationManager)
                .userDetailsService(userDetailsService)
                .tokenStore(tokenStore())
                .tokenEnhancer(jwtAccessTokenConverter());

        super.configure(endpoints);
    }

//    @Bean
//    public TokenStore tokenStore(){
//        return new RedisTokenStore(redisConnectionFactory);
//    }

    @Bean
    public TokenStore tokenStore(){
        JwtTokenStore jwtTokenStore = new JwtTokenStore(jwtAccessTokenConverter());
        return jwtTokenStore;
    }

    public JwtAccessTokenConverter jwtAccessTokenConverter(){
        JwtAccessTokenConverter jwtAccessTokenConverter = new JwtAccessTokenConverter();
        // 加载私钥
        ClassPathResource classPathResource = new ClassPathResource("coinexchange.jks");
        KeyStoreKeyFactory keyStoreKeyFactory = new KeyStoreKeyFactory(classPathResource, "coinexchange".toCharArray());
        KeyPair coinexchange = keyStoreKeyFactory.getKeyPair("coinexchange", "coinexchange".toCharArray());
        jwtAccessTokenConverter.setKeyPair(coinexchange);
        return jwtAccessTokenConverter;
    }




}
