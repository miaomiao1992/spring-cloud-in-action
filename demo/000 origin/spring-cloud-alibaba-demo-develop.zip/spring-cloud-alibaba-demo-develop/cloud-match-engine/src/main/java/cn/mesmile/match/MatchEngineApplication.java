package cn.mesmile.match;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @author zb
 * @date 2022/3/21 17:26
 * @Description 撮合引擎
 *      https://www.bilibili.com/video/BV1YR4y1J7Uq?p=150&spm_id_from=pageDriver
 */
@EnableFeignClients(basePackages = {"cn.mesmile"})
@MapperScan("cn.mesmile.match.mapper")
@EnableDiscoveryClient
@SpringBootApplication(scanBasePackages = {"cn.mesmile"})
public class MatchEngineApplication {

    public static void main(String[] args) {
        SpringApplication.run(MatchEngineApplication.class, args);
    }

}
