package cn.mesmile.match.engine;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Map;

/**
 * @author zb
 * @date 2022/3/22 11:01
 * @Description
 */
@Data
@ConfigurationProperties(prefix = "spring.match")
public class MatchEngineProperties {

    /**
     * 交易对信息
     */
    private Map<String, CoinScale> symbol;


    @Data
    public static class CoinScale {
        /**
         *  交易币种的精度
         */
        private int coinScale;

        /**
         * 货币的精度
         */
        private int baseCoinScale;
    }


}
