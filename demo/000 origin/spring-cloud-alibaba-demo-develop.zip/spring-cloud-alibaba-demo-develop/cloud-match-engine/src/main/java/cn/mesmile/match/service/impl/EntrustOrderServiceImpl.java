package cn.mesmile.match.service.impl;

import cn.mesmile.match.entity.EntrustOrder;
import cn.mesmile.match.mapper.EntrustOrderMapper;
import cn.mesmile.match.service.EntrustOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 委托订单信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-22
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class EntrustOrderServiceImpl extends ServiceImpl<EntrustOrderMapper, EntrustOrder> implements EntrustOrderService {

    @Override
    public Page<EntrustOrder> findEntrustOrderPage(Page<EntrustOrder> page) {
        Page<EntrustOrder> result = page(page);
        return result;
    }
}
