package cn.mesmile.match.handler;

import cn.mesmile.match.disruptor.OrderEvent;
import cn.mesmile.match.engine.MatchServiceFactory;
import cn.mesmile.match.enums.MatchStrategyEnum;
import cn.mesmile.match.model.Order;
import cn.mesmile.match.model.OrderBooks;
import com.lmax.disruptor.EventHandler;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.Objects;

/**
 * @author zb
 * @date 2022/3/21 23:15
 * @Description
 *
 *          该对象 有多个，和symbol的数据对应
 *          针对某一个 OrderEventHandler 只会同一时间有一个线程来执行它
 */
@Data
@Slf4j
public class OrderEventHandler implements EventHandler<OrderEvent> {

    private OrderBooks orderBooks;

    private String symbol;

    public OrderEventHandler(OrderBooks orderBooks){
        this.orderBooks = orderBooks;
        this.symbol = this.orderBooks.getSymbol();
    }

    /**
     *  接受到了某个消息
     * @param event
     * @param sequence
     * @param endOfBatch
     * @throws Exception
     */
    @Override
    public void onEvent(OrderEvent event, long sequence, boolean endOfBatch) throws Exception {
        // 从 ringBuffer里面接收到数据，需要判断 symbol 是否为该对象需要处理的类型

        Object source = event.getSource();
        if (!(source instanceof Order)){
            return;
        }
        //
        if (!Objects.equals(symbol, ((Order) source).getSymbol())){
            // 这里从 ringBuffer 里面接收到了不属于这里处理的数据
            return;
        }

        log.info("开始接收订单事件 ========》{}", event);


        // todo 处理逻辑
        MatchServiceFactory.getMatchService(MatchStrategyEnum.LIMIT_PRICE).match(orderBooks, (Order) source );

        log.info("处理完成订单事件 ========》{}", event);
    }
}
