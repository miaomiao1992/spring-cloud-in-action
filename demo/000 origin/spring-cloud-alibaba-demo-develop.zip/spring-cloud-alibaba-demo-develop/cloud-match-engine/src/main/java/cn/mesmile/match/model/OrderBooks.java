package cn.mesmile.match.model;

import cn.mesmile.match.enums.OrderDirectionEnum;
import lombok.Data;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author zb
 * @date 2022/3/22 9:53
 * @Description
 */
@Data
public class OrderBooks {

    /**
     *  买入限价交易，价格从高到低
     *  价格越高，越容易买到
     *  key 价格
     *  mergeOrder 价格相同的订单(key相同)，订单按照时间排序
     */
    private TreeMap<BigDecimal, MergeOrder> buyLimitPrice;

    /**
     * 卖出的限价交易，价格从低到高
     * 价格越低，卖出越容易
     * key 价格
     * mergeOrder 价格相同的订单(key相同)，订单按照时间排序
     */
    private TreeMap<BigDecimal, MergeOrder> sellLimitPrice;

    /**
     *  交易币种
     */
    private String symbol;

    /**
     *  交易币种的精度
     */
    private int coinScale;

    /**
     * 货币的精度
     */
    private int baseCoinScale;

    /**
     * 日期格式器
     */
    private SimpleDateFormat dateFormat;

    public OrderBooks(String symbol){
        this(symbol, 4 , 4);
    }

    public OrderBooks(String symbol, int coinScale, int baseCoinScale){
        this.symbol = symbol;
        this.coinScale = coinScale;
        this.baseCoinScale = baseCoinScale;
        this.initialize();
    }

    public void initialize(){
        // 从高到低
        buyLimitPrice = new TreeMap<>(Comparator.reverseOrder());
        // 从低到高
        sellLimitPrice = new TreeMap<>(Comparator.naturalOrder());

        dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    }

    /**
     * 获取当前交易队列
     * @param orderDirectionEnum
     * @return
     */
    public TreeMap<BigDecimal, MergeOrder> getCurrentLimitPrice(OrderDirectionEnum orderDirectionEnum){
        return orderDirectionEnum == OrderDirectionEnum.BUY ? this.buyLimitPrice : this.sellLimitPrice;
    }


    public Iterator<Map.Entry<BigDecimal, MergeOrder>> getCurrentLimitPriceIterator(OrderDirectionEnum orderDirectionEnum){
        return getCurrentLimitPrice(orderDirectionEnum).entrySet().iterator();
    }

    /**
     * 添加订单
     * @param order
     */
    public void addOrder(Order order){
        TreeMap<BigDecimal, MergeOrder> currentLimitPrice = getCurrentLimitPrice(OrderDirectionEnum.getOrderDirectionEnum(order.getOrderDirection()));
        MergeOrder mergeOrder = currentLimitPrice.get(order.getPrice());
        if (mergeOrder == null){
            // 之前没有相同价格的订单，无需合并
            mergeOrder = new MergeOrder();
            // 添加节点
            currentLimitPrice.put(order.getPrice(), mergeOrder);
        }
        // 添加订单
        mergeOrder.addOrder(order);
    }

    /**
     * 取消订单
     * @param order
     */
    public void cancelOrder(Order order){
        TreeMap<BigDecimal, MergeOrder> currentLimitPrice = getCurrentLimitPrice(OrderDirectionEnum.getOrderDirectionEnum(order.getOrderDirection()));
        MergeOrder mergeOrder = currentLimitPrice.get(order.getPrice());
        if (mergeOrder == null || mergeOrder.size() <= 0){
            return;
        }
        Iterator<Order> iterator = mergeOrder.iterator();
        while (iterator.hasNext()){
            Order nextOrder = iterator.next();
            if (Objects.equals(nextOrder.getOrderId(), order.getOrderId())){
                // 删除订单
                iterator.remove();
            }
        }
        // 检查合并订单是否为0
        int size = mergeOrder.size();
        if (size == 0){
            currentLimitPrice.remove(order.getPrice());
        }
    }

    /**
     * 获取排在队列里面的第一个数据
     * @param orderDirectionEnum
     * @return
     */
    public Map.Entry<BigDecimal, MergeOrder> getFirstOrder(OrderDirectionEnum orderDirectionEnum){
         return getCurrentLimitPrice(orderDirectionEnum).firstEntry();
    }

}
