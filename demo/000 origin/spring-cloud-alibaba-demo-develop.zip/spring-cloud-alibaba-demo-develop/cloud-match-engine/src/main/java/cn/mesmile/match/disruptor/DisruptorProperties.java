package cn.mesmile.match.disruptor;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author zb
 * @date 2022/3/21 18:19
 * @Description 并发编程，高速队列
 */
@Data
@ConfigurationProperties(prefix = "spring.disruptor")
public class DisruptorProperties {


    /**
     *  ringBuffer 缓冲区大小，默认 1024 * 1024
     */
    private int ringBufferSize = 1024 * 1024;

    /**
     * 是否为多生产者，如果是则通过RingBuffer.createMuLtiProducer创建一个多生产者的RingBuffer，
     * 否则通过RingBuffer.createSingleProducer 创建一个单生产者的RingBuffer
     */
    private boolean isMuLtiProducer = false;



}
