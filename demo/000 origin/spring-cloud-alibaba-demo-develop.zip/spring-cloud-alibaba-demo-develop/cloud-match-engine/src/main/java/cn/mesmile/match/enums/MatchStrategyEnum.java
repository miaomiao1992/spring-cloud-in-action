package cn.mesmile.match.enums;

/**
 * @author zb
 * @date 2022/3/22 11:48
 * @Description
 */
public enum  MatchStrategyEnum {

    /**
     * 限价交易
     */
    LIMIT_PRICE,
    /**
     * 市场交易
     */
    MARKER_PRICE;
}
