package cn.mesmile.match.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.match.disruptor.OrderEvent;
import cn.mesmile.match.enums.OrderDirectionEnum;
import cn.mesmile.match.handler.OrderEventHandler;
import cn.mesmile.match.model.MergeOrder;
import cn.mesmile.match.model.OrderBooks;
import com.lmax.disruptor.EventHandler;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.TreeMap;

/**
 * @author zb
 * @date 2022/3/22 15:30
 * @Description
 */
@Api(value = "委托订单信息相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/match/data")
public class MatchController {

    @Autowired
    private EventHandler<OrderEvent> []orderEventEventHandler;

    @GetMapping("/order")
    @ApiOperation("获取交易数据")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "", name = "")
    })
    public R<TreeMap<BigDecimal, MergeOrder>> getTradeData(@RequestParam("symbol") String symbol,@RequestParam("code") Integer code){
        TreeMap<BigDecimal, MergeOrder> currentLimitPrice = null;
        for (EventHandler<OrderEvent> eventEventHandler : orderEventEventHandler) {
            OrderEventHandler orderEventHandler = (OrderEventHandler) eventEventHandler;
            if (Objects.equals(orderEventHandler.getSymbol(), symbol)){
                OrderBooks orderBooks = orderEventHandler.getOrderBooks();
                currentLimitPrice = orderBooks.getCurrentLimitPrice(OrderDirectionEnum.getOrderDirectionEnum(code));
                break;
            }
        }
        return R.data(currentLimitPrice);
    }


}
