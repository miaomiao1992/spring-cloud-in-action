package cn.mesmile.match.disruptor;

import cn.mesmile.match.model.Order;
import com.lmax.disruptor.EventTranslatorOneArg;
import com.lmax.disruptor.RingBuffer;

/**
 * @author zb
 * @date 2022/3/21 19:09
 * @Description
 */
public class DisruptorTemplate {

    private static final EventTranslatorOneArg<OrderEvent, Order> TRANSLATOR = new EventTranslatorOneArg<OrderEvent, Order>() {
        @Override
        public void translateTo(OrderEvent event, long sequence, Order input) {
            event.setSource(input);
        }
    };

    private final RingBuffer<OrderEvent> ringBuffer;

    public DisruptorTemplate(RingBuffer<OrderEvent> ringBuffer){
        this.ringBuffer = ringBuffer;
    }

    /**
     * 发送数据到 ringBuffer
     * @param input
     */
    public void onData(Order input){
        ringBuffer.publishEvent(TRANSLATOR, input);
    }

}
