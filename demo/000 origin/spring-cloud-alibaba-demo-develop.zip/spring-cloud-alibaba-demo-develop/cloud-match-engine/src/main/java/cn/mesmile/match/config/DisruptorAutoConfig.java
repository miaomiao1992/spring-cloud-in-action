package cn.mesmile.match.config;

import cn.mesmile.match.disruptor.DisruptorProperties;
import cn.mesmile.match.disruptor.DisruptorTemplate;
import cn.mesmile.match.disruptor.OrderEvent;
import cn.mesmile.match.handler.DisruptorHandlerException;
import com.lmax.disruptor.*;
import com.lmax.disruptor.dsl.Disruptor;
import com.lmax.disruptor.dsl.ProducerType;
import net.openhft.affinity.AffinityThreadFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ThreadFactory;

/**
 * @author zb
 * @date 2022/3/21 18:25
 * @Description
 */
@Configuration
@EnableConfigurationProperties(DisruptorProperties.class)
public class DisruptorAutoConfig {

    public DisruptorProperties properties;

    public DisruptorAutoConfig(DisruptorProperties properties) {
        this.properties = properties;
    }

    /**
     * final EventFactory<T> eventFactory, 事件工厂
     * final int ringBufferSize,
     * final ThreadFactory threadFactory, (消费者)线程工厂
     * final ProducerType producerType, 生产者类型
     * final WaitStrategy waitStrategy  等待策略： ringBuffer 没有数据的时候怎么办
     *
     * @param threadFactory          线程工厂
     * @param orderEventEventFactory 事件工厂
     * @param waitStrategy           等待策略
     * @param eventHandlers          事件拦截器
     * @return @Qualifier("eventHandlers")
     */

    @Bean
    public RingBuffer<OrderEvent> ringBuffer(ThreadFactory threadFactory, EventFactory<OrderEvent> orderEventEventFactory,
                                             WaitStrategy waitStrategy,
                                              @Qualifier("eventHandlers") EventHandler<OrderEvent>[] eventHandlers) {
        Disruptor<OrderEvent> disruptor = null;
        if (properties.isMuLtiProducer()) {
            disruptor = new Disruptor<OrderEvent>(
                    orderEventEventFactory, properties.getRingBufferSize(),
                    threadFactory, ProducerType.MULTI, waitStrategy);
        } else {
            disruptor = new Disruptor<OrderEvent>(
                    orderEventEventFactory, properties.getRingBufferSize(),
                    threadFactory, ProducerType.SINGLE, waitStrategy);
        }
        // 设置异常拦截器
        disruptor.setDefaultExceptionHandler(new DisruptorHandlerException());

        // 设置消费者,每个消费者 代表 一个交易对
        // 有多少个消费者，就有多少个 eventHandlers，事件来了后 多个eventHandlers是并发执行的
        disruptor.handleEventsWith(eventHandlers);

        RingBuffer<OrderEvent> ringBuffer = disruptor.getRingBuffer();
        // 开始监听
        disruptor.start();

        final Disruptor<OrderEvent> disruptorShutdown = disruptor;
        // 优雅停机
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            disruptorShutdown.shutdown();
        }, "thread-disruptorShutdown-"));

        return ringBuffer;
    }

    @Bean
    public EventFactory<OrderEvent> eventEventFactory() {
        return new EventFactory<OrderEvent>() {
            @Override
            public OrderEvent newInstance() {
                return new OrderEvent();
            }
        };
    }

    @Bean
    public ThreadFactory threadFactory(){
        // cpu亲和锁
        AffinityThreadFactory affinityThreadFactory = new AffinityThreadFactory("match-handler:");
        return affinityThreadFactory;
    }

    /**
     *  YieldingWaitStrategy 无锁高效的等待策略
     * @return
     */
    @Bean
    public WaitStrategy waitStrategy(){
        return new YieldingWaitStrategy();
    }

    @Bean
    public DisruptorTemplate disruptorTemplate(RingBuffer<OrderEvent> ringBuffer){
        return new DisruptorTemplate(ringBuffer);
    }

}
