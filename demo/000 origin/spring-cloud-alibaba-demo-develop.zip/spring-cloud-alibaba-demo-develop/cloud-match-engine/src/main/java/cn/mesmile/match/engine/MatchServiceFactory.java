package cn.mesmile.match.engine;

import cn.mesmile.match.enums.MatchStrategyEnum;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zb
 * @date 2022/3/22 11:25
 * @Description
 */
public class MatchServiceFactory {

    private static Map<MatchStrategyEnum, MatchService> matchServiceMap = new HashMap<>();

    /**
     * 向工厂里面添加一个交易的实现类型
     * @param matchStrategy
     * @param matchService
     */
    public static void addMatchService(MatchStrategyEnum matchStrategy, MatchService matchService){
        matchServiceMap.put(matchStrategy, matchService);
    }

    /**
     * 获取交易实现类型
     * @param matchStrategy
     */
    public static MatchService getMatchService(MatchStrategyEnum matchStrategy){
        return matchServiceMap.get(matchStrategy);
    }

}
