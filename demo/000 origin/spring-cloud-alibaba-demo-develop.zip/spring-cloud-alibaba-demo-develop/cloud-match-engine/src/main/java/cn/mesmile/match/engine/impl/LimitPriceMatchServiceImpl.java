package cn.mesmile.match.engine.impl;

import cn.mesmile.match.engine.MatchService;
import cn.mesmile.match.engine.MatchServiceFactory;
import cn.mesmile.match.enums.MatchStrategyEnum;
import cn.mesmile.match.model.Order;
import cn.mesmile.match.model.OrderBooks;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

/**
 * @author zb
 * @date 2022/3/22 11:22
 * @Description
 */
@Slf4j
@Service
public class LimitPriceMatchServiceImpl implements MatchService, InitializingBean {

    @Override
    public void match(OrderBooks orderBooks, Order order) {

        log.info("开始撮合 ===========> {}", order);

        orderBooks.addOrder(order);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        // 将限价交易放到工厂里面
        MatchServiceFactory.addMatchService(MatchStrategyEnum.LIMIT_PRICE, this);
    }

}
