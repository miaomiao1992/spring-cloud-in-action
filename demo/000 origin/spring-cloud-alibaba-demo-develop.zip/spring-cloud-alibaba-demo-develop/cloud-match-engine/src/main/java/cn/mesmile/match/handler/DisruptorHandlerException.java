package cn.mesmile.match.handler;

import com.lmax.disruptor.ExceptionHandler;
import lombok.extern.slf4j.Slf4j;

/**
 * @author zb
 * @date 2022/3/21 18:27
 * @Description  disruptor 异常拦截
 */
@Slf4j
public class DisruptorHandlerException implements ExceptionHandler<Object> {

    @Override
    public void handleEventException(Throwable throwable, long sequence, Object event) {
        log.error("disruptor 业务异常 Event Exception =====>> {}, sequence =====>> {}, event =====>> {}", throwable.getMessage(), sequence, event);
    }

    @Override
    public void handleOnStartException(Throwable throwable) {
        log.error("OnStart Exception =====>> {}", throwable.getMessage());
    }

    @Override
    public void handleOnShutdownException(Throwable throwable) {
        log.error("OnShutdown Exception =====>> {}", throwable.getMessage());
    }
}
