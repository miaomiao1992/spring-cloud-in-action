package cn.mesmile.match.model;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @author zb
 * @date 2022/3/21 18:58
 * @Description
 */
@Data
public class OrderDetail {

    /** 本次订单的id */
    private String orderId;

    /** 成交价格 */
    private BigDecimal price;

    /** 买入卖出量 */
    private BigDecimal amount;

    /** 成交额 */
    private BigDecimal turnover;

    /** 费率 */
    private BigDecimal free;

    /** 成交时间 */
    private Long dealTime;

}
