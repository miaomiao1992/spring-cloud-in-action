package cn.mesmile.match.rocket;

import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.context.annotation.Configuration;

/**
 * @author zb
 * @date 2022/3/21 23:30
 * @Description 开启 stream 开发
 */
@Configuration
@EnableBinding(Sink.class)
public class RocketStreamConfig {

}
