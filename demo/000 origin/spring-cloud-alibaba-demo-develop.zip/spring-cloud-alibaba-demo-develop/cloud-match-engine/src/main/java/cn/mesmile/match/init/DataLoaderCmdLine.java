package cn.mesmile.match.init;

import cn.hutool.core.collection.CollUtil;
import cn.mesmile.match.disruptor.DisruptorTemplate;
import cn.mesmile.match.entity.EntrustOrder;
import cn.mesmile.match.mapper.EntrustOrderMapper;
import cn.mesmile.match.model.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author zb
 * @date 2022/3/22 12:48
 * @Description 启动项目的时候，数据初始化加载到 ringBuffer 中
 */
@Component
public class DataLoaderCmdLine implements CommandLineRunner {

    @Autowired
    private DisruptorTemplate disruptorTemplate;
    @Autowired
    private EntrustOrderMapper entrustOrderMapper;

    @Override
    public void run(String... args) throws Exception {
        // if(true){
        //     return;
        // }
        // List<EntrustOrder> entrustOrderList = entrustOrderService.list(Wrappers.<EntrustOrder>lambdaQuery()
        //         .eq(EntrustOrder::getStatus, 1).orderByAsc(EntrustOrder::getCreated)
        // );
        List<EntrustOrder> entrustOrderList = entrustOrderMapper.listPage(1000);

        if (CollUtil.isEmpty(entrustOrderList)){
            return;
        }
        for (EntrustOrder entrustOrder : entrustOrderList) {
            disruptorTemplate.onData(entrustOrder2Order(entrustOrder));
        }
    }

    private Order entrustOrder2Order(EntrustOrder entrustOrder) {
        Order order = new Order();
        order.setOrderId(entrustOrder.getId().toString());
        order.setSymbol(entrustOrder.getSymbol());
        // 交易的数量 = 总数量 - 已经成交的数量
        order.setAmount(entrustOrder.getVolume().add(entrustOrder.getDeal().negate()));
        order.setOrderDirection(entrustOrder.getType());
        order.setPrice(entrustOrder.getPrice());
        order.setTime(entrustOrder.getCreated().getTime());
        // order.setUserId();
        // order.setCoinSymbol();
        // order.setTradedAmount();
        // order.setBaseSymbol();
        // order.setOrderStatus();
        // order.setCompletedTime();
        // order.setCancelTime();
        // order.setDetails();
        return order;
    }
}
