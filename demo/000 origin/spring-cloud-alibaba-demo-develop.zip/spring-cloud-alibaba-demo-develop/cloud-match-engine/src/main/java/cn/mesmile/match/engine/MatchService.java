package cn.mesmile.match.engine;

import cn.mesmile.match.model.Order;
import cn.mesmile.match.model.OrderBooks;

/**
 * @author zb
 * @date 2022/3/22 11:21
 * @Description 戳合服务
 */
public interface MatchService {

    /**
     * 订单撮合
     * @param orderBooks
     * @param order
     */
    void match(OrderBooks orderBooks,Order order);
}
