package cn.mesmile.match.disruptor;

import lombok.Data;

import java.io.Serializable;

/**
 * @author zb
 * @date 2022/3/21 18:45
 * @Description
 */
@Data
public class OrderEvent implements Serializable {

    /**
     * 时间戳
     */
    private final long timestamp;

    /**
     * 事件携带的数据
     */
    protected transient  Object source;

    public OrderEvent(){
        this.timestamp = System.currentTimeMillis();
    }

    public OrderEvent(Object source){
        this.timestamp = System.currentTimeMillis();
        this.source = source;
    }

}
