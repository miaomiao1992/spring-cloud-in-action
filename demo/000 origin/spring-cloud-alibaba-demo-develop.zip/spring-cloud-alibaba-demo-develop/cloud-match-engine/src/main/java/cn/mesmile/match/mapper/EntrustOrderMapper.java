package cn.mesmile.match.mapper;

import cn.mesmile.match.entity.EntrustOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 委托订单信息 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-22
 */
public interface EntrustOrderMapper extends BaseMapper<EntrustOrder> {

    /**
     * 获取前条数据
     * @param size
     * @return
     */
    List<EntrustOrder> listPage(int size);

}
