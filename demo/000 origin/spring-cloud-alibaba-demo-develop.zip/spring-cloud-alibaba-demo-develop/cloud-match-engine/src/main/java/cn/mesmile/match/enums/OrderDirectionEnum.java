package cn.mesmile.match.enums;

import org.springframework.security.access.prepost.PreAuthorize;

/**
 * @author zb
 * @date 2022/3/22 10:15
 * @Description
 */
public enum OrderDirectionEnum {

    /**
     * 交易方向
     */
    BUY(1, "买入"),
    SELL(2, "卖出");

    private int code;

    private String desc;

    OrderDirectionEnum(int code,String desc){
        this.code = code;
        this.desc = desc;
    }

    public int getCode(){
        return code;
    }

    public String getDesc(){
        return desc;
    }

    public static OrderDirectionEnum getOrderDirectionEnum(int code){
        OrderDirectionEnum[] values = OrderDirectionEnum.values();
        for (OrderDirectionEnum value : values) {
            if (value.getCode() == code){
                return value;
            }
        }
        return null;
    }


}
