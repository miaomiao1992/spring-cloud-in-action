package cn.mesmile.match.rocket;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.MessageChannel;

/**
 * @author zb
 * @date 2022/3/21 23:21
 * @Description 接收订单消息
 *      这里的名称中字符， 用 数字 和 字母大小写 和 _ 或 -
 */
public interface Sink {

    /**
     *   @Input("order_in")     消费者
     *   @Output("order_out")   生产者
     */
    @Input("order_in")
    MessageChannel messageChannel();
}
