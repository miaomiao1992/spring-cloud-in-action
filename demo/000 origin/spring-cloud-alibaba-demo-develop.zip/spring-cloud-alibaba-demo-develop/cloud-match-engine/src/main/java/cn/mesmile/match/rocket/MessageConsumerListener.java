package cn.mesmile.match.rocket;

import cn.mesmile.match.disruptor.DisruptorTemplate;
import cn.mesmile.match.entity.EntrustOrder;
import cn.mesmile.match.model.Order;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Service;

/**
 * @author zb
 * @date 2022/3/21 23:27
 * @Description 消费者
 */
@Slf4j
@Service
public class MessageConsumerListener {

    @Autowired
    private DisruptorTemplate disruptorTemplate;

    // 监听队列 order.in
    @StreamListener("order_in")
    public void handleMessage(EntrustOrder entrustOrder){
        log.info(">>>>> 接收到了委托单=====》{}", entrustOrder);
        Order order = entrustOrder2Order(entrustOrder);
        disruptorTemplate.onData(order);
    }

    private Order entrustOrder2Order(EntrustOrder entrustOrder) {
        Order order = new Order();
        order.setOrderId(entrustOrder.getId().toString());
        order.setSymbol(entrustOrder.getSymbol());
        // 交易的数量 = 总数量 - 已经成交的数量
        order.setAmount(entrustOrder.getVolume().add(entrustOrder.getDeal().negate()));
        order.setOrderDirection(entrustOrder.getType());
        order.setPrice(entrustOrder.getPrice());
        order.setTime(entrustOrder.getCreated().getTime());
        // order.setUserId();
        // order.setCoinSymbol();
        // order.setTradedAmount();
        // order.setBaseSymbol();
        // order.setOrderStatus();
        // order.setCompletedTime();
        // order.setCancelTime();
        // order.setDetails();
        return order;
    }

}
