package cn.mesmile.match.config;

import cn.mesmile.match.disruptor.OrderEvent;
import cn.mesmile.match.engine.MatchEngineProperties;
import cn.mesmile.match.handler.OrderEventHandler;
import cn.mesmile.match.model.OrderBooks;
import com.lmax.disruptor.EventHandler;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @author zb
 * @date 2022/3/22 11:05
 * @Description
 */
@Configuration
@EnableConfigurationProperties(MatchEngineProperties.class)
public class MatchEngineAutoConfig {

    private MatchEngineProperties matchEngineProperties;

    public MatchEngineAutoConfig(MatchEngineProperties matchEngineProperties){
        this.matchEngineProperties = matchEngineProperties;
    }

    @Bean("eventHandlers")
    public EventHandler<OrderEvent>[] eventHandlers(){
        Map<String, MatchEngineProperties.CoinScale> symbolMap = matchEngineProperties.getSymbol();
        Set<Map.Entry<String, MatchEngineProperties.CoinScale>> entries = symbolMap.entrySet();
        Iterator<Map.Entry<String, MatchEngineProperties.CoinScale>> iterator = entries.iterator();
        EventHandler<OrderEvent>[] eventHandlers = new EventHandler[entries.size()];
        int i = 0;
        while (iterator.hasNext()){
            Map.Entry<String, MatchEngineProperties.CoinScale> next = iterator.next();
            String symbol = next.getKey();
            MatchEngineProperties.CoinScale scale = next.getValue();
            OrderBooks orderBooks = null;
            if (scale != null){
                orderBooks = new OrderBooks(symbol,scale.getCoinScale(), scale.getBaseCoinScale());
            }else {
                orderBooks = new OrderBooks(symbol);
            }
            eventHandlers[i++] = new OrderEventHandler(orderBooks);
        }
        return eventHandlers;
    }

}
