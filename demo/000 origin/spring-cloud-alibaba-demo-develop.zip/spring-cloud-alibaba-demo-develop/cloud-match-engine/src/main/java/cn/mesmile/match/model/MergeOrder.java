package cn.mesmile.match.model;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.LinkedList;

/**
 * @author zb
 * @date 2022/3/22 10:05
 * @Description 订单合并，价格相同的订单
 */
@Data
public class MergeOrder {

    private LinkedList<Order> orders = new LinkedList<>();

    /**
     * 在最后的位置添加一个
     * @param order
     */
    public void addOrder(Order order){
        orders.add(order);
    }

    /**
     *  从头获取数据
     * @return
     */
    public Order getFirstOrder(){
        return orders.get(0);
    }

    public int size(){
        return orders.size();
    }

    public BigDecimal getFirstPrice(){
        return orders.get(0).getPrice();
    }

    public Iterator<Order> iterator(){
        return orders.iterator();
    }

    /**
     * 总金额
     * @return
     */
    public BigDecimal getTotalAmount(){
        BigDecimal totalAmount = new BigDecimal("0");
        for (Order order : orders) {
            totalAmount = totalAmount.add(order.getAmount());
        }
        return totalAmount;
    }

}
