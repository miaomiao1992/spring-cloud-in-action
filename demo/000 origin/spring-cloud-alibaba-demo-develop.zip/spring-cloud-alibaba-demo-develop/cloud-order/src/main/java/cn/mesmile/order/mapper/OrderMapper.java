package cn.mesmile.order.mapper;


import cn.mesmile.order.entity.Order;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * @author zb
 * @date 2022/2/20 20:45
 * @Description
 */
public interface OrderMapper extends BaseMapper<Order> {

}
