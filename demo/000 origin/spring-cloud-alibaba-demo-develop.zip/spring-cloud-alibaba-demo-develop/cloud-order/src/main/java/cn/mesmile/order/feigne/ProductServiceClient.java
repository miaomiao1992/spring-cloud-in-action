package cn.mesmile.order.feigne;

import cn.mesmile.common.result.R;
import cn.mesmile.order.feigne.dto.Product;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * @author zb
 * @date 2022/3/7 10:59
 * @Description
 */
@FeignClient(value = "cloud-product-service", fallback = ProductServiceClientFallback.class)
public interface ProductServiceClient {

    /**
     * 获取商品
     * @param productId
     * @return
     */
    @GetMapping("/v1/product/get/{productId}")
    R<Product> getProduct(@PathVariable("productId")Long productId);

    /**
     *  修改库存
     * @param productId
     * @param number
     * @return
     */
    @PostMapping("/v1/product/update/{productId}/{number}")
    R updateProduct(@PathVariable("productId")Long productId,@PathVariable("number")Long number);

}
