package cn.mesmile.order.config;

/**
 * @author zb
 * @date 2022/2/20 20:48
 * @Description
 */
public class OrderConfig {
}
