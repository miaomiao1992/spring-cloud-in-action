package cn.mesmile.order.service;


import cn.mesmile.order.entity.Order;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @author zb
 * @date 2022/2/20 20:44
 * @Description
 */
public interface OrderService extends IService<Order> {


    /**
     *  生成订单
     * @param productId 产品id
     * @param number 订购数量
     * @return
     */
    boolean addOrder(Long productId, Long number);
}
