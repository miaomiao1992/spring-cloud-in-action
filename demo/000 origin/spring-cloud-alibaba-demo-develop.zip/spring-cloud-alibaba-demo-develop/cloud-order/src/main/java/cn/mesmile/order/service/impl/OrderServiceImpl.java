package cn.mesmile.order.service.impl;

import cn.mesmile.common.exception.ServiceException;
import cn.mesmile.common.result.R;
import cn.mesmile.common.result.ResultCode;
import cn.mesmile.order.entity.Order;
import cn.mesmile.order.feigne.ProductServiceClient;
import cn.mesmile.order.feigne.dto.Product;
import cn.mesmile.order.mapper.OrderMapper;
import cn.mesmile.order.service.OrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import io.seata.spring.annotation.GlobalTransactional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * @author zb
 * @date 2022/2/20 20:44
 * @Description
 */
@RequiredArgsConstructor
@Transactional(propagation = Propagation.SUPPORTS,rollbackFor = Exception.class,readOnly = true)
@Service
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements OrderService {

    private final ProductServiceClient productServiceClient;

    /** seata 全局事务 */
    @GlobalTransactional(rollbackFor = Exception.class)
    @Override
    public boolean addOrder(Long productId, Long number) {
        if (number <= 0){
            throw new ServiceException(ResultCode.PARAM_VALID_ERROR);
        }
        R<Product> productResult = productServiceClient.getProduct(productId);
        if (ResultCode.SUCCESS.getCode() != productResult.getCode()){
            throw new ServiceException(ResultCode.PARAM_VALID_ERROR);
        }
        Product product = productResult.getData();
        if (product == null){
            throw new ServiceException(ResultCode.PARAM_VALID_ERROR);
        }
        Long stock = product.getStock();
        long result = stock - number;
        if (result <= 0){
            throw new ServiceException(ResultCode.PARAM_VALID_ERROR);
        }
        R r = productServiceClient.updateProduct(productId, number);
        if (ResultCode.SUCCESS.getCode() != r.getCode()){
            throw new ServiceException(ResultCode.PARAM_VALID_ERROR);
        }
        Order order = new Order();
        order.setOutTradeNo(RandomStringUtils.randomNumeric(8));
        order.setState(1);
        order.setCreateTime(new Date());
        order.setTotalFee(product.getPrice() * number);
        order.setVideoId(product.getId());
        order.setVideoTitle(product.getProductName());
        order.setVideoImg("https://www.baidu.com");
        order.setUserId(123456L);
        boolean save = save(order);
        return save;
    }
}
