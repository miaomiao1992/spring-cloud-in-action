package cn.mesmile.order.feigne.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @author zb
 * @date 2022/3/7 11:05
 * @Description
 */
@Data
public class Product {

    private Long id;

    @ApiModelProperty(value = "产品名称", example = "名称", notes = "分布式", required = false)
    private String productName;

    @ApiModelProperty(value = "库存", example = "1", notes = "商品库存", required = false)
    private Long stock;

    @ApiModelProperty(value = "单价", example = "1", notes = "总计金额，单位分", required = false)
    private Long price;

    /**
     * DateTimeFormat 入参格式化
     * JsonFormat     出参格式化
     */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @ApiModelProperty(value = "创建时间", example = "", notes = "1标识支付，0标识未支付", required = false)
    private Date createTime;


}
