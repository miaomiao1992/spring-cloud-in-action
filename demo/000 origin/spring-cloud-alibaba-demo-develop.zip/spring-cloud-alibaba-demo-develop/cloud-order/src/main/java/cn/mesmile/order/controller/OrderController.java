package cn.mesmile.order.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.order.entity.Order;
import cn.mesmile.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author zb
 * @date 2022/2/20 20:44
 * @Description
 */
@RequestMapping("/v1/order")
@RequiredArgsConstructor
@RestController
public class OrderController {

    private final OrderService orderService;

    @PostMapping("/save")
    public R saveOrder(@RequestBody Order order){
        boolean save = orderService.save(order);
        return R.status(save);
    }

    @GetMapping("/list")
    public R listOrder(){
        List<Order> list = orderService.list();
        return R.data(list);
    }

    @PostMapping("/add/{productId}/{number}")
    public R addOrder(@PathVariable("productId")Long productId,@PathVariable("number")Long number){
        boolean result = orderService.addOrder(productId, number);
        return R.status(result);
    }


}
