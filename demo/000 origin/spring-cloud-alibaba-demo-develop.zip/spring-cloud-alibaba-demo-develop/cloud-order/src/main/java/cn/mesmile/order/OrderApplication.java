package cn.mesmile.order;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @author zb
 * @date 2022/2/20 20:34
 * @Description
 */
@EnableFeignClients(basePackages = {"cn.mesmile"})
@MapperScan("cn.mesmile.order.mapper")
@EnableDiscoveryClient
@SpringBootApplication(scanBasePackages = {"cn.mesmile"})
public class OrderApplication {

    public static void main(String[] args) {
        SpringApplication.run(OrderApplication.class, args);
    }

}
