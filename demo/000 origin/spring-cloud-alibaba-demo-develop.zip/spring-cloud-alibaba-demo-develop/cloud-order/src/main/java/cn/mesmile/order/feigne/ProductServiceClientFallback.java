package cn.mesmile.order.feigne;

import cn.mesmile.common.result.R;
import cn.mesmile.order.feigne.dto.Product;
import org.springframework.stereotype.Component;

/**
 * @author zb
 * @date 2022/3/7 11:00
 * @Description
 */
@Component
public class ProductServiceClientFallback implements ProductServiceClient{


    @Override
    public R<Product> getProduct(Long productId) {
        return R.fail("未找到商品编号为："+ productId);
    }

    @Override
    public R updateProduct(Long productId, Long number) {
        return R.fail("修改商品库存失败");
    }
}
