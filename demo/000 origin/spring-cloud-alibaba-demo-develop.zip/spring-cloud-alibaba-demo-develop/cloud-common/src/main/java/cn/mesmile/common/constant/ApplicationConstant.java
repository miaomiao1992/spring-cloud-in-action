package cn.mesmile.common.constant;

/**
 * @author zb
 * @date 2022/3/14 10:27
 * @Description
 */
public interface ApplicationConstant {

    String SYSTEM_APPLICATION_NAME = "cloud-system-service";

    String ORDER_APPLICATION_NAME = "cloud-order-service";

    String PRODUCT_APPLICATION_NAME = "cloud-product-service";

    String AUTH_APPLICATION_NAME = "cloud-auth-service";

    String GATEWAY_APPLICATION_NAME = "cloud-gateway-service";


}
