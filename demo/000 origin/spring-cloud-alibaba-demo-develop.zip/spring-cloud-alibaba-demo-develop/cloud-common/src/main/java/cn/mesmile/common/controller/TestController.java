package cn.mesmile.common.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.common.service.CacheService;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;

/**
 * @author zb
 * @date 2022/3/14 20:03
 * @Description
 */
@RequiredArgsConstructor
@Api(tags = "测试controller哦")
@RestController
public class TestController {

    private final CacheService cacheService;

    @GetMapping("/common/test")
    @ApiOperation(value = "测试方法", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "param",value = "参数1",dataType = "String",paramType = "query",example = "参数1"),
            @ApiImplicitParam(name = "param2",value = "参数2",dataType = "String",paramType = "query",example = "参数2")
    })
    public R get(@RequestParam("param") String param,@RequestParam("param2")  String param2){
        return R.data("成功了");
    }


    @GetMapping("/common/cache")
    @ApiOperation(value = "缓存方法", authorizations = {@Authorization("Authorization")})
    public R get(@RequestParam("username")String username){
        R cache = cacheService.getCache(username);
        return cache;
    }

    @GetMapping("/getDate")
    @ApiOperation(value = "测试JacksonConfig转换Long和time", authorizations = {@Authorization("Authorization")})
    public R getDate(){
        Date date = null;
        for (int i = 0; i < 1000 ; i++) {
            date = new Date();
        }
        HashMap<String, Object> map = new HashMap<>();
        map.put("time", date);
        map.put("long", 1000861233445635457L);
        return R.data(map);
    }


}
