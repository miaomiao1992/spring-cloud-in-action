package cn.mesmile.common.base;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author zb
 * @date 2022/3/18 10:30
 * @Description
 */
@Data
public class BaseEntity implements Serializable {

    @TableField(value = "create_by", fill = FieldFill.INSERT)
    @ApiModelProperty("创建人")
    private Long createBy;

    @TableField(value = "modify_by", fill = FieldFill.UPDATE)
    @ApiModelProperty("修改人")
    private Long modifyBy;

    @TableField(value = "created", fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;

    @TableField(value = "last_update_time", fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;
}
