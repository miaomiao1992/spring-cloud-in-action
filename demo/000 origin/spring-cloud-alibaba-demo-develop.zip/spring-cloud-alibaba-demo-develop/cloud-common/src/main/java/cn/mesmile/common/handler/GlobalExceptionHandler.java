package cn.mesmile.common.handler;

import cn.mesmile.common.exception.ServiceException;
import cn.mesmile.common.result.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

/**
 * @author zb
 * @date 2022/3/14 19:27
 * @Description 全局异常拦截
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * @ExceptionHandler相当于controller的@RequestMapping
     * 如果抛出的的是ServiceException，则调用该方法
     * @param serviceException 业务异常
     * @return @ResponseBody
     */
    @ExceptionHandler(ServiceException.class)
    public R handle(ServiceException serviceException){
        // 获取指定报名前缀的异常信息
        String stackTraceByPn = getStackTraceByPn(serviceException, "cn.mesmile");
//        log.error("记录业务异常", serviceException);
        log.error("{}:{}{}",serviceException.getMessage(),serviceException.getCode(), stackTraceByPn);
        return R.fail(serviceException.getCode(), serviceException.getMessage());
    }

    public static String getStackTraceByPn(Throwable e, String packagePrefix){
        StringBuilder append = new StringBuilder("\n").append(e);
        for (StackTraceElement stackTraceElement : e.getStackTrace()) {
            if (stackTraceElement.getClassName().startsWith(packagePrefix)){
                append.append("\n\tat ").append(stackTraceElement);
            }
        }
        return append.toString();
    }

    /**
     * 方法参数校验失败的异常
     **/
    @ExceptionHandler(value = MethodArgumentNotValidException.class)
    public R handlerMethodArgumentNotValidException(MethodArgumentNotValidException exception) {
        BindingResult bindingResult = exception.getBindingResult();
        if (bindingResult.hasErrors()) {
            FieldError fieldError = bindingResult.getFieldError();
            if (fieldError != null) {
                return R.fail(fieldError.getField() + fieldError.getDefaultMessage());
            }
        }
        return R.fail(exception.getMessage());
    }

    /**
     * 对象内部使用Validate 没有校验成功的异常
     **/
    @ExceptionHandler(value = BindException.class)
    public R handlerBindException(BindException bindException) {
        BindingResult bindingResult = bindException.getBindingResult();
        if (bindingResult.hasErrors()) {
            FieldError fieldError = bindingResult.getFieldError();
            if (fieldError != null) {
                return R.fail(fieldError.getField() + fieldError.getDefaultMessage());
            }
        }
        return R.fail(bindException.getMessage());
    }
}
