package cn.mesmile.common.utils;

import cn.mesmile.common.exception.BizAssertException;
import cn.mesmile.common.result.IResultCode;
import cn.mesmile.common.result.ResultCode;


/**
 * @author zb
 * @date 2022/2/24 11:31
 * @Description 业务断言判断
 *  不建议使用 spring 自带的Assert类因为抛出的是非法参数异常 throw new IllegalStateException(message) 更适用于框架级别
 */
public class BizAssertUtil {

    public BizAssertUtil() {
    }

    public static int defaultErrorCode = ResultCode.FAILURE.getCode();


    public static void notNull(Object object, String message, int errorCode) {
        if (object == null) {
            throw new BizAssertException(errorCode, message);
        }
    }

    public static void notNull(Object object, String message) {
        notNull(object, message, defaultErrorCode);
    }

    public static void notNull(Object object, IResultCode resultCode) {
        notNull(object, resultCode.getMessage(), resultCode.getCode());
    }


    public static void isTrue(boolean expression, String message, int errorCode) {
        if (!expression) {
            throw new BizAssertException(errorCode, message);
        }
    }

    public static void isTrue(boolean expression, String message) {
        isTrue(expression, message, defaultErrorCode);
    }

    public static void isTrue(boolean expression, IResultCode resultCode) {
        isTrue(expression, resultCode.getMessage(), resultCode.getCode());
    }


    public static void notEmpty(String text, String message, int errorCode) {
        if (isEmpty(text)) {
            throw new BizAssertException(errorCode, message);
        }
    }

    public static void notEmpty(String text, String message) {
        notEmpty(text, message, defaultErrorCode);
    }

    public static void notEmpty(String text, IResultCode resultCode) {
        notEmpty(text, resultCode.getMessage(), resultCode.getCode());
    }


    public static void notBlank(String text, String message, int errorCode) {
        if (isBlank(text)) {
            throw new BizAssertException(errorCode, message);
        }
    }

    public static void notBlank(String text, String message) {
        notBlank(text, message, defaultErrorCode);
    }

    public static void notBlank(String text, IResultCode resultCode) {
        notBlank(text, resultCode.getMessage(), resultCode.getCode());
    }

    public static boolean isEmpty(Object str) {
        return str == null || "".equals(str);
    }

    public static boolean isBlank(CharSequence str) {
        int length;
        if (str != null && (length = str.length()) != 0) {
            for (int i = 0; i < length; ++i) {
                if (!isBlankChar(str.charAt(i))) {
                    return false;
                }
            }
            return true;
        } else {
            return true;
        }
    }

    public static boolean isBlankChar(int c) {
        return Character.isWhitespace(c) || Character.isSpaceChar(c) || c == 65279 || c == 8234 || c == 0;
    }

}
