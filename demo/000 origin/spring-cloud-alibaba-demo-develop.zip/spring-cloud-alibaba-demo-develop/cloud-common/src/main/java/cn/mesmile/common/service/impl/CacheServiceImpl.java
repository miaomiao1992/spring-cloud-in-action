package cn.mesmile.common.service.impl;

import cn.mesmile.common.result.R;
import cn.mesmile.common.result.WebLog;
import cn.mesmile.common.service.CacheService;
import com.alicp.jetcache.anno.CacheType;
import com.alicp.jetcache.anno.Cached;
import org.springframework.stereotype.Service;
import sun.awt.windows.WEmbeddedFrame;

/**
 * @author zb
 * @date 2022/3/15 12:09
 * @Description
 */
@Service
public class CacheServiceImpl implements CacheService {


    @Cached(name = "cn.mesmile.common.service.impl.CacheServiceImpl", key = "#username", cacheType = CacheType.BOTH)
    @Override
    public R getCache(String username) {
        WebLog webLog = new WebLog();
        webLog.setDescription("这是描述哦");
        webLog.setUsername("这是一段用户名");
        webLog.setSpendTime(200);
        webLog.setBasePath("/user/get");
        try {
            Thread.sleep(1000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return R.data(webLog);
    }
}
