package cn.mesmile.common.exception;

import cn.mesmile.common.result.IResultCode;
import cn.mesmile.common.result.ResultCode;
import lombok.Getter;
import lombok.Setter;

/**
 * @author zb
 * @date 2022/2/24 10:58
 * @Description
 */
@Getter
@Setter
public class ServiceException extends RuntimeException {

    private final long serialVersionUID = 1L;

    private int code;

    public ServiceException(IResultCode result){
        super(result.getMessage());
        this.code = result.getCode();
    }

    public ServiceException(Integer code, String msg){
        super(msg);
        this.code = code;
    }

    public ServiceException(String msg){
        super(msg);
        this.code = ResultCode.PARAM_VALID_ERROR.getCode();
    }


}
