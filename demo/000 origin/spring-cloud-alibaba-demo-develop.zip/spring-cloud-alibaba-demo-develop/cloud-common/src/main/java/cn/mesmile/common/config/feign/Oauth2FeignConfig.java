package cn.mesmile.common.config.feign;

import cn.mesmile.common.exception.ServiceException;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;

/**
 * @author zb
 * @date 2022/3/20 10:49
 * @Description Feign 拦截器解决 token 传递问题
 */
@Slf4j
public class Oauth2FeignConfig implements RequestInterceptor {

    /**
     * 令牌在openFeign调用过程中是不能自动中继的，因此必须手动的将令牌信息传递下去
     *
     * 注意：openFeign在开启熔断降级后内部调用开启了子线程，因此传统的方案直接在RequestInterceptor中设置是不可行的
     *
     * 那么如何保证子线程也能获取请求头中的用户信息呢？
     * RequestContextHolder这个神器。
     * RequestContextHolder内部通过InheritableThreadLocal实现子线程共享信息。
     */
    @Override
    public void apply(RequestTemplate template) {
        // 从RequestContextHolder中获取HttpServletRequest
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        if (requestAttributes == null){
            log.error(">>>> 没有上下文，feign 无法传递token");
            throw new ServiceException("没有上下文，feign无法传递token");
        }
        ServletRequestAttributes attributes = (ServletRequestAttributes) requestAttributes;
        HttpServletRequest request = attributes.getRequest();
        // 获取RequestContextHolder中的信息,放入feign的RequestTemplate中
        Enumeration<String> headerNames = request.getHeaderNames();
        if (headerNames != null) {
            while (headerNames.hasMoreElements()) {
                String name = headerNames.nextElement();
                String values = request.getHeader(name);
                template.header(name, values);
            }
        }
    }

}
