package cn.mesmile.common.config.jetcache;

import com.alicp.jetcache.anno.config.EnableCreateCacheAnnotation;
import com.alicp.jetcache.anno.config.EnableMethodCache;
import org.springframework.context.annotation.Configuration;

/**
 * @author zb
 * @date 2022/3/14 19:00
 * @Description
 */
@Configuration
@EnableCreateCacheAnnotation
@EnableMethodCache(basePackages = "cn.mesmile")
public class JetCacheConfig {

}
