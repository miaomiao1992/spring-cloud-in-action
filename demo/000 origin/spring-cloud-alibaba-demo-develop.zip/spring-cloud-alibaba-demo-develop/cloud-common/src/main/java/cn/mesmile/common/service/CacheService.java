package cn.mesmile.common.service;

import cn.mesmile.common.result.R;

/**
 * @author zb
 * @date 2022/3/15 12:09
 * @Description
 */
public interface CacheService {

    /**
     *  通过用户名查找缓存
     * @param username
     * @return
     */
    R getCache(String username);
}
