package cn.mesmile.common.exception;

import cn.mesmile.common.result.IResultCode;
import lombok.Getter;

/**
 * @author zb
 * @date 2022/2/24 11:27
 * @Description
 */
@Getter
public class BizAssertException extends RuntimeException{

    private final long serialVersionUID = 1L;

    private int code;

    public BizAssertException(IResultCode result){
        super(result.getMessage());
        this.code = result.getCode();
    }

    public BizAssertException(Integer code, String msg){
        super(msg);
        this.code = code;
    }


}
