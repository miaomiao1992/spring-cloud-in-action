package cn.mesmile.admin.mapper;

import cn.mesmile.admin.entity.RolePrivilegeUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户权限配置 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface RolePrivilegeUserMapper extends BaseMapper<RolePrivilegeUser> {

}
