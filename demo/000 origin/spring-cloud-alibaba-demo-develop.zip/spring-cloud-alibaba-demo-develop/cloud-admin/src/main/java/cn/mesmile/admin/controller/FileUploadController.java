package cn.mesmile.admin.controller;

import cn.mesmile.common.result.R;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;

/**
 * @author zb
 * @date 2022/3/18 16:53
 * @Description
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/file")
@Api(tags = "文件上传相关api")
public class FileUploadController {

    @PostMapping("/upload")
    @ApiImplicitParam(name = "file",value = "文件")
    @ApiOperation("上传文件")
    public R uploadFile(@RequestParam("file") MultipartFile file) throws IOException {
        // test.jpg
        String originalFilename = file.getOriginalFilename();

        InputStream inputStream = file.getInputStream();

        return R.data("链接地址");
    }

}
