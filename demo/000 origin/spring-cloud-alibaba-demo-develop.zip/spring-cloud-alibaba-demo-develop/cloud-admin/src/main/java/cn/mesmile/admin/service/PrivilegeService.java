package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.Privilege;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Set;

/**
 * <p>
 * 权限配置 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface PrivilegeService extends IService<Privilege> {

    /**
     *  查询权限列表
     * @param sourceMenuId
     * @param roleId
     * @return
     */
    Set<Privilege> listPrivilege(Long sourceMenuId, Long roleId);
}
