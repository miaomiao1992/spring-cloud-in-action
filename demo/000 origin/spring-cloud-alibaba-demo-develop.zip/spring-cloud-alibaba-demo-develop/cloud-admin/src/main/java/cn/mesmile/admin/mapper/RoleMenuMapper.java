package cn.mesmile.admin.mapper;

import cn.mesmile.admin.entity.RoleMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 角色菜单 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface RoleMenuMapper extends BaseMapper<RoleMenu> {

}
