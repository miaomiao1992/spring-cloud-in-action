package cn.mesmile.admin.entity;

import cn.mesmile.common.base.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.*;
import org.aspectj.lang.annotation.DeclareAnnotation;

/**
 * <p>
 * 用户角色配置
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Data
@TableName("sys_user_role")
@ApiModel(value = "UserRole对象", description = "用户角色配置")
public class UserRole extends BaseEntity{

    private static final long serialVersionUID = 1L;

    public UserRole(Long roleId, Long userId){
        this.roleId = roleId;
        this.userId = userId;
    }

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("角色ID")
    private Long roleId;

    @ApiModelProperty("用户ID")
    private Long userId;

}
