package cn.mesmile.admin.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 工单记录
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Getter
@Setter
@TableName("work_issue")
@ApiModel(value = "WorkIssue对象", description = "工单记录")
public class WorkIssue implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户id(提问用户id)")
    private Long userId;

    @ApiModelProperty("回复人id")
    private Long answerUserId;

    @ApiModelProperty("回复人名称")
    private String answerName;

    @ApiModelProperty("工单内容")
    private String question;

    @ApiModelProperty("回答内容")
    private String answer;

    @ApiModelProperty("状态：1-待回答；2-已回答；")
    private Integer status;

    @TableField(value = "last_update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;

    @TableField(value = "created",fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;

    @TableField(exist = false)
    @ApiModelProperty("创建工单的用户名称")
    private String username;

    @TableField(exist = false)
    @ApiModelProperty("创建工单的用户的真实名称")
    private String realName;

}
