package cn.mesmile.admin.service.impl;

import cn.mesmile.admin.entity.Menu;
import cn.mesmile.admin.feign.Oauth2FeignClient;
import cn.mesmile.admin.model.dto.JwtTokenDTO;
import cn.mesmile.admin.model.vo.LoginResultVO;
import cn.mesmile.admin.service.LoginService;
import cn.mesmile.admin.service.MenuService;
import cn.mesmile.common.exception.ServiceException;
import cn.mesmile.common.result.R;
import cn.mesmile.common.result.ResultCode;
import cn.mesmile.common.utils.CloudRedisUtil;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author zb
 * @date 2022/3/17 19:39
 * @Description
 */
@RequiredArgsConstructor
@Service
public class LoginServiceImpl implements LoginService {

    private final Oauth2FeignClient oauth2FeignClient;

    private final MenuService menuService;

    private final CloudRedisUtil cloudRedisUtil;

    private static final String basicToken = "Basic aWNvbi1hcHA6aWNvbi1zZWNyZXQ=";

    @Override
    public LoginResultVO login(String username, String password) {

        JwtTokenDTO jwtTokenDTOR = oauth2FeignClient
                .getToken("password" , username, password, "1" , basicToken);
        if (jwtTokenDTOR == null) {
            throw new ServiceException("登录异常");
        }
        // 获取token
        String accessToken = jwtTokenDTOR.getAccessToken();
        Jwt jwt = JwtHelper.decode(accessToken);
        String claims = jwt.getClaims();
        JSONObject jsonObject = JSONObject.parseObject(claims);
        JSONArray authorities = jsonObject.getJSONArray("authorities" );
        // String username = jsonObject.getString("user_name" );
        // 获取菜单
        Set<Menu> setMenu = menuService.listMenuByUsername(username);
        // 获取权限
        Set<SimpleGrantedAuthority> grantedAuthorities = authorities
                .stream().map(auth -> new SimpleGrantedAuthority(auth.toString())).collect(Collectors.toSet());
        // 将token存入redis
        cloudRedisUtil.setEx(accessToken,"",jwtTokenDTOR.getExpiresIn(), TimeUnit.SECONDS);

        return new LoginResultVO(jwtTokenDTOR.getTokenType()+" "+accessToken, setMenu, grantedAuthorities);
    }
}
