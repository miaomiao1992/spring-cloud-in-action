package cn.mesmile.admin.mapper;

import cn.mesmile.admin.entity.Notice;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 系统资讯公告信息 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface NoticeMapper extends BaseMapper<Notice> {

}
