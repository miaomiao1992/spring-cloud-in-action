package cn.mesmile.admin.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * @author zb
 * @date 2022/3/18 12:36
 * @Description
 */
@Data
@ApiModel(value = "授予或取消角色的权限")
public class RolePrivilegesParamDTO {

    @ApiModelProperty("角色id")
    @NotNull(message = "角色不允许为空")
    private Long roleId;

    @ApiModelProperty("角色包含的权限")
    private Set<Long> privilegeIds = Collections.emptySet();

}
