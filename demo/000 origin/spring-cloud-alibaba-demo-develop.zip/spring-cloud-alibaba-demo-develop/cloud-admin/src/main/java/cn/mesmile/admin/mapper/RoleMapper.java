package cn.mesmile.admin.mapper;

import cn.mesmile.admin.entity.Role;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Set;

/**
 * <p>
 * 角色 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface RoleMapper extends BaseMapper<Role> {

    /**
     * 通过用户id，获取用户角色code
     * @param userId
     * @return
     */
    Set<String> listRoleCodeByUserId(Long userId);

    /**
     * 通过用户名，获取用户角色code
     * @param username
     * @return
     */
    Set<String> listRoleCodeByUsername(String username);

}
