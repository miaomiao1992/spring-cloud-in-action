package cn.mesmile.admin.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.admin.entity.Notice;
import cn.mesmile.admin.mapper.NoticeMapper;
import cn.mesmile.admin.service.NoticeService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * <p>
 * 系统资讯公告信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Service
public class NoticeServiceImpl extends ServiceImpl<NoticeMapper, Notice> implements NoticeService {

    @Override
    public Page<Notice> findNoticePage(Page<Notice> page, String title, Integer status, Date startTime, Date endTime) {
        Page<Notice> result = page(page, Wrappers.<Notice>lambdaQuery()
                                .like(StrUtil.isNotBlank(title), Notice::getTitle, title)
                                .eq(status != null, Notice::getStatus, status)
                                .between(startTime != null && endTime != null,Notice::getCreated, startTime, endTime)
        );
        return result;
    }
}
