package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.Config;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 平台配置信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface ConfigService extends IService<Config> {

    /**
     *  查找配置分页
     * @param page
     * @param type
     * @param code
     * @param name
     * @return
     */
    Page<Config> findConfigPage(Page<Config> page, String type, String code, String name);

    /**
     * 通过配置code查找配置
     * @param code
     * @return
     */
    Config getConfigByCode(String code);
}
