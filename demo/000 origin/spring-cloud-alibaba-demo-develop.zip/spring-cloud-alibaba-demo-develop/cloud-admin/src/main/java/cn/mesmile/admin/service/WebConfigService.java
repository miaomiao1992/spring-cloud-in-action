package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.WebConfig;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 网站配置信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface WebConfigService extends IService<WebConfig> {

    /**
     * 分页查询网站配置
     * @param page 分页参数
     * @param name 名称
     * @param type 类型
     * @return
     */
    Page<WebConfig> findWebConfigPage(Page<WebConfig> page, String name, String type);

    /**
     *  获取pc端的 banner 图
     * @return
     */
    List<WebConfig> getPcBanners();
}
