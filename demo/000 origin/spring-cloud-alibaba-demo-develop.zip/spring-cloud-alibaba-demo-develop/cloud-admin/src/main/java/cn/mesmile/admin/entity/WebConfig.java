package cn.mesmile.admin.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 网站配置信息
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Getter
@Setter
@TableName("web_config")
@ApiModel(value = "WebConfig对象", description = "网站配置信息")
public class WebConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("Id")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("分组, LINK_BANNER ,WEB_BANNER")
    private String type;

    @ApiModelProperty("名称")
    private String name;

    @ApiModelProperty("值")
    private String value;

    @ApiModelProperty("权重")
    private Integer sort;

    @ApiModelProperty("创建时间")
    private Date created;

    @ApiModelProperty("超链接地址")
    private String url;

    @ApiModelProperty("是否使用 0 否 1是")
    private Boolean status;


}
