package cn.mesmile.admin.service.impl;

import cn.mesmile.admin.entity.UserLog;
import cn.mesmile.admin.mapper.UserLogMapper;
import cn.mesmile.admin.service.UserLogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 系统日志 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Service
public class UserLogServiceImpl extends ServiceImpl<UserLogMapper, UserLog> implements UserLogService {

}
