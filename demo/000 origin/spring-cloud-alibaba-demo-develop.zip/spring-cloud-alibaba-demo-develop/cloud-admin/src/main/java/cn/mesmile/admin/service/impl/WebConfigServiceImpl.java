package cn.mesmile.admin.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.admin.entity.WebConfig;
import cn.mesmile.admin.mapper.WebConfigMapper;
import cn.mesmile.admin.service.WebConfigService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * <p>
 * 网站配置信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Transactional(rollbackFor = Exception.class, propagation = Propagation.SUPPORTS, readOnly = true)
@Service
public class WebConfigServiceImpl extends ServiceImpl<WebConfigMapper, WebConfig> implements WebConfigService {

    @Override
    public Page<WebConfig> findWebConfigPage(Page<WebConfig> page, String name, String type) {
        Page<WebConfig> result = page(page, Wrappers.<WebConfig>lambdaQuery()
                .like(StrUtil.isNotBlank(name), WebConfig::getName, name)
                .like(StrUtil.isNotBlank(type), WebConfig::getType, type)
        );
        return result;
    }

    @Override
    public List<WebConfig> getPcBanners() {
        List<WebConfig> list = list(Wrappers.<WebConfig>lambdaQuery()
                .eq(WebConfig::getType, "WEB_BANNER")
                .eq(WebConfig::getStatus, 1)
                .orderByDesc(WebConfig::getSort)
        );
        return list;
    }
}
