package cn.mesmile.admin.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 人民币充值卡号管理
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Data
@TableName("admin_bank")
@ApiModel(value = "Bank对象", description = "人民币充值卡号管理")
public class Bank implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("开户人姓名")
    private String name;

    @ApiModelProperty("开户行名称")
    private String bankName;

    @ApiModelProperty("卡号")
    private String bankCard;

    @ApiModelProperty("充值转换换币种ID")
    private Long coinId;

    @ApiModelProperty("币种名称")
    private String coinName;

    @ApiModelProperty("状态：0-无效；1-有效；")
    private Integer status;


}
