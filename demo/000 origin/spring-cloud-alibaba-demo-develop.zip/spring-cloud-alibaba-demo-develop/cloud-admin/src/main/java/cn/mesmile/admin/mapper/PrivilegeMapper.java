package cn.mesmile.admin.mapper;

import cn.mesmile.admin.entity.Privilege;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Set;

/**
 * <p>
 * 权限配置 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface PrivilegeMapper extends BaseMapper<Privilege> {

    /**
     *  通过角色id ,查询其拥有的权限
     * @param roleId
     * @return
     */
    Set<Long> listPrivilegeIdsByRoleId(Long roleId);
}
