package cn.mesmile.admin.mapper;

import cn.mesmile.admin.entity.UserRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Set;

/**
 * <p>
 * 用户角色配置 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface UserRoleMapper extends BaseMapper<UserRole> {

    /**
     * 通过用户id查询角色id
     * @param userId
     * @return
     */
    Set<Long> listRoleIdByUserId(Long userId);
}
