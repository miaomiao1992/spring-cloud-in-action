package cn.mesmile.admin.controller;

import cn.mesmile.admin.entity.Config;
import cn.mesmile.admin.entity.Notice;
import cn.mesmile.admin.service.ConfigService;
import cn.mesmile.common.result.R;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.Date;

/**
 * <p>
 * 平台配置信息 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/config")
@Api(tags = "配置管理")
public class ConfigController {

    private final ConfigService configService;

    @GetMapping
    @ApiOperation("查询分页配置")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size", value = "每页显示条数",defaultValue = "10"),
            @ApiImplicitParam(name = "type", value = "后台参数类型"),
            @ApiImplicitParam(name = "code", value = "后台参数code"),
            @ApiImplicitParam(name = "name", value = "后台参数名称")
    })
    @PreAuthorize("hasAuthority('config_qurey')")
    public R<Page<Config>> findNoticePage(@ApiIgnore Page<Config> page, String type, String code, String name){
        page.addOrder(OrderItem.desc("created"));
        Page<Config> result = configService.findConfigPage(page, type, code, name);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增配置")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "config", value = "config的json数据")
    })
    @PreAuthorize("hasAuthority('config_create')")
    public R save(@RequestBody Config config){
        boolean save = configService.save(config);
        return R.data(save);
    }

    @PostMapping
    @ApiOperation("修改配置")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "config", value = "config的json数据")
    })
    @PreAuthorize("hasAuthority('config_update')")
    public R update(@RequestBody Config config){
        boolean update = configService.updateById(config);
        return R.data(update);
    }


}
