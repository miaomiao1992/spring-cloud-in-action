package cn.mesmile.admin.service.impl;

import cn.mesmile.admin.entity.RoleMenu;
import cn.mesmile.admin.mapper.RoleMenuMapper;
import cn.mesmile.admin.service.RoleMenuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 角色菜单 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Service
public class RoleMenuServiceImpl extends ServiceImpl<RoleMenuMapper, RoleMenu> implements RoleMenuService {

}
