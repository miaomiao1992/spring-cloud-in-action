package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.Bank;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 人民币充值卡号管理 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface BankService extends IService<Bank> {

    /**
     * 分页查找银行卡
     * @param page
     * @param bankCard
     * @return
     */
    Page<Bank> findBankPage(Page<Bank> page, String bankCard);
}
