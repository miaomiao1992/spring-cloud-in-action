package cn.mesmile.admin.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 角色菜单
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Getter
@Setter
@TableName("sys_role_menu")
@ApiModel(value = "RoleMenu对象", description = "角色菜单")
public class RoleMenu implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    private Long roleId;

    private Long menuId;

    @ApiModelProperty("创建人")
    private Long createBy;

    @ApiModelProperty("修改人")
    private Long modifyBy;

    @ApiModelProperty("创建时间")
    private Date created;

    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;


}
