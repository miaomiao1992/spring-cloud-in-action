package cn.mesmile.admin.mapper;

import cn.mesmile.admin.entity.RolePrivilege;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 角色权限配置 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface RolePrivilegeMapper extends BaseMapper<RolePrivilege> {

}
