package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.WorkIssue;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Date;

/**
 * <p>
 * 工单记录 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface WorkIssueService extends IService<WorkIssue> {

    /**
     *  查找客服工单
     * @param page
     * @param startTime
     * @param endTime
     * @param status
     * @return
     */
    Page<WorkIssue> findWorkIssuePage(Page<WorkIssue> page, Date startTime, Date endTime, Integer status);

    /**
     *  前台查询自己提交的工单
     * @param page
     * @param userId
     * @return
     */
    Page<WorkIssue> findWorkIssueSimplePage(Page<WorkIssue> page, Long userId);
}
