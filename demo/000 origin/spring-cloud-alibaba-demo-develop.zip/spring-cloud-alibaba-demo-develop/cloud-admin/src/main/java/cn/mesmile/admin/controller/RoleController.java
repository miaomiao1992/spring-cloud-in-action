package cn.mesmile.admin.controller;

import cn.mesmile.admin.entity.Privilege;
import cn.mesmile.admin.entity.Role;
import cn.mesmile.admin.service.RoleService;
import cn.mesmile.common.result.R;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 角色 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/role")
@Api(tags = "角色管理")
public class RoleController {

    private final RoleService roleService;

    @GetMapping
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current",value = "当前页",defaultValue = "1",paramType = "query"),
            @ApiImplicitParam(name = "size",value = "每页显示条数，默认 10",defaultValue = "10",paramType = "query"),
            @ApiImplicitParam(name = "name",value = "角色名称",defaultValue = "管理员",paramType = "query")
    })
    @ApiOperation(value = "查询角色列表")
    @PreAuthorize("hasAuthority('sys_role_query')") // @ApiIgnore 让外界感知不到除了上面配置的参数
    public R<Page<Role>> findByPage(@ApiIgnore Page<Role> rolePage,@RequestParam("name") String name){
        // 按照修改时间 降序排列
        rolePage.addOrder(OrderItem.desc("last_update_time"));
        Page<Role> page = roleService.findByPage(rolePage, name);
        // Page<Role> page = roleService.page(rolePage);
        return R.data(page);
    }

    @PostMapping
    @ApiImplicitParams({
            @ApiImplicitParam(name = "role",value = "role里面的json数据")
    })
    @ApiOperation(value = "新增角色")
    @PreAuthorize("hasAuthority('sys_role_create')")
    public R add(@RequestBody @Validated Role role){
        boolean save = roleService.save(role);
        return R.status(save);
    }

    @PatchMapping
    @ApiImplicitParams({
            @ApiImplicitParam(name = "role",value = "role里面的json数据")
    })
    @ApiOperation(value = "修改角色")
    @PreAuthorize("hasAuthority('sys_role_update')")
    public R update(@RequestBody @Validated Role role){
        boolean update = roleService.updateById(role);
        return R.status(update);
    }

    @DeleteMapping
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id",value = "role角色id")
    })
    @ApiOperation(value = "删除角色")
    @PreAuthorize("hasAuthority('sys_role_delete')")
    public R update(@RequestParam("ids") List<Long> ids){
        if (CollectionUtils.isEmpty(ids)) {
            return R.fail("删除数据不允许为空");
        }
        boolean delete = roleService.removeByIds(ids);
        return R.status(delete);
    }

}
