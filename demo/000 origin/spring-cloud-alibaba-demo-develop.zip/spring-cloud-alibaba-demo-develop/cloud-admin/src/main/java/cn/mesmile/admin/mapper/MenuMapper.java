package cn.mesmile.admin.mapper;

import cn.mesmile.admin.entity.Menu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Set;

/**
 * <p>
 * 系统菜单 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface MenuMapper extends BaseMapper<Menu> {

    /**
     *  通过用户id 查询 菜单列表
     * @param userId
     * @return
     */
    Set<Menu> listMenuByUserId(Long userId);

    /**
     * 通过用户名查找菜单
     * @param username
     * @return
     */
    Set<Menu> listMenuByUsername(String username);

}
