package cn.mesmile.admin.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 系统资讯公告信息
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Getter
@Setter
@TableName("notice")
@ApiModel(value = "Notice对象", description = "系统资讯公告信息")
public class Notice implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("标题")
    private String title;

    @ApiModelProperty("简介")
    private String description;

    @ApiModelProperty("作者")
    private String author;

    @ApiModelProperty("文章状态")
    private Integer status;

    @ApiModelProperty("文章排序，越大越靠前")
    private Integer sort;

    @ApiModelProperty("内容")
    private String content;

    @TableField(value = "last_update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("最后修改时间")
    private Date lastUpdateTime;

    @TableField(value = "created",fill = FieldFill.INSERT)
    @ApiModelProperty("创建日期")
    private Date created;


}
