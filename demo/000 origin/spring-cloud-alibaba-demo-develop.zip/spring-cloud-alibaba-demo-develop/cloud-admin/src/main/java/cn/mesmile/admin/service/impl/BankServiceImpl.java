package cn.mesmile.admin.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.admin.entity.Bank;
import cn.mesmile.admin.mapper.BankMapper;
import cn.mesmile.admin.service.BankService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 人民币充值卡号管理 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class BankServiceImpl extends ServiceImpl<BankMapper, Bank> implements BankService {

    @Override
    public Page<Bank> findBankPage(Page<Bank> page, String bankCard) {
        Page<Bank> resultPage = page(page, Wrappers.<Bank>lambdaQuery().like(StrUtil.isNotBlank(bankCard), Bank::getBankCard, bankCard));
        return resultPage;
    }
}
