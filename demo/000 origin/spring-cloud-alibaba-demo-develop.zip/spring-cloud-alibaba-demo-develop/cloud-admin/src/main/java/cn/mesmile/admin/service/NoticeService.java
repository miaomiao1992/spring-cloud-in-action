package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.Notice;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Date;

/**
 * <p>
 * 系统资讯公告信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface NoticeService extends IService<Notice> {

    /**
     *  查询公告分页
     * @param page
     * @param title
     * @param status
     * @param startTime
     * @param endTime
     * @return
     */
    Page<Notice> findNoticePage(Page<Notice> page, String title, Integer status, Date startTime, Date endTime);
}
