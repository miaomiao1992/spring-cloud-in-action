package cn.mesmile.admin.controller;

import cn.mesmile.admin.model.vo.LoginResultVO;
import cn.mesmile.admin.service.LoginService;
import cn.mesmile.common.result.R;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zb
 * @date 2022/3/17 19:33
 * @Description
 */
@RequiredArgsConstructor
@RequestMapping("/admin")
@RestController
@Api(tags = "登录相关操作")
public class LoginController {

    private final LoginService loginService;

    @PostMapping("/login")
    @ApiOperation(value = "后台管理人员登录")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "用户名",name = "username",required = true),
            @ApiImplicitParam(value = "密码",name = "password",required = true)
    })
    public R<LoginResultVO> login( @RequestParam("username")String username,
                                    @RequestParam("password")String password ){
        LoginResultVO login = loginService.login(username, password);
        return R.data(login);
    }



}
