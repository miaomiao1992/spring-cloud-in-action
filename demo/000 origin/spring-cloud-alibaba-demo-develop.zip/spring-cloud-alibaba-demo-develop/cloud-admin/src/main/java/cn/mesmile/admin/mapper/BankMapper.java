package cn.mesmile.admin.mapper;

import cn.mesmile.admin.entity.Bank;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 人民币充值卡号管理 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface BankMapper extends BaseMapper<Bank> {

}
