package cn.mesmile.admin.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.mesmile.admin.entity.Privilege;
import cn.mesmile.admin.mapper.PrivilegeMapper;
import cn.mesmile.admin.service.PrivilegeService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * <p>
 * 权限配置 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Service
public class PrivilegeServiceImpl extends ServiceImpl<PrivilegeMapper, Privilege> implements PrivilegeService {

    @Autowired
    private PrivilegeMapper privilegeMapper;

    @Override
    public Set<Privilege> listPrivilege(Long sourceMenuId, Long roleId) {
        LambdaQueryWrapper<Privilege> eq = Wrappers.<Privilege>lambdaQuery()
                .eq(Privilege::getMenuId, sourceMenuId);
        // 查询到该菜单下所有权限
        List<Privilege> privileges = baseMapper.selectList(eq);
        if (CollectionUtil.isEmpty(privileges)){
            return Collections.emptySet();
        }
        // 该角色是否拥有该权限
        Set<Long> currentRolePrivilegeIdSet = privilegeMapper.listPrivilegeIdsByRoleId(roleId);
        for (Privilege privilege : privileges) {
            if (currentRolePrivilegeIdSet.contains(privilege.getId())) {
                privilege.setOwner(1);
            }
        }
        return new HashSet<>(privileges);
    }
}
