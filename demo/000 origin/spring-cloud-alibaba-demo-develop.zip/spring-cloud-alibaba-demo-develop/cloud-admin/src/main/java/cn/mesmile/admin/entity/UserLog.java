package cn.mesmile.admin.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 系统日志
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Getter
@Setter
@TableName("sys_user_log")
@ApiModel(value = "UserLog对象", description = "系统日志")
public class UserLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    private Long id;

    // @TableField(value = "`group`")
    @ApiModelProperty("组")
    private String group;

    @ApiModelProperty("用户Id")
    private Long userId;

    @ApiModelProperty("日志类型 1查询 2修改 3新增 4删除 5导出 6审核")
    private Integer type;

    @ApiModelProperty("方法")
    private String method;

    @ApiModelProperty("参数")
    private String params;

    @ApiModelProperty("时间")
    private Long time;

    @ApiModelProperty("IP地址")
    private String ip;

    @ApiModelProperty("描述")
    private String description;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("创建时间")
    private Date created;


}
