package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.Role;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 角色 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface RoleService extends IService<Role> {

    /**
     *  通过角色名称查询角色
     * @param rolePage
     * @param name
     * @return
     */
    Page<Role> findByPage(Page<Role> rolePage, String name);
}
