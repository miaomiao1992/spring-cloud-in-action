package cn.mesmile.admin.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.mesmile.admin.entity.Menu;
import cn.mesmile.admin.entity.Privilege;
import cn.mesmile.admin.entity.RolePrivilege;
import cn.mesmile.admin.mapper.RolePrivilegeMapper;
import cn.mesmile.admin.model.dto.RolePrivilegesParamDTO;
import cn.mesmile.admin.service.MenuService;
import cn.mesmile.admin.service.PrivilegeService;
import cn.mesmile.admin.service.RolePrivilegeService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.stream.Collectors;

/**
 * <p>
 * 角色权限配置 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Transactional(rollbackFor = Exception.class,readOnly = true,propagation = Propagation.SUPPORTS)
@RequiredArgsConstructor
@Service
public class RolePrivilegeServiceImpl extends ServiceImpl<RolePrivilegeMapper, RolePrivilege> implements RolePrivilegeService {

    private final MenuService menuService;

    private final PrivilegeService privilegeService;

    @Override
    public List<Menu> listMenuAndPrivileges(Long roleId) {
        List<Menu> menuList = menuService.list();
        // 显示二级菜单以及二级菜单下的权限
        if (CollectionUtils.isEmpty(menuList)){
            return Collections.emptyList();
        }
        // 一级菜单
        List<Menu> rootMenuList = menuList.stream()
                .filter(menu -> menu.getParentId() == null).collect(Collectors.toList());
        if (CollectionUtils.isEmpty(rootMenuList)){
            return Collections.emptyList();
        }
        // 查询所有二级菜单
        List<Menu> subMenuList = new ArrayList<>();
        for (Menu rootMenu : rootMenuList) {
            subMenuList.addAll(getChildMenus(rootMenu.getId(), roleId, menuList));
        }
        return subMenuList;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean grantPrivileges(RolePrivilegesParamDTO rolePrivilegesParam) {
        Long roleId = rolePrivilegesParam.getRoleId();
        // 先删除角色权限
        remove(Wrappers.<RolePrivilege>lambdaQuery().eq(RolePrivilege::getRoleId, roleId));

        Set<Long> privilegeIds = rolePrivilegesParam.getPrivilegeIds();
        if (CollectionUtil.isNotEmpty(privilegeIds)){
            List<RolePrivilege> rolePrivilegeList = new ArrayList<>(privilegeIds.size());
            for (Long privilegeId : privilegeIds) {
                RolePrivilege rolePrivilege = new RolePrivilege(roleId, privilegeId);
                rolePrivilegeList.add(rolePrivilege);
            }
            // 再添加角色权限
            return saveBatch(rolePrivilegeList);
        }
        return false;
    }

    private List<Menu> getChildMenus(Long parentId, Long roleId, List<Menu> menuList) {
        List<Menu> subMenuPrivilegeList = new ArrayList<>();
        for (Menu sourceMenu : menuList) {
            // 查找二级菜单
            if (Objects.equals(sourceMenu.getParentId(), parentId)){
                subMenuPrivilegeList.add(sourceMenu);
                // 获取下一个子级
                Long sourceMenuId = sourceMenu.getId();
                List<Menu> childMenus = getChildMenus(sourceMenuId, roleId, menuList);
                // 设置子级
                sourceMenu.setSubMenuSet(new HashSet<>(childMenus));
                // 子级拥有的权限
                Set<Privilege> privilegeSet = privilegeService.listPrivilege(sourceMenuId, roleId);
                sourceMenu.setPrivilegeSet(privilegeSet);
            }
        }
        return subMenuPrivilegeList;
    }


}
