package cn.mesmile.admin.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.StrUtil;
import cn.mesmile.admin.entity.User;
import cn.mesmile.admin.entity.UserRole;
import cn.mesmile.admin.mapper.UserMapper;
import cn.mesmile.admin.service.UserRoleService;
import cn.mesmile.admin.service.UserService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * <p>
 * 平台用户 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Autowired
    private UserRoleService userRoleService;

    @Override
    public Page<User> findUsersPage(Page<User> page, String mobile, String fullname) {
        Page<User> result = page(page,
                Wrappers.<User>lambdaQuery()
                        .eq(StrUtil.isNotBlank(mobile), User::getMobile, mobile)
                        .like(StrUtil.isNotBlank(fullname), User::getFullname, fullname)
                );
        List<User> records = result.getRecords();
        if (CollectionUtil.isNotEmpty(records)){
            for (User user : records) {
                Set<Long> roleIdSet = userRoleService.listRoleIdByUserId(user.getId());
                String roleStrings = roleIdSet.stream().map(Object::toString).collect(Collectors.joining("," ));
                user.setRole_strings(roleStrings);
            }
        }
        return result;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean saveUser(User user) {
        String password = user.getPassword();
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        user.setPassword(bCryptPasswordEncoder.encode(password));
        // 角色id字符串，英文逗号分割
        String role_strings = user.getRole_strings();
        boolean save = save(user);
        if (save){
            Long userId = user.getId();
            String[] split = StrUtil.splitToArray(role_strings, "," );
            if (split.length > 0){
                Set<UserRole> userRoles = new HashSet<>(split.length);
                for (String roleId : split) {
                    UserRole userRole = new UserRole(Long.valueOf(roleId), userId);
                    userRoles.add(userRole);
                }
                // 保存用户角色关系
                return userRoleService.saveBatch(userRoles);
            }
        }
        return false;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updateUser(User user) {
        String password = user.getPassword();
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        user.setPassword(bCryptPasswordEncoder.encode(password));
        // 角色id字符串，英文逗号分割
        String role_strings = user.getRole_strings();
        boolean update = updateById(user);
        if (update){
            // 先删除用户角色关系
            boolean remove = userRoleService.remove(Wrappers
                    .<UserRole>lambdaQuery().eq(UserRole::getUserId, user.getId()));
            // 后添加用户角色关系
            String[] roleIds = StrUtil.splitToArray(role_strings,",");
            if (roleIds.length > 0){
                Set<UserRole> userRoles = new HashSet<>(roleIds.length);
                for (String roleId : roleIds) {
                    UserRole userRole = new UserRole(Long.valueOf(roleId), user.getId());
                    userRoles.add(userRole);
                }
                // 保存关系
                return userRoleService.saveBatch(userRoles);
            }
        }
        return false;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean deleteUsers(List<Long> ids) {
        return removeByIds(ids);
    }
}
