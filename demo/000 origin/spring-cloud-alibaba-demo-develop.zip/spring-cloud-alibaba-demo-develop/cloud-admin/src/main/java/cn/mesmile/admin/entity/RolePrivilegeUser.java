package cn.mesmile.admin.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 用户权限配置
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Getter
@Setter
@TableName("sys_role_privilege_user")
@ApiModel(value = "RolePrivilegeUser对象", description = "用户权限配置")
public class RolePrivilegeUser implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("角色Id")
    private Long roleId;

    @ApiModelProperty("用户Id")
    private Long userId;

    @ApiModelProperty("权限Id")
    private Long privilegeId;


}
