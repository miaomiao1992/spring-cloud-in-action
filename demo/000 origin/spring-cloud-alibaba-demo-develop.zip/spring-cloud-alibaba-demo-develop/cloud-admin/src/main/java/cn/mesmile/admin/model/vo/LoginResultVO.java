package cn.mesmile.admin.model.vo;

import cn.mesmile.admin.entity.Menu;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.List;
import java.util.Set;

/**
 * @author zb
 * @date 2022/3/17 19:30
 * @Description
 */
@NoArgsConstructor
@Data
@ApiModel(value = "登录返回结果")
public class LoginResultVO {

    public LoginResultVO(String token, Set<Menu> menuList, Set<SimpleGrantedAuthority> authorityList){
        this.token = token;
        this.menuList = menuList;
        this.authorityList = authorityList;
    }

    @ApiModelProperty("token")
    private String token;

    @ApiModelProperty("用户菜单")
    private Set<Menu> menuList;

    @ApiModelProperty("用户权限")
    private Set<SimpleGrantedAuthority> authorityList;

}
