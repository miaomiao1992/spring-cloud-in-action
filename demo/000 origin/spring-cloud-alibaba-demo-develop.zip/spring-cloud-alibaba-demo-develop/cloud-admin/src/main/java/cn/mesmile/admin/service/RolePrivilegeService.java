package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.Menu;
import cn.mesmile.admin.entity.RolePrivilege;
import cn.mesmile.admin.model.dto.RolePrivilegesParamDTO;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 角色权限配置 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface RolePrivilegeService extends IService<RolePrivilege> {

    /**
     *  通过角色id 查询，菜单权限表
     * @param roleId
     * @return
     */
    List<Menu> listMenuAndPrivileges(Long roleId);

    /**
     *  授予或取消角色权限
     * @param rolePrivilegesParam
     * @return
     */
    boolean grantPrivileges(RolePrivilegesParamDTO rolePrivilegesParam);
}
