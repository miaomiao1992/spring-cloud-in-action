package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.RoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 角色菜单 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface RoleMenuService extends IService<RoleMenu> {

}
