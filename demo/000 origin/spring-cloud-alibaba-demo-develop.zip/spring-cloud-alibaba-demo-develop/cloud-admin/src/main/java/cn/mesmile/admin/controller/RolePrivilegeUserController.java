package cn.mesmile.admin.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 用户权限配置 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@RestController
@RequestMapping("/role-privilege-user")
public class RolePrivilegeUserController {

}
