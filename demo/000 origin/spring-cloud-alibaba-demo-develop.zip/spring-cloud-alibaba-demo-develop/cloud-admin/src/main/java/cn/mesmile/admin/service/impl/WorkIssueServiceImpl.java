package cn.mesmile.admin.service.impl;

import cn.mesmile.admin.entity.WorkIssue;
import cn.mesmile.admin.mapper.WorkIssueMapper;
import cn.mesmile.admin.service.WorkIssueService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * <p>
 * 工单记录 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Service
public class WorkIssueServiceImpl extends ServiceImpl<WorkIssueMapper, WorkIssue> implements WorkIssueService {

    @Override
    public Page<WorkIssue> findWorkIssuePage(Page<WorkIssue> page, Date startTime, Date endTime, Integer status) {
        Page<WorkIssue> resultPage = page(page, Wrappers.<WorkIssue>lambdaQuery()
                .eq(status != null, WorkIssue::getStatus, status)
                .between(startTime != null && endTime != null, WorkIssue::getCreated, startTime, endTime)
        );
        return resultPage;
    }

    @Override
    public Page<WorkIssue> findWorkIssueSimplePage(Page<WorkIssue> page, Long userId) {
        Page<WorkIssue> resultPage = page(page, Wrappers.<WorkIssue>lambdaQuery()
                .eq(userId != null, WorkIssue::getUserId, userId)
        );
        return resultPage;
    }
}
