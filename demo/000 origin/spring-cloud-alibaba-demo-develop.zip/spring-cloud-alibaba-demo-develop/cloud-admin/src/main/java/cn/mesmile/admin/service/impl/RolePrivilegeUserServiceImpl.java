package cn.mesmile.admin.service.impl;

import cn.mesmile.admin.entity.RolePrivilegeUser;
import cn.mesmile.admin.mapper.RolePrivilegeUserMapper;
import cn.mesmile.admin.service.RolePrivilegeUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户权限配置 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Service
public class RolePrivilegeUserServiceImpl extends ServiceImpl<RolePrivilegeUserMapper, RolePrivilegeUser> implements RolePrivilegeUserService {

}
