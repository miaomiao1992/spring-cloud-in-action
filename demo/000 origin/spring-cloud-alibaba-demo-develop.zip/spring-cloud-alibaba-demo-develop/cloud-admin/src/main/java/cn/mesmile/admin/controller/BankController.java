package cn.mesmile.admin.controller;

import cn.mesmile.admin.entity.Bank;
import cn.mesmile.admin.entity.Notice;
import cn.mesmile.admin.service.BankService;
import cn.mesmile.common.result.R;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.Date;

/**
 * <p>
 * 人民币充值卡号管理 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/bank")
@Api(tags = "银行卡管理")
public class BankController {

    private final BankService bankService;

    @GetMapping
    @ApiOperation("查询分页银行卡")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size", value = "每页显示条数",defaultValue = "10"),
            @ApiImplicitParam(name = "bankCard", value = "公司银行卡")
    })
    @PreAuthorize("hasAuthority('admin_bank_query')")
    public R<Page<Bank>> findNoticePage(@ApiIgnore Page<Bank> page, String bankCard){
        Page<Bank> result = bankService.findBankPage(page, bankCard);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增银行卡")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "bank", value = "bank对象的json数据")
    })
    @PreAuthorize("hasAuthority('admin_bank_create')")
    public R save(@RequestBody Bank bank){
        boolean save = bankService.save(bank);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改银行卡")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "bank", value = "bank对象的json数据")
    })
    @PreAuthorize("hasAuthority('admin_bank_update')")
    public R update(@RequestBody Bank bank){
        boolean update = bankService.updateById(bank);
        return R.status(update);
    }

    @PostMapping("/update-status")
    @ApiOperation("修改银行卡")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "bankId", value = "bank对象的id"),
            @ApiImplicitParam(name = "status", value = "状态")
    })
    public R updateStatus(Long bankId, Integer status){
        boolean update = bankService.update(Wrappers.<Bank>lambdaUpdate()
                .eq(Bank::getId, bankId)
                .set(Bank::getStatus, status)
        );
        return R.status(update);
    }




}
