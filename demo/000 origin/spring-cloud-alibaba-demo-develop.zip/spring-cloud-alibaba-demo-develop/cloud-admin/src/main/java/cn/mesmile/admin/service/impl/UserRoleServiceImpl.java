package cn.mesmile.admin.service.impl;

import cn.mesmile.admin.entity.UserRole;
import cn.mesmile.admin.mapper.UserRoleMapper;
import cn.mesmile.admin.service.UserRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Set;

/**
 * <p>
 * 用户角色配置 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Service
public class UserRoleServiceImpl extends ServiceImpl<UserRoleMapper, UserRole> implements UserRoleService {

    @Autowired
    private UserRoleMapper userRoleMapper;

    @Override
    public Set<Long> listRoleIdByUserId(Long userId) {
        Set<Long> roleIdSet = userRoleMapper.listRoleIdByUserId(userId);
        return roleIdSet;
    }
}
