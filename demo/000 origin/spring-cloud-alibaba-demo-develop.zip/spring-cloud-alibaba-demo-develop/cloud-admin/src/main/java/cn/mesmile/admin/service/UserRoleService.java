package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.UserRole;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Set;

/**
 * <p>
 * 用户角色配置 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface UserRoleService extends IService<UserRole> {

    /**
     * 通过用户id ，查询其拥有的角色id
     * @param userId
     * @return
     */
    Set<Long> listRoleIdByUserId(Long userId);
}
