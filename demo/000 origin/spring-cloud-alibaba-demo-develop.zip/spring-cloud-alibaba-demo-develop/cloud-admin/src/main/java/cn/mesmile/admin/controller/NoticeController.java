package cn.mesmile.admin.controller;

import cn.mesmile.admin.entity.Notice;
import cn.mesmile.admin.service.NoticeService;
import cn.mesmile.common.result.R;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 系统资讯公告信息 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/notice")
@Api(tags = "公告管理相关api")
public class NoticeController {

    private final NoticeService noticeService;

    @GetMapping
    @ApiOperation("查询分页公告")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size", value = "每页显示条数",defaultValue = "10"),
            @ApiImplicitParam(name = "title", value = "公告标题"),
            @ApiImplicitParam(name = "status", value = "状态"),
            @ApiImplicitParam(name = "startTime", value = "开始时间"),
            @ApiImplicitParam(name = "endTime", value = "结束时间")
    })
    public R<Page<Notice>> findNoticePage(@ApiIgnore Page<Notice> page, String title, Integer status, Date startTime, Date endTime){
        page.addOrder(OrderItem.desc("sort"),OrderItem.desc("last_update_time"));
        Page<Notice> result = noticeService.findNoticePage(page, title, status, startTime, endTime);
        return R.data(result);
    }

    @PostMapping("/save")
    @ApiOperation("增加公告")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "notice", value = "notice的json对象")
    })
    @PreAuthorize("hasAuthority('notice_create')")
    public R save(@RequestBody Notice notice){
        notice.setStatus(1);
        boolean result = noticeService.save(notice);
        return R.data(result);
    }

    @PatchMapping("/update")
    @ApiOperation("修改公告")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "notice", value = "notice的json对象")
    })
    @PreAuthorize("hasAuthority('notice_update')")
    public R update(@RequestBody Notice notice){
        boolean result = noticeService.updateById(notice);
        return R.data(result);
    }

    @PostMapping("/update-status")
    @ApiOperation("修改公告状态")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "notice公告的id"),
            @ApiImplicitParam(name = "status", value = "notice公告的状态"),
    })
    public R updateStatus(@RequestParam("id")Long id,@RequestParam("status")Integer status){
        boolean update = noticeService.update(Wrappers.<Notice>lambdaUpdate()
                .eq(id != null, Notice::getId, id)
                .set(status != null, Notice::getStatus, status)
        );
        return R.data(update);
    }


    @PostMapping("/delete")
    @ApiOperation("删除多个公告")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "ids", value = "多个公告的id")
    })
    @PreAuthorize("hasAuthority('notice_delete')")
    public R deleteNotice(@RequestBody List<String> ids){
        boolean result = noticeService.removeByIds(ids);
        return R.data(result);
    }

    @GetMapping("/simple")
    @ApiOperation("前台查询分页公告")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size", value = "每页显示条数",defaultValue = "10"),
    })
    public R<Page<Notice>> findNoticeSimplePage(@ApiIgnore Page<Notice> page){
        page.addOrder(OrderItem.desc("sort"),OrderItem.desc("last_update_time"));
        Page<Notice> result = noticeService.findNoticePage(page, null, 1, null, null);
        return R.data(result);
    }

    @GetMapping("/simple/{id}")
    @ApiOperation("前台查询单条公告")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "notice的id"),
    })
    public R<Notice> findNoticeSimple(@PathVariable("id")Long id){
        Notice one = noticeService.getById(id);
        return R.data(one);
    }

}
