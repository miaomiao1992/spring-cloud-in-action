package cn.mesmile.admin.mapper;

import cn.mesmile.admin.entity.WorkIssue;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 工单记录 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface WorkIssueMapper extends BaseMapper<WorkIssue> {

}
