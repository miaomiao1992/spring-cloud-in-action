package cn.mesmile.admin.controller;

import cn.mesmile.admin.entity.Privilege;
import cn.mesmile.admin.service.PrivilegeService;
import cn.mesmile.common.result.R;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

/**
 * <p>
 * 权限配置 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/privilege")
@Api(tags = "权限管理")
public class PrivilegeController {

    private final PrivilegeService privilegeService;

    @GetMapping
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current",value = "当前页",defaultValue = "1",paramType = "query"),
            @ApiImplicitParam(name = "size",value = "每页显示条数，默认 10",defaultValue = "10",paramType = "query"),
    })
    @ApiOperation(value = "查询权限列表")
    @PreAuthorize("hasAuthority('sys_privilege_query')") // @ApiIgnore 让外界感知不到除了上面配置的参数
    public R<Page<Privilege>> findByPage(@ApiIgnore Page<Privilege> privilegePage){
        // 按照修改时间 降序排列
        privilegePage.addOrder(OrderItem.desc("last_update_time"));
        Page<Privilege> page = privilegeService.page(privilegePage);
        return R.data(page);
    }

    @PostMapping
    @ApiImplicitParams({
            @ApiImplicitParam(name = "privilege",value = "privilege里面的json数据")
    })
    @ApiOperation(value = "新增权限")
    @PreAuthorize("hasAuthority('sys_privilege_create')")
    public R add(@RequestBody @Validated Privilege privilege){
        boolean save = privilegeService.save(privilege);
        return R.status(save);
    }

    @PatchMapping
    @ApiImplicitParams({
            @ApiImplicitParam(name = "privilege",value = "privilege里面的json数据")
    })
    @ApiOperation(value = "修改权限")
    @PreAuthorize("hasAuthority('sys_privilege_update')")
    public R update(@RequestBody @Validated Privilege privilege){
        boolean update = privilegeService.updateById(privilege);
        return R.status(update);
    }

    @DeleteMapping
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id",value = "privilege权限id")
    })
    @ApiOperation(value = "删除权限")
    @PreAuthorize("hasAuthority('sys_privilege_delete')")
    public R update(@RequestParam("id")Long id){
        boolean delete = privilegeService.removeById(id);
        return R.status(delete);
    }

}
