package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.User;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 平台用户 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface UserService extends IService<User> {

    /**
     *  查询用户分页参数
     * @param page 分页参数
     * @param mobile 电话
     * @param fullname 姓名
     * @return
     */
    Page<User> findUsersPage(Page<User> page, String mobile, String fullname);

    /**
     * 添加用户
     * @param user
     * @return
     */
    boolean saveUser(User user);

    /**
     * 修改用户
     * @param user
     * @return
     */
    boolean updateUser(User user);

    /**
     * 批量删除用户
     * @param ids
     * @return
     */
    boolean deleteUsers(List<Long> ids);
}
