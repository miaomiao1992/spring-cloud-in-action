package cn.mesmile.admin.service.impl;

import cn.mesmile.admin.entity.Menu;
import cn.mesmile.admin.mapper.MenuMapper;
import cn.mesmile.admin.service.MenuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Set;

/**
 * <p>
 * 系统菜单 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@RequiredArgsConstructor
@Service
public class MenuServiceImpl extends ServiceImpl<MenuMapper, Menu> implements MenuService {

    private final MenuMapper menuMapper;

    @Override
    public Set<Menu> listMenuByUsername(String username) {
        return menuMapper.listMenuByUsername(username);
    }

    @Override
    public Set<Menu> listMenuByUserId(Long userId) {
        return menuMapper.listMenuByUserId(userId);
    }
}
