package cn.mesmile.admin.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <p>
 * 角色权限配置
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@NoArgsConstructor
@Getter
@Setter
@TableName("sys_role_privilege")
@ApiModel(value = "RolePrivilege对象", description = "角色权限配置")
public class RolePrivilege implements Serializable {

    private static final long serialVersionUID = 1L;

    public RolePrivilege(Long roleId, Long privilegeId){
        this.roleId = roleId;
        this.privilegeId = privilegeId;
    }

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("角色id")
    private Long roleId;

    @ApiModelProperty("权限id")
    private Long privilegeId;


}
