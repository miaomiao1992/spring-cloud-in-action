package cn.mesmile.admin.service;

import cn.mesmile.admin.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Set;

/**
 * <p>
 * 系统菜单 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface MenuService extends IService<Menu> {

    /**
     * 通过用户名查询菜单列表
     * @param username
     * @return
     */
    Set<Menu> listMenuByUsername(String username);

    /**
     *  通过用户id查询菜单列表
     * @param userId 用户id
     * @return
     */
    Set<Menu> listMenuByUserId(Long userId);
}
