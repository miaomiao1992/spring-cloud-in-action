package cn.mesmile.admin.controller;

import cn.mesmile.admin.entity.WebConfig;
import cn.mesmile.admin.service.WebConfigService;
import cn.mesmile.common.result.R;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 网站配置信息 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/web-config")
@Api(tags = "网站配置banners图相关api")
public class WebConfigController {

    private final WebConfigService webConfigService;

    @GetMapping("/get")
    @ApiOperation(value = "分页查询获取配置", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current",value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size",value = "每页显示的条数",defaultValue = "10"),
            @ApiImplicitParam(name = "name",value = "名称"),
            @ApiImplicitParam(name = "type",value = "类型")
    })
    @PreAuthorize("hasAuthority('web_config_query')")
    public R<Page<WebConfig>> findUsersPage(@ApiIgnore Page<WebConfig> page, String name, String type){
        page.addOrder(OrderItem.desc("sort"));
        Page<WebConfig> webConfigPage = webConfigService.findWebConfigPage(page, name ,type);
        return R.data(webConfigPage);
    }

    @PostMapping("/save")
    @ApiOperation(value = "增加网站配置", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "webConfig",value = "webConfig的json数据")
    })
    @PreAuthorize("hasAuthority('web_config_create')")
    public R save(@RequestBody WebConfig webConfig){
        boolean save = webConfigService.save(webConfig);
        return R.data(save);
    }

    @PatchMapping("/update")
    @ApiOperation(value = "修改网站配置", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "webConfig",value = "webConfig的json数据")
    })
    @PreAuthorize("hasAuthority('web_config_update')")
    public R update(@RequestBody WebConfig webConfig){
        boolean update = webConfigService.updateById(webConfig);
        return R.data(update);
    }

    @PostMapping("/delete")
    @ApiOperation(value = "删除网站配置", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "ids",value = "webConfig的多个id")
    })
    @PreAuthorize("hasAuthority('web_config_delete')")
    public R delete(@RequestBody List<String> ids){
        boolean delete = webConfigService.removeByIds(ids);
        return R.data(delete);
    }

    @GetMapping("/banners")
    @ApiOperation(value = "获取pc端的banner图")
    public R<List<WebConfig>> banners(){
        List<WebConfig> webConfigList = webConfigService.getPcBanners();
        return R.data(webConfigList);
    }



}
