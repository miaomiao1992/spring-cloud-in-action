package cn.mesmile.admin.entity;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.common.base.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;

import java.util.Collections;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import java.util.Set;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 系统菜单
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Data
@TableName("sys_menu")
@ApiModel(value = "Menu对象", description = "系统菜单")
public class Menu extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("上级菜单ID")
    private Long parentId;

    @ApiModelProperty("上级菜单唯一KEY值")
    private String parentKey;

    @ApiModelProperty("类型 1-分类 2-节点")
    private Integer type;

    @ApiModelProperty("名称")
    private String name;

//    @TableField(value = "`desc`") 这里desc是系统关键字，若报错则加上符号 一票
    @ApiModelProperty("描述")
    private String desc;

    @ApiModelProperty("目标地址")
    private String targetUrl;

    @ApiModelProperty("排序索引")
    private Integer sort;

    @ApiModelProperty("状态 0-无效； 1-有效；")
    private Integer status;

    @TableField(exist = false)
    @ApiModelProperty("该菜单下的所有权限")
    private Set<Privilege> privilegeSet = Collections.emptySet();

    @TableField(exist = false)
    @ApiModelProperty("该菜单下的所有子菜单")
    private Set<Menu> subMenuSet = Collections.emptySet();

    @TableField(exist = false)
    @ApiModelProperty("该菜单下的唯一key")
    private String menuKey;

    /**
     *  获取菜单的唯一key凭证
     * @return
     */
    public String getMenuKey(){
        if(StrUtil.isNotBlank(parentKey)){
            return parentKey+"."+id;
        }else {
            return id.toString();
        }
    }

}
