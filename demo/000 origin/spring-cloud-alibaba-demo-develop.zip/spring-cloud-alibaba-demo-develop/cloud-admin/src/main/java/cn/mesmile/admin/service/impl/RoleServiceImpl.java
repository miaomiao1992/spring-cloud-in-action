package cn.mesmile.admin.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.admin.entity.Role;
import cn.mesmile.admin.mapper.RoleMapper;
import cn.mesmile.admin.service.RoleService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 角色 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role> implements RoleService {

    @Override
    public Page<Role> findByPage(Page<Role> rolePage, String name) {
        LambdaQueryWrapper<Role> queryWrapper = Wrappers.<Role>lambdaQuery()
                .like(StrUtil.isNotBlank(name), Role::getName, name);
        return baseMapper.selectPage(rolePage, queryWrapper);
    }
}
