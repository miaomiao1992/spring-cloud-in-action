package cn.mesmile.admin.entity;

import cn.mesmile.common.base.BaseEntity;
import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * <p>
 * 权限配置
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@EqualsAndHashCode(callSuper = false)
@Data
@TableName("sys_privilege")
@ApiModel(value = "Privilege对象", description = "权限配置")
public class Privilege extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("所属菜单Id")
    @NotNull(message = "菜单id不允许为空")
    private Long menuId;

    @ApiModelProperty("功能点名称")
    @NotBlank(message = "功能名称不允许为空")
    private String name;

    @ApiModelProperty("功能描述")
    private String description;

    private String url;

    private String method;

    @TableField(exist = false)
    @ApiModelProperty("当前角色是否拥有这个权限")
    private int owner;

}
