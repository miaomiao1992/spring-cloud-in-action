package cn.mesmile.admin.mapper;

import cn.mesmile.admin.entity.Config;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 平台配置信息 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
public interface ConfigMapper extends BaseMapper<Config> {

}
