package cn.mesmile.admin.controller;

import cn.mesmile.admin.entity.User;
import cn.mesmile.admin.service.UserService;
import cn.mesmile.common.result.R;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.springframework.core.annotation.Order;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 平台用户 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/user")
@Api(tags = "用户相关api")
public class UserController {

    private final UserService userService;

    @GetMapping("/get2")
    @ApiOperation(value = "获取单个用户", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id",value = "用户id",dataType = "Long",paramType = "query",example = "123")
    })
    public R getUser(@RequestParam("id")Long id){
        User user = userService.getById(id);
        return R.data(user);
    }

    @GetMapping("/get")
    @ApiOperation(value = "分页获取用户", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current",value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size",value = "每页显示的条数",defaultValue = "10"),
            @ApiImplicitParam(name = "mobile",value = "电话号码"),
            @ApiImplicitParam(name = "fullname",value = "姓名")
    })
    @PreAuthorize("hasAuthority('sys_user_query')")
    public R<Page<User>> findUsersPage(@ApiIgnore Page<User> page,String mobile, String fullname){
        page.addOrder(OrderItem.desc("created"));
        Page<User> user = userService.findUsersPage(page, mobile ,fullname);
        return R.data(user);
    }

    @PostMapping("/save")
    @ApiOperation(value = "添加用户", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "user",value = "user相关的json")
    })
    @PreAuthorize("hasAuthority('sys_user_create')")
    public R save(@Validated @RequestBody User user){
        boolean save = userService.saveUser(user);
        return R.status(save);
    }

    @PatchMapping("/update")
    @ApiOperation(value = "修改用户", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "user",value = "user相关的json")
    })
    @PreAuthorize("hasAuthority('sys_user_update')")
    public R update(@Validated @RequestBody User user){
        boolean updateUser = userService.updateUser(user);
        return R.status(updateUser);
    }

    @PostMapping("/delete")
    @ApiOperation(value = "删除用户", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "user",value = "user相关的json")
    })
    @PreAuthorize("hasAuthority('sys_user_delete')")
    public R update(@RequestBody List<Long> ids){
        boolean delete = userService.deleteUsers(ids);
        return R.status(delete);
    }



}
