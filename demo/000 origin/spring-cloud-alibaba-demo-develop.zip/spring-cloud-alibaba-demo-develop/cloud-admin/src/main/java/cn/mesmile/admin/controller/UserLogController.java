package cn.mesmile.admin.controller;

import cn.mesmile.admin.entity.User;
import cn.mesmile.admin.entity.UserLog;
import cn.mesmile.admin.service.UserLogService;
import cn.mesmile.common.result.R;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * <p>
 * 系统日志 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/user-log")
@Api(tags = "用户日志api")
public class UserLogController {

    private final UserLogService userLogService;

    @GetMapping("/get")
    @ApiOperation(value = "分页查询日志", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current",value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size",value = "每页显示的条数",defaultValue = "10")
    })
    public R<Page<UserLog>> findUsersPage(@ApiIgnore Page<UserLog> page){
        page.addOrder(OrderItem.desc("created"));
        Page<UserLog> userLogPage = userLogService.page(page);
        return R.data(userLogPage);
    }




}
