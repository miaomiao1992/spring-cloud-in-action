package cn.mesmile.admin.controller;

import cn.mesmile.admin.entity.Menu;
import cn.mesmile.admin.model.dto.RolePrivilegesParamDTO;
import cn.mesmile.admin.service.RolePrivilegeService;
import cn.mesmile.common.result.R;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * <p>
 * 角色权限配置 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/role-privilege")
@Api(tags = "角色权限配置")
public class RolePrivilegeController {

    private final RolePrivilegeService rolePrivilegeService;

    @GetMapping
    @ApiImplicitParams({
            @ApiImplicitParam(name = "roleId",value = "角色id")
    })
    @ApiOperation(value = "角色配置权限")
    public R<List<Menu>> listMenuAndPrivileges(@RequestParam("roleId") Long roleId){
        List<Menu> dataList = rolePrivilegeService.listMenuAndPrivileges(roleId);
        return R.data(dataList);
    }

    @PostMapping
    @ApiImplicitParams({
            @ApiImplicitParam(name = "rolePrivilegesParam",value = "rolePrivilegesParam的json数据")
    })
    @ApiOperation(value = "授予或取消角色配置权限")
    public R grantPrivileges(@Validated @RequestBody RolePrivilegesParamDTO rolePrivilegesParam){
        boolean result = rolePrivilegeService.grantPrivileges(rolePrivilegesParam);
        return R.status(result);
    }

}
