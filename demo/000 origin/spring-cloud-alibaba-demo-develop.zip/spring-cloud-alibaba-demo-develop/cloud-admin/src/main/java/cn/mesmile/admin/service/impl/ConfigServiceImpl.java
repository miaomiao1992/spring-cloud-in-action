package cn.mesmile.admin.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.admin.entity.Config;
import cn.mesmile.admin.mapper.ConfigMapper;
import cn.mesmile.admin.service.ConfigService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 平台配置信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Service
public class ConfigServiceImpl extends ServiceImpl<ConfigMapper, Config> implements ConfigService {

    @Override
    public Page<Config> findConfigPage(Page<Config> page, String type, String code, String name) {
        Page<Config> result = page(page, Wrappers.<Config>lambdaQuery()
                .eq(StrUtil.isNotBlank(type), Config::getType, type)
                .like(StrUtil.isNotBlank(code), Config::getCode, code)
                .like(StrUtil.isNotBlank(name), Config::getName, name)
        );
        return result;
    }

    @Override
    public Config getConfigByCode(String code) {
        if (StrUtil.isBlank(code)){
            return new Config();
        }
        return getOne(Wrappers.<Config>lambdaQuery().eq(Config::getCode, code));
    }
}
