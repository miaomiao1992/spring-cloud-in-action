package cn.mesmile.admin.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author zb
 * @date 2022/3/17 19:43
 * @Description
 */
@Data
public class JwtTokenDTO {

    @ApiModelProperty("认证token")
    @JsonProperty("access_token")
    private String accessToken;

    @ApiModelProperty("token类型")
    @JsonProperty("token_type")
    private String tokenType;

    @ApiModelProperty("刷新token")
    @JsonProperty("refresh_token")
    private String refreshToken;

    @ApiModelProperty("过期时间，单位秒")
    @JsonProperty("expires_in")
    private Integer expiresIn;

    @ApiModelProperty("授权范围")
    private String scope;

    @ApiModelProperty("授权凭证")
    private String jti;
}
