package cn.mesmile.admin.entity;

import cn.mesmile.common.base.BaseEntity;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

/**
 * <p>
 * 角色
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@EqualsAndHashCode(callSuper = true)
@Data
@TableName("sys_role")
@ApiModel(value = "Role对象", description = "角色")
public class Role extends BaseEntity {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("名称")
    @NotBlank(message = "角色名称不允许为空")
    private String name;

    @ApiModelProperty("代码")
    @NotBlank(message = "角色编码不允许为空")
    private String code;

    @ApiModelProperty("描述")
    private String description;

    @ApiModelProperty("创建人")
    private Long createBy;

}
