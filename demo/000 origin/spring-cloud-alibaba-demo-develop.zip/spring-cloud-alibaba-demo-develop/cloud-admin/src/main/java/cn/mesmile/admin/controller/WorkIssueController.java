package cn.mesmile.admin.controller;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.admin.entity.WebConfig;
import cn.mesmile.admin.entity.WorkIssue;
import cn.mesmile.admin.service.WorkIssueService;
import cn.mesmile.common.result.R;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.Date;

/**
 * <p>
 * 工单记录 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/work-issue")
@Api(tags = "客服工单相关api")
public class WorkIssueController {

    private final WorkIssueService workIssueService;

    @GetMapping("/get")
    @ApiOperation(value = "分页查询客服工单相关api", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current",value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size",value = "每页显示的条数",defaultValue = "10"),
            @ApiImplicitParam(name = "startTime",value = "开始时间"),
            @ApiImplicitParam(name = "endTime",value = "结束时间"),
            @ApiImplicitParam(name = "status",value = "状态")
    })
    @PreAuthorize("hasAuthority('work_issue_query')")
    public R<Page<WorkIssue>> findWorkIssuePage(@ApiIgnore Page<WorkIssue> page, Date startTime, Date endTime,Integer status){
        page.addOrder(OrderItem.desc("created"));
        Page<WorkIssue> workIssuePage = workIssueService.findWorkIssuePage(page, startTime ,endTime,status);
        return R.data(workIssuePage);
    }

    @PostMapping("/get")
    @ApiOperation(value = "回复工单", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id",value = "工单id"),
            @ApiImplicitParam(name = "answer",value = "回复内容")
    })
    @PreAuthorize("hasAuthority('work_issue_answer')")
    public R answer(Long id,String answer){

        boolean update = workIssueService.update(Wrappers.<WorkIssue>lambdaUpdate()
                .eq(WorkIssue::getId, id)
                .set(StrUtil.isNotBlank(answer), WorkIssue::getAnswer, answer)
                .set(WorkIssue::getAnswerUserId, 123456789L)
        );
        return R.data(update);
    }


    @GetMapping("/issueList")
    @ApiOperation(value = "前台分页查询客服工单相关api", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current",value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size",value = "每页显示的条数",defaultValue = "10"),
    })
    public R<Page<WorkIssue>> findWorkIssueSimplePage(@ApiIgnore Page<WorkIssue> page){
        // SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        // // TODO
        Long userId = 123456L;
        page.addOrder(OrderItem.desc("created"));
        Page<WorkIssue>  workIssuePage = workIssueService.findWorkIssueSimplePage(page, userId);
        return R.data(workIssuePage);
    }

    @PostMapping("/addWorkIssue")
    @ApiOperation(value = "前台用户提交工单", authorizations = {@Authorization("Authorization")})
    @ApiImplicitParams({
            @ApiImplicitParam(name = "question",value = "问题")
    })
    public R addWorkIssue(@RequestParam("question") WorkIssue  workIssue){
        // SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        // // TODO
        Long userId = 123456L;
        workIssue.setUserId(userId);
        workIssue.setQuestion(workIssue.getQuestion());
        workIssue.setStatus(1);
        boolean save = workIssueService.save(workIssue);
        return R.status(save);
    }


}
