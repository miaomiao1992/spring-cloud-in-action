package cn.mesmile.admin.service;

import cn.mesmile.admin.model.vo.LoginResultVO;

/**
 * @author zb
 * @date 2022/3/17 19:39
 * @Description
 */
public interface LoginService {

    /**
     *  后台管理人员登录接口
     * @param username 用户名
     * @param password 密码
     * @return
     */
    LoginResultVO login(String username, String password);
}
