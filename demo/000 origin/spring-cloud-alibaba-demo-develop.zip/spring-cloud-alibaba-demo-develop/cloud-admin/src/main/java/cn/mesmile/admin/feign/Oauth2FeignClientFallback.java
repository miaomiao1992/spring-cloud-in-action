package cn.mesmile.admin.feign;

import cn.mesmile.admin.model.dto.JwtTokenDTO;
import cn.mesmile.common.result.R;
import org.springframework.stereotype.Component;

/**
 * @author zb
 * @date 2022/3/17 19:56
 * @Description
 */
@Component
public class Oauth2FeignClientFallback implements Oauth2FeignClient {

    @Override
    public JwtTokenDTO getToken(String grantType, String username, String password, String loginType, String basicToken) {
        return null;
    }
}
