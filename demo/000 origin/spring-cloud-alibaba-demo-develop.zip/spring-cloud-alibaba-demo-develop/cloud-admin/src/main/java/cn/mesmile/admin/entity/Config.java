package cn.mesmile.admin.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 平台配置信息
 * </p>
 *
 * @author zb
 * @since 2022-03-17
 */
@Data
@TableName("config")
@ApiModel(value = "Config对象", description = "平台配置信息")
public class Config implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("配置规则类型")
    private String type;

    @ApiModelProperty("配置规则代码")
    private String code;

    @ApiModelProperty("配置规则名称")
    private String name;

//    @TableField(value = "`desc`")
    @ApiModelProperty("配置规则描述")
    private String desc;

    @ApiModelProperty("配置值")
    private String value;

    @TableField(value = "created",fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;


}
