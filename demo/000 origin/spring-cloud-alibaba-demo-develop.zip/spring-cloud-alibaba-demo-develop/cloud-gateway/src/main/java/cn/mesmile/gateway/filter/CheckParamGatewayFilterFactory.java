package cn.mesmile.gateway.filter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.Arrays;
import java.util.List;

/**
 * @author zb
 * @date 2022/3/5 20:02
 * @Description 自定义过滤器
 *          配置
 *          filters: #过滤器，请求在传递过程中通过过滤器修改
 *             - CheckParam=1
 */
@Component
public class CheckParamGatewayFilterFactory extends AbstractGatewayFilterFactory<CheckParamGatewayFilterFactory.Config> {

    /**
     * Prefix key.
     */
    public static final String PREFIX_KEY = "prefix";

    private static final Log log = LogFactory
            .getLog(CheckParamGatewayFilterFactory.class);

    public CheckParamGatewayFilterFactory() {
        super(CheckParamGatewayFilterFactory.Config.class);
    }

    @Override
    public List<String> shortcutFieldOrder() {
        return Arrays.asList(PREFIX_KEY);
    }

    @Override
    public GatewayFilter apply(CheckParamGatewayFilterFactory.Config config) {
        return new GatewayFilter() {
            @Override
            public Mono<Void> filter(ServerWebExchange exchange,
                                     GatewayFilterChain chain) {
                String prefix = config.getPrefix();

                return chain.filter(exchange);
//                boolean alreadyPrefixed = exchange
//                        .getAttributeOrDefault(GATEWAY_ALREADY_PREFIXED_ATTR, false);
//                if (alreadyPrefixed) {
//                    return chain.filter(exchange);
//                }
//                exchange.getAttributes().put(GATEWAY_ALREADY_PREFIXED_ATTR, true);
//
//                ServerHttpRequest req = exchange.getRequest();
//                addOriginalRequestUrl(exchange, req.getURI());
//                String newPath = config.prefix + req.getURI().getRawPath();
//
//                ServerHttpRequest request = req.mutate().path(newPath).build();
//
//                exchange.getAttributes().put(GATEWAY_REQUEST_URL_ATTR, request.getURI());
//
//                if (log.isTraceEnabled()) {
//                    log.trace("Prefixed URI with: " + config.prefix + " -> "
//                            + request.getURI());
//                }
//
//                return chain.filter(exchange.mutate().request(request).build());
            }

//            @Override
//            public String toString() {
//                return filterToStringCreator(CheckParamGatewayFilterFactory.this)
//                        .append("prefix", config.getPrefix()).toString();
//            }
        };
    }

    public static class Config {

        private String prefix;

        public String getPrefix() {
            return prefix;
        }

        public void setPrefix(String prefix) {
            this.prefix = prefix;
        }

    }

}

