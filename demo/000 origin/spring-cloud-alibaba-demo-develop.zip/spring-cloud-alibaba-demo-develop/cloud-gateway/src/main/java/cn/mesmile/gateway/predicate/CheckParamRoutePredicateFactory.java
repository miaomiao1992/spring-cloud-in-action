package cn.mesmile.gateway.predicate;

import org.springframework.cloud.gateway.handler.predicate.AbstractRoutePredicateFactory;
import org.springframework.cloud.gateway.handler.predicate.GatewayPredicate;
import org.springframework.stereotype.Component;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.server.ServerWebExchange;

import javax.validation.constraints.NotEmpty;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;

/**
 * @author zb
 * @date 2022/3/5 19:16
 * @Description 自定义断言
 *
 *      predicates: #断言 配置哪个路径才转发
 *         - Query=name,test|test2|test3 #http://localhost:8002/v1/user/list?name=test
 *         - CheckParam=test
 */
@Component
public class CheckParamRoutePredicateFactory extends
        AbstractRoutePredicateFactory<CheckParamRoutePredicateFactory.Config> {

    /**
     * Param key.
     */
    public static final String PARAM_KEY = "param";

//    /**
//     * Regexp key.
//     */
//    public static final String REGEXP_KEY = "regexp";

    public CheckParamRoutePredicateFactory() {
        super(CheckParamRoutePredicateFactory.Config.class);
    }

    @Override
    public List<String> shortcutFieldOrder() {
        return Arrays.asList(PARAM_KEY);
    }

    @Override
    public Predicate<ServerWebExchange> apply(CheckParamRoutePredicateFactory.Config config) {
        return new GatewayPredicate() {
            @Override
            public boolean test(ServerWebExchange exchange) {
                String param = config.getParam();
                if (Objects.equals("test", param)){
                    return true;
                }

//                if (!StringUtils.hasText(config.regexp)) {
//                    // check existence of header
//                    return exchange.getRequest().getQueryParams()
//                            .containsKey(config.param);
//                }
//
//                List<String> values = exchange.getRequest().getQueryParams()
//                        .get(config.param);
//                if (values == null) {
//                    return false;
//                }
//                for (String value : values) {
//                    if (value != null && value.matches(config.regexp)) {
//                        return true;
//                    }
//                }
                return false;
            }

        };
    }

    @Validated
    public static class Config {

        @NotEmpty
        private String param;

//        private String regexp;

        public String getParam() {
            return param;
        }

        public CheckParamRoutePredicateFactory.Config setParam(String param) {
            this.param = param;
            return this;
        }

//        public String getRegexp() {
//            return regexp;
//        }
//
//        public CheckParamRoutePredicateFactory.Config setRegexp(String regexp) {
//            this.regexp = regexp;
//            return this;
//        }

    }

}