package cn.mesmile.gateway.filter;

import cn.mesmile.gateway.utils.CloudRedisUtil;
import cn.mesmile.gateway.utils.WebUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.Set;

/**
 * @author zb
 * @date 2022/2/23 17:13
 * @Description 全局过滤器,权限认证
 */
@Component
public class GlobalApiFilter implements GlobalFilter, Ordered {

    private final CloudRedisUtil redisUtil;

    @Value("${auth.slip.url:/admin/login,/user/gt/register,/user/login}")
    private Set<String> skipUrl;

    public GlobalApiFilter(CloudRedisUtil redisUtil) {
        this.redisUtil = redisUtil;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
//        List<String> stringList = exchange.getRequest().getHeaders().get("Authorization");
        // 该接口是否需要token才能访问
        if (!isRequireToken(exchange)){
            return chain.filter(exchange);
        }

        // 取出用户的token
        String token = getUserToken(exchange);
        // 判断用户的token是否有效
        if (StringUtils.isEmpty(token)){
            ServerHttpResponse response = exchange.getResponse();
            Mono<Void> mono = WebUtil.renderString(response, "缺少认证信息");
            return mono;
        }

//        if (isTokenExpired(token)){
//            ServerHttpResponse response = exchange.getResponse();
//            Mono<Void> mono = WebUtil.renderString(response, "认证信息过期，请重新认证");
//            return mono;
//        }

        Boolean aBoolean = redisUtil.hasKey(token);
        if (aBoolean !=null && aBoolean){
            return chain.filter(exchange);
        }


        // 继续往下执行
        Mono<Void> filter = chain.filter(exchange);
        return filter;
    }

//    private boolean isTokenExpired(String token) {
//
//        return true;
//    }

    private String getUserToken(ServerWebExchange exchange) {
        // 写业务逻辑
        ServerHttpRequest request = exchange.getRequest();
        String token = request.getHeaders().getFirst("Authorization");
        return token == null ? null : token.replace("bearer ","");
    }

    /**
     * 是否必须要token才能访问
     * @param exchange
     * @return
     */
    private boolean isRequireToken(ServerWebExchange exchange) {
        String path = exchange.getRequest().getURI().getPath();
        if (skipUrl.contains(path)){
            return false;
        }
        return true;
    }



    @Override
    public int getOrder() {
        // 数字越小，优先级越高
        return 0;
    }
}
