package cn.mesmile.gateway.utils;

import com.alibaba.fastjson.JSONObject;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpResponse;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * @author zb
 * @date 2022/3/10 10:41
 * @Description
 */
public class WebUtil {

    public static Mono<Void> renderString(ServerHttpResponse response, String text) {
        try {
            response.setStatusCode(HttpStatus.UNAUTHORIZED);
            response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("success",false);
            jsonObject.put("code",HttpStatus.UNAUTHORIZED.value());
            jsonObject.put("msg",text);
            DataBuffer wrap = response.bufferFactory().wrap(jsonObject.toJSONString().getBytes());
            return response.writeWith(Flux.just(wrap));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
