//package cn.mesmile.gateway.config;
//
//import com.alibaba.csp.sentinel.adapter.gateway.sc.callback.BlockRequestHandler;
//import com.alibaba.csp.sentinel.adapter.gateway.sc.callback.GatewayCallbackManager;
//import com.alibaba.csp.sentinel.slots.block.authority.AuthorityException;
//import com.alibaba.csp.sentinel.slots.block.degrade.DegradeException;
//import com.alibaba.csp.sentinel.slots.block.flow.FlowException;
//import com.alibaba.csp.sentinel.slots.block.flow.param.ParamFlowException;
//import com.alibaba.csp.sentinel.slots.system.SystemBlockException;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.InvalidMediaTypeException;
//import org.springframework.http.MediaType;
//import org.springframework.stereotype.Component;
//import org.springframework.web.reactive.function.BodyInserters;
//import org.springframework.web.reactive.function.server.ServerResponse;
//import org.springframework.web.server.ServerWebExchange;
//import reactor.core.publisher.Mono;
//
//import javax.annotation.PostConstruct;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
///**
// * @author zb
// * @date 2022/2/22 14:32
// * @Description 自定义全局的 gateway sentinel 异常拦截处理 返回  和 InitBlockHandle 功能一样
// */
//@Component
//public class CloudSentinelBlockHandler implements BlockRequestHandler {
//
//    @PostConstruct
//    public void init(){
//        GatewayCallbackManager.setBlockHandler(new CloudSentinelBlockHandler());
//    }
//
//    /*
//        FlowException  限流异常
//        DegradeException  降级异常
//        ParamFlowException 参数限流异常
//        SystemBlockException 系统负载异常
//        AuthorityException 授权异常
//     */
//
//    @Override
//    public Mono<ServerResponse> handleRequest(ServerWebExchange exchange, Throwable e) {
////        if (acceptsHtml(exchange)) {
////            return htmlErrorResponse(e);
////        }
//
//        // 降级业务
//        Map<String,Object> backMap=new HashMap<>();
//        if (e instanceof FlowException){
//            backMap.put("code",-1);
//            backMap.put("msg","限流-异常啦");
//        }else if (e instanceof DegradeException){
//            backMap.put("code",-2);
//            backMap.put("msg","降级-异常啦");
//        }else if (e instanceof ParamFlowException){
//            backMap.put("code",-3);
//            backMap.put("msg","热点-异常啦");
//        }else if (e instanceof SystemBlockException){
//            backMap.put("code",-4);
//            backMap.put("msg","系统规则-异常啦");
//        }else if (e instanceof AuthorityException){
//            backMap.put("code",-5);
//            backMap.put("msg","认证-异常啦");
//        }
//
//        backMap.put("success",false);
//        return ServerResponse.status(HttpStatus.OK)
//                .header("content-Type","application/json;charset=UTF-8")
//                .body(BodyInserters.fromValue(backMap));
//        // 设置返回json数据
////                response.setStatus(200);
////                response.setHeader("content-Type","application/json;charset=UTF-8");
////                response.getWriter().write(JSONObject.toJSONString(backMap));
//    }
//
//    /**
//     * Reference from {@code DefaultErrorWebExceptionHandler} of Spring Boot.
//     */
//    private boolean acceptsHtml(ServerWebExchange exchange) {
//        try {
//            List<MediaType> acceptedMediaTypes = exchange.getRequest().getHeaders().getAccept();
//            acceptedMediaTypes.remove(MediaType.ALL);
//            MediaType.sortBySpecificityAndQuality(acceptedMediaTypes);
//            return acceptedMediaTypes.stream()
//                    .anyMatch(MediaType.TEXT_HTML::isCompatibleWith);
//        } catch (InvalidMediaTypeException ex) {
//            return false;
//        }
//    }
//
//    private static final String DEFAULT_BLOCK_MSG_PREFIX = "Blocked by Sentinel: ";
//
//    private Mono<ServerResponse> htmlErrorResponse(Throwable ex) {
//        return ServerResponse.status(HttpStatus.TOO_MANY_REQUESTS)
//                .contentType(MediaType.TEXT_PLAIN)
//                .syncBody(DEFAULT_BLOCK_MSG_PREFIX + ex.getClass().getSimpleName());
//    }
//
//}
