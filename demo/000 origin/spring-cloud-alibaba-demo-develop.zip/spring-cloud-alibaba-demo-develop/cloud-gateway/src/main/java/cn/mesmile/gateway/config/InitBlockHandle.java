package cn.mesmile.gateway.config;

import com.alibaba.csp.sentinel.adapter.gateway.sc.callback.BlockRequestHandler;
import com.alibaba.csp.sentinel.adapter.gateway.sc.callback.GatewayCallbackManager;
import com.alibaba.csp.sentinel.slots.block.authority.AuthorityException;
import com.alibaba.csp.sentinel.slots.block.degrade.DegradeException;
import com.alibaba.csp.sentinel.slots.block.flow.FlowException;
import com.alibaba.csp.sentinel.slots.block.flow.param.ParamFlowException;
import com.alibaba.csp.sentinel.slots.system.SystemBlockException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerResponse;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

/**
 * @author zb
 * @date 2022/3/5 21:39
 * @Description 自定义sentinel限流后发送异常，返回友好提示
 *
 *          SentinelSCGAutoConfiguration 类中 已经配置好了 adapter 相关配置
 */
@Component
public class InitBlockHandle {

    @PostConstruct
    public void init(){
        BlockRequestHandler blockRequestHandler = new BlockRequestHandler() {
            @Override
            public Mono<ServerResponse> handleRequest(ServerWebExchange serverWebExchange, Throwable e) {
                // 降级业务
                Map<String,Object> backMap=new HashMap<>();
                if (e instanceof FlowException){
                    backMap.put("code",-1);
                    backMap.put("msg","限流-异常啦");
                }else if (e instanceof DegradeException){
                    backMap.put("code",-2);
                    backMap.put("msg","降级-异常啦");
                }else if (e instanceof ParamFlowException){
                    backMap.put("code",-3);
                    backMap.put("msg","热点-异常啦");
                }else if (e instanceof SystemBlockException){
                    backMap.put("code",-4);
                    backMap.put("msg","系统规则-异常啦");
                }else if (e instanceof AuthorityException){
                    backMap.put("code",-5);
                    backMap.put("msg","认证-异常啦");
                }

                backMap.put("success",false);
                return ServerResponse.status(HttpStatus.OK)
                        .header("content-Type","application/json;charset=UTF-8")
                        .body(BodyInserters.fromValue(backMap));
            }

        };
        GatewayCallbackManager.setBlockHandler(blockRequestHandler);
    }
}
