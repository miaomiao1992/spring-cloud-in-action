package cn.mesmile.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @author zb
 * @date 2022/2/23 16:57
 * @Description https://www.bilibili.com/video/BV1g3411L7Yv?p=32&spm_id_from=pageDriver
 */
// @EnableFeignClients(basePackages = {"cn.mesmile"})
// @MapperScan("cn.mesmile.gateway.mapper")
@EnableDiscoveryClient
@SpringBootApplication(scanBasePackages = {"cn.mesmile"})
public class GatewayApplication {

    public static void main(String[] args) {
        SpringApplication.run(GatewayApplication.class, args);
    }

}
