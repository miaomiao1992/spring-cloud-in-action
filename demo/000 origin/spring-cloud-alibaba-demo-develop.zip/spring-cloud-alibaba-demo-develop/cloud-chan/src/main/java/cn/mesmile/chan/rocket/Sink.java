package cn.mesmile.chan.rocket;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.messaging.MessageChannel;

/**
 * @author zb
 * @date 2022/3/23 11:22
 * @Description
 */
public interface Sink {

    /**
     *  @Input 生产者
     *  @Output 消息者
     */
    @Input("tio_message")
    MessageChannel messageChannel();
}
