package cn.mesmile.chan.model;

import cn.hutool.core.util.CharsetUtil;
import com.alibaba.fastjson.JSONObject;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.joda.time.DateTime;
import org.tio.websocket.common.WsResponse;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * @author zb
 * @date 2022/3/23 12:10
 * @Description  websocket 返回给前端的数据
 */
@Data
public class WebSocketResponseEntity {

    @ApiModelProperty("推送的id")
    private String id;

    @ApiModelProperty("推送的channel")
    private String ch;

    @ApiModelProperty("状态")
    private String status;

    @ApiModelProperty("订阅的组名")
    private String subbed;

    @ApiModelProperty("取消订阅的组名")
    private String canceled;

    @ApiModelProperty("发送的事件")
    private String event;

    @ApiModelProperty("时间戳")
    private Long ts;

    public Long getTs(){
        return new DateTime().getMillis();
    }

    private Map<String,Object> extend = new LinkedHashMap<>(16);

    public WsResponse build(){
        extend.put("id",this.getId());
        extend.put("ch",this.getCh());
        extend.put("status",this.getStatus());
        extend.put("subbed",this.getSubbed());
        extend.put("canceled",this.getCanceled());
        extend.put("event",this.getEvent());
        extend.put("ts",this.getTs());
        return WsResponse.fromText(JSONObject.toJSONString(extend), CharsetUtil.UTF_8);
    }

    public WebSocketResponseEntity put(String key, Object value){
        extend.put(key, value);
        return this;
    }

}
