package cn.mesmile.chan.controller;

import cn.mesmile.chan.model.MessagePayload;
import cn.mesmile.chan.rocket.Sink;
import cn.mesmile.common.result.R;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zb
 * @date 2022/3/23 11:35
 * @Description
 */
@Slf4j
@Api(value = "发送消息相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/message")
public class SendMessageController {

    @Autowired
    private Sink sink;

    @GetMapping("/send/{channel}")
    @ApiOperation("模拟向rocket中发送消息，然后再发送到 websocket 中")
    public R sendMessage(@PathVariable("channel")String channel){
        List<MessagePayload> resultList = new ArrayList<>();
        for (int i = 0; i < 3; i++) {
            MessagePayload messagePayload = new MessagePayload();
            String string = "第【"+ i +"】条消息体："+ (i*3);
            messagePayload.setBody(string);
            // messagePayload.setUserId("admin");
            messagePayload.setChannel(channel);
            MessageBuilder<MessagePayload> messageBuilder = MessageBuilder.withPayload(messagePayload)
                    .setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON);
            boolean send = sink.messageChannel().send(messageBuilder.build());
            log.info(">>>>>>>>>> 发送消息结果："+ send);
            resultList.add(messagePayload);
        }
        return R.data(resultList);
    }

}
