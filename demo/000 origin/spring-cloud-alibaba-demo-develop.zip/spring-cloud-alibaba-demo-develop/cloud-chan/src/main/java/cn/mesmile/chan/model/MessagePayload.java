package cn.mesmile.chan.model;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author zb
 * @date 2022/3/23 12:38
 * @Description
 */
@Data
public class MessagePayload {

    @ApiModelProperty("用户id")
    private String userId;

    @ApiModelProperty("订阅组名称")
    private String channel;

    @ApiModelProperty("消息内容")
    private String body;
}
