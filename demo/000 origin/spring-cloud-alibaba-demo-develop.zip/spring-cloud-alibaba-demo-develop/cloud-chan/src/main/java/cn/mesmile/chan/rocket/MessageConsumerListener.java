package cn.mesmile.chan.rocket;

import cn.hutool.core.util.CharsetUtil;
import cn.hutool.core.util.StrUtil;
import cn.mesmile.chan.handler.WebsocketMessageHandler;
import cn.mesmile.chan.model.MessagePayload;
import cn.mesmile.chan.model.WebSocketResponseEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.stereotype.Service;
import org.tio.core.Tio;
import org.tio.server.ServerTioConfig;
import org.tio.websocket.common.WsResponse;
import org.tio.websocket.starter.TioWebSocketServerBootstrap;

import static org.tio.core.Tio.sendToGroup;

/**
 * @author zb
 * @date 2022/3/21 23:27
 * @Description 消费者
 */
@Slf4j
@Service
public class MessageConsumerListener {

    @Autowired
    private TioWebSocketServerBootstrap webSocketServerBootstrap;

    // 监听队列 order.in
    @StreamListener("tio_message")
    public void handleMessage(MessagePayload messagePayload){
        ServerTioConfig serverTioConfig = webSocketServerBootstrap.getServerTioConfig();

        log.info(">>>>> websocket 开始发送消息 =====》{}", messagePayload);

        WebSocketResponseEntity webSocketResponseEntity = new WebSocketResponseEntity();
        webSocketResponseEntity.setCh(messagePayload.getChannel());
        webSocketResponseEntity.setStatus("OK");
        webSocketResponseEntity.setSubbed(messagePayload.getChannel());
        webSocketResponseEntity.put("result", messagePayload.getBody());

        if (StrUtil.isNotBlank(messagePayload.getUserId())){
            Boolean aBoolean = Tio.sendToUser(webSocketServerBootstrap.getServerTioConfig(),
                    messagePayload.getUserId(), webSocketResponseEntity.build());
            log.info(">>>>> websocket 发送个人成功 =====》{}", messagePayload);
            return;
        }
        // 发送数据
        Tio.sendToGroup(serverTioConfig, messagePayload.getChannel(), webSocketResponseEntity.build());
        log.info(">>>>> websocket 发送成功 =====》{}", messagePayload);
    }


}
