package cn.mesmile.chan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.tio.websocket.starter.EnableTioWebSocketServer;

/**
 * @author zb
 * @date 2022/3/22 22:48
 * @Description 推送服务
 *      @EnableTioWebSocketServer 开启tio
 *      websocket 测试 http://www.websocket-test.com
 *      tio 官网    https://www.tiocloud.com/
 *      https://www.tiocloud.com/1/blog/1477876378442539008?type=screen-category
 */
@EnableTioWebSocketServer
@SpringBootApplication(scanBasePackages = {"cn.mesmile"})
// @EnableScheduling
public class ChanApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChanApplication.class, args);
    }

    // @Autowired
    // private TioWebSocketServerBootstrap tioWebSocketServerBootstrap;
    //
    // @Scheduled(fixedRate = 5000)
    // public void pushData(){
    //     // 使用Tio推送简单数据
    //     Tio.sendToGroup(tioWebSocketServerBootstrap.getServerTioConfig(),"test",
    //             WsResponse.fromText("现在时间是："+ DateUtil.now(),"UTF-8"));
    //     System.out.println("----------------send---------------");
    // }
}
