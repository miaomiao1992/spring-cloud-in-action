package cn.mesmile.member.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.validation.annotation.Validated;

/**
 * <p>
 * 用户表
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Data
@TableName("user")
@ApiModel(value = "User对象", description = "用户表")
public class UserMember implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("自增id")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户类型：1-普通用户；2-代理人")
    private Integer type;

    @ApiModelProperty("用户名")
    private String username;

    @ApiModelProperty("国际电话区号")
    private String countryCode;

    @ApiModelProperty("手机号")
    private String mobile;

    @ApiModelProperty("密码")
    private String password;

    @ApiModelProperty("交易密码")
    private String paypassword;

    @ApiModelProperty("交易密码设置状态")
    private Boolean paypassSetting;

    @ApiModelProperty("邮箱")
    private String email;

    @ApiModelProperty("真实姓名")
    private String realName;

    @ApiModelProperty("证件类型:1，身份证；2，军官证；3，护照；4，台湾居民通行证；5，港澳居民通行证；9，其他；")
    private Integer idCardType;

    @ApiModelProperty("认证状态：0-未认证；1-初级实名认证；2-高级实名认证")
    private Integer authStatus;

    @ApiModelProperty("Google令牌秘钥")
    private String gaSecret;

    @ApiModelProperty("Google认证开启状态,0,未启用，1启用")
    private Boolean gaStatus;

    @ApiModelProperty("身份证号")
    private String idCard;

    @ApiModelProperty("代理商级别")
    private Integer level;

    @ApiModelProperty("认证时间")
    private Date authtime;

    @ApiModelProperty("登录数")
    private Integer logins;

    @ApiModelProperty("状态：0，禁用；1，启用；")
    private Integer status;

    @ApiModelProperty("邀请码")
    private String inviteCode;

    @ApiModelProperty("邀请关系")
    private String inviteRelation;

    @ApiModelProperty("直接邀请人ID")
    private String directInviteid;

    @ApiModelProperty("0 否 1是  是否开启平台币抵扣手续费")
    private Integer isDeductible;

    @ApiModelProperty("审核状态,1通过,2拒绝,0,待审核")
    private Integer reviewsStatus;

    @ApiModelProperty("代理商拒绝原因")
    private String agentNote;

    @ApiModelProperty("API的KEY")
    private String accessKeyId;

    @ApiModelProperty("API的密钥")
    private String accessKeySecret;

    @ApiModelProperty("引用认证状态id")
    private Long refeAuthId;

    @TableField(value = "last_update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;

    @TableField(value = "created",fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;

    @ApiModelProperty("会员的高级认证状态 0审核中，1通过，2拒绝(拒绝的理由)，3未填写")
    @TableField(exist = false)
    private Integer seniorAuthStatus;

    @ApiModelProperty("拒绝的理由")
    @TableField(exist = false)
    private String seniorAuthDesc;

}
