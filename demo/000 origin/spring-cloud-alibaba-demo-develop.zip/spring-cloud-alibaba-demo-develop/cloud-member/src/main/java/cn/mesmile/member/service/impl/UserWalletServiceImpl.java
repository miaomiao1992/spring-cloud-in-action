package cn.mesmile.member.service.impl;

import cn.mesmile.member.entity.UserWallet;
import cn.mesmile.member.mapper.UserWalletMapper;
import cn.mesmile.member.service.UserWalletService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户提币地址 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Service
public class UserWalletServiceImpl extends ServiceImpl<UserWalletMapper, UserWallet> implements UserWalletService {

    @Override
    public Page<UserWallet> findUserWalletPage(Page<UserWallet> page, Long userId) {
        Page<UserWallet> result = page(page, Wrappers.<UserWallet>lambdaQuery()
                .eq(userId != null, UserWallet::getUserId, userId));
        return result;
    }
}
