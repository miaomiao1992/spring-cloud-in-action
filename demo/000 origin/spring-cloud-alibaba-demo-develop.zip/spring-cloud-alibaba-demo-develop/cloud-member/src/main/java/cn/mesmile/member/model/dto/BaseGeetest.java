package cn.mesmile.member.model.dto;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.common.exception.ServiceException;
import cn.mesmile.common.utils.CloudRedisUtil;
import cn.mesmile.member.geetest.GeetestLib;
import cn.mesmile.member.geetest.entity.GeetestLibResult;
import cn.mesmile.member.geetest.enums.DigestmodEnum;
import com.alibaba.fastjson.JSONObject;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zb
 * @date 2022/3/21 9:40
 * @Description
 */
@Slf4j
@Data
public class BaseGeetest {


    /**
     * 极验 二次校验数据
     */
    private String geetest_challenge;

    private String geetest_seccod;

    private String geetest_validate;

    private String uuid;

    /**
     * 后端 二次校验 验证码
     * @param cloudRedisUtil
     * @param geetestLib
     */
    public void checkFormData(CloudRedisUtil cloudRedisUtil, GeetestLib geetestLib) {
        if (!StrUtil.isAllNotEmpty(geetest_challenge, geetest_validate, geetest_seccod)){
            throw new ServiceException("验证码参数异常");
        }
        /**
         * 极验二次校验
         */
        String uuidStr = (String) cloudRedisUtil.get(GeetestLib.GEETEST_SERVER_USER_KEY + ":" + uuid);
        Integer status = (Integer) cloudRedisUtil.get(GeetestLib.GEETEST_SERVER_STATUS_SESSION_KEY);

        GeetestLibResult result = null;
        // 检测存入redis中的极验云状态标识
        if (status != null && status == 1){
            DigestmodEnum digestmodEnum = DigestmodEnum.MD5;
            Map<String, String> paramMap = new HashMap<>(8);
            paramMap.put("digestmod", digestmodEnum.getName());
            paramMap.put("user_id", uuidStr);
            paramMap.put("client_type", "web");
            result = geetestLib.successValidate(geetest_challenge, geetest_validate, geetest_seccod, paramMap);
        } else {
            result = geetestLib.failValidate(geetest_challenge, geetest_validate, geetest_seccod);
        }
        if (result.getStatus() != 1){
            log.info("验证数据异常："+ JSONObject.toJSONString(result,true));
            throw new ServiceException("验证码异常");
        }
    }
}
