package cn.mesmile.member.mappers;

import cn.mesmile.member.entity.UserMember;
import cn.mesmile.member.model.dto.UserMemberDTO;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;

/**
 * @author zb
 * @date 2022/3/20 11:02
 * @Description  用法 UserMemberDtoMapper.INSTANCE.convert2Dto(UserMember userMember)
 *  entity 转 dto
 *  dto 转 entity
 */
@Mapper(componentModel = "spring")
public interface UserMemberDtoMapper {
    /**
     * 获取该对象实例
     */
    UserMemberDtoMapper INSTANCE = Mappers.getMapper(UserMemberDtoMapper.class);

    /**
     *  将 entity 转换成 dto
     * @param userMember
     * @return
     */
    UserMemberDTO convert2Dto(UserMember userMember);

    /**
     *  将 dto 转换成 entity
     * @param userMemberDTO
     * @return
     */
    UserMember convert2Entity(UserMemberDTO userMemberDTO);

    /**
     *  将 entity 转换成 dto
     * @param userMember
     * @return
     */
    List<UserMemberDTO> convert2Dto(List<UserMember> userMember);

    /**
     *  将 dto 转换成 entity
     * @param userMemberDTO
     * @return
     */
    List<UserMember> convert2Entity(List<UserMemberDTO> userMemberDTO);
}
