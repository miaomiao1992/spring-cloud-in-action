package cn.mesmile.member.mapper;

import cn.mesmile.member.entity.Sms;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 短信信息 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface SmsMapper extends BaseMapper<Sms> {

}
