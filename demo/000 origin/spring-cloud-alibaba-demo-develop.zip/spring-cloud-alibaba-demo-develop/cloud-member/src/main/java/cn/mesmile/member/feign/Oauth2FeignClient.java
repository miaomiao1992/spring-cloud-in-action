package cn.mesmile.member.feign;

import cn.mesmile.common.constant.ApplicationConstant;
import cn.mesmile.member.model.dto.JwtTokenDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author zb
 * @date 2022/3/17 19:48
 * @Description
 */
@FeignClient(name = ApplicationConstant.AUTH_APPLICATION_NAME, fallback = Oauth2FeignClientFallback.class)
public interface Oauth2FeignClient {

    /**
     *  获取token
     * @param grantType 授权类型
     * @param username 用户名
     * @param password 密码
     * @param loginType 自定义登录类型
     * @param basicToken 第三方客户端加密生成 Basic aWNvbi1hcHA6aWNvbi1zZWNyZXQ=
     * @return 登录结果
     */
    @PostMapping("/oauth/token")
    ResponseEntity<JwtTokenDTO> getToken(@RequestParam("grant_type") String grantType, @RequestParam("username") String username,
                                        @RequestParam("password") String password, @RequestParam("login_type") String loginType,
                                        @RequestHeader("Authorization") String basicToken);





}
