package cn.mesmile.member.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author zb
 * @date 2022/3/19 22:33
 * @Description
 */
@Data
@ApiModel("修改手机号")
public class UpdatePhoneForm {

    @ApiModelProperty("国家的code")
    @NotBlank(message = "国家区号不允许为空")
    private String countryCode;

    @ApiModelProperty("新的手机号")
    @NotBlank(message = "国家区号不允许为空")
    private String newMobilePhone;

    @ApiModelProperty("新手机号的验证码")
    @NotBlank(message = "国家区号不允许为空")
    private String validateCode;

    @ApiModelProperty("旧的手机号验证码")
    @NotBlank(message = "国家区号不允许为空")
    private String oldValidateCode;

}
