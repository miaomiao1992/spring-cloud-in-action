package cn.mesmile.member.service;

import cn.mesmile.member.entity.UserLoginLog;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户登录日志 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface UserLoginLogService extends IService<UserLoginLog> {

}
