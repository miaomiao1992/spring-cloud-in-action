package cn.mesmile.member.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.member.entity.Sms;
import cn.mesmile.member.service.SmsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 短信信息 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@RestController
@RequestMapping("/sms")
@RequiredArgsConstructor
@Api(tags = "发送短信管理")
public class SmsController {

    private final SmsService smsService;


    @PostMapping("/sendTo")
    @ApiOperation("发送短信")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "sms的json数据",name = "sms")
    })
    public R sendTo(@RequestBody @Validated Sms sms){
        boolean result = smsService.sendSms(sms);
        return R.status(result);
    }


}
