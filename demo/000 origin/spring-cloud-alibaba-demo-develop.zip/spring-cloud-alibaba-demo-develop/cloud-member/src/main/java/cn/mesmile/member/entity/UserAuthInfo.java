package cn.mesmile.member.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 实名认证信息
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Getter
@Setter
@TableName("user_auth_info")
@ApiModel(value = "UserAuthInfo对象", description = "实名认证信息")
public class UserAuthInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户ID")
    private Long userId;

    @ApiModelProperty("图片地址")
    private String imageUrl;

    @ApiModelProperty("序号：1-身份证正面照；2-身份证反面照；3-手持身份证照片；")
    private Integer serialno;

    @TableField(value = "last_update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @TableField(value = "created",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("创建时间")
    private Date created;

    @ApiModelProperty("用户每组审核记录唯一标识")
    private Long authCode;


}
