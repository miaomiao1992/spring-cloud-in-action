package cn.mesmile.member;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @author zb
 * @date 2022/3/18 23:11
 * @Description
 *      极验验证码  https://docs.geetest.com/sensebot/deploy/server/java
 *      阿里云 云市场  身份证实名认证
 *      会员模块
 */
@EnableFeignClients(basePackages = {"cn.mesmile"})
@MapperScan("cn.mesmile.member.mapper")
@EnableDiscoveryClient
@SpringBootApplication(scanBasePackages = "cn.mesmile")
public class MemberApplication {

    public static void main(String[] args) {
        SpringApplication.run(MemberApplication.class, args);
    }

}
