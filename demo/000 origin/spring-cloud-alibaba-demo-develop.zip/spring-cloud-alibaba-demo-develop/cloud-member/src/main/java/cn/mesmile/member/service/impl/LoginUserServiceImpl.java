package cn.mesmile.member.service.impl;

import cn.mesmile.common.exception.ServiceException;
import cn.mesmile.common.utils.CloudRedisUtil;
import cn.mesmile.member.feign.Oauth2FeignClient;
import cn.mesmile.member.geetest.GeetestLib;
import cn.mesmile.member.model.dto.JwtTokenDTO;
import cn.mesmile.member.model.dto.LoginForm;
import cn.mesmile.member.model.vo.LoginUserVO;
import cn.mesmile.member.service.LoginUserService;
import cn.mesmile.member.utils.GeetestUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

/**
 * @author zb
 * @date 2022/3/19 17:19
 * @Description
 */
@Slf4j
@Service
public class LoginUserServiceImpl implements LoginUserService {

    @Autowired
    private Oauth2FeignClient oauth2FeignClient;
    @Autowired
    private CloudRedisUtil cloudRedisUtil;
    @Autowired
    private GeetestLib geetestLib;

    private static final String basicToken = "Basic aWNvbi1hcHA6aWNvbi1zZWNyZXQ=";

    @Override
    public LoginUserVO login(LoginForm loginForm) {
        // 校验极验的数据
        loginForm.checkFormData(cloudRedisUtil, geetestLib);
        // GeetestUtil.checkFormData(loginForm.getGeetest_challenge(),loginForm.getGeetest_validate(),
        //         loginForm.getGeetest_seccod(),loginForm.getUuid(),cloudRedisUtil, geetestLib);
        // 登录
        ResponseEntity<JwtTokenDTO> responseEntity = oauth2FeignClient.getToken("password", loginForm.getUsername(), loginForm.getPassword(), "test", basicToken);
        if (responseEntity.getStatusCode() != HttpStatus.OK || responseEntity.getBody() == null){
            throw new ServiceException("登录异常");
        }
        JwtTokenDTO token = responseEntity.getBody();
        LoginUserVO loginUserVO = new LoginUserVO();
        loginUserVO.setUsername(loginForm.getUsername());
        loginUserVO.setExpire(token.getExpiresIn());
        loginUserVO.setAccess_token(token.getTokenType()+" "+token.getAccessToken());
        loginUserVO.setRefresh_token(token.getRefreshToken());

        // 将token存入redis
        cloudRedisUtil.setEx(token.getAccessToken(),"",token.getExpiresIn(), TimeUnit.SECONDS);

        return loginUserVO;
    }

}
