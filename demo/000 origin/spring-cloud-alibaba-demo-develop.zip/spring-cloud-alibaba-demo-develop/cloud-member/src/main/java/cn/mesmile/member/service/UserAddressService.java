package cn.mesmile.member.service;

import cn.mesmile.member.entity.UserAddress;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户钱包地址信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface UserAddressService extends IService<UserAddress> {

    /**
     *  分页查询用户钱包地址
     * @param page
     * @param userId
     * @return
     */
    Page<UserAddress> findUserAddressPage(Page<UserAddress> page, Long userId);
}
