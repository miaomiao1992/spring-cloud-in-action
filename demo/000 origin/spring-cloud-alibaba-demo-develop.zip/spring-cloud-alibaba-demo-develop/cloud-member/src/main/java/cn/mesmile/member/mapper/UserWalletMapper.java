package cn.mesmile.member.mapper;

import cn.mesmile.member.entity.UserWallet;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户提币地址 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface UserWalletMapper extends BaseMapper<UserWallet> {

}
