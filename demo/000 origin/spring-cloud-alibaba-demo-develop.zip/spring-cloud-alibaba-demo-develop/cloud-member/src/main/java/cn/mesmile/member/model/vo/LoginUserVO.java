package cn.mesmile.member.model.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author zb
 * @date 2022/3/19 17:16
 * @Description
 */
@Data
@ApiModel("登录成功返回")
public class LoginUserVO {

    @ApiModelProperty("用户名")
    private String username;

    @ApiModelProperty("token的过期时间")
    private Integer expire;

    @ApiModelProperty("认证token")
    private String access_token;

    @ApiModelProperty("刷新认证token")
    private String refresh_token;

}
