package cn.mesmile.member.feign;

import cn.mesmile.member.model.dto.JwtTokenDTO;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

/**
 * @author zb
 * @date 2022/3/17 19:56
 * @Description
 */
@Component
public class Oauth2FeignClientFallback implements Oauth2FeignClient {

    @Override
    public ResponseEntity<JwtTokenDTO> getToken(String grantType, String username, String password, String loginType, String basicToken) {
        return null;
    }
}
