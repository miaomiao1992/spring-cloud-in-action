package cn.mesmile.member.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 用户钱包地址信息
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Getter
@Setter
@TableName("user_address")
@ApiModel(value = "UserAddress对象", description = "用户钱包地址信息")
public class UserAddress implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户ID")
    private Long userId;

    @ApiModelProperty("币种ID")
    private Long coinId;

    @ApiModelProperty("地址")
    private String address;

    @ApiModelProperty("keystore")
    private String keystore;

    @ApiModelProperty("密码")
    private String pwd;

    @TableField(value = "last_update_time", fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @TableField(value = "created", fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;

    private Long markid;

    @TableField(exist = false)
    @ApiModelProperty("币种名称")
    private String coinName;

}
