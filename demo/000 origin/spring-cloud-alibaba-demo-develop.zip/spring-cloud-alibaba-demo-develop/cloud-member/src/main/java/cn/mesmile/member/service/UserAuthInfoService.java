package cn.mesmile.member.service;

import cn.mesmile.member.entity.UserAuthInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 实名认证信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface UserAuthInfoService extends IService<UserAuthInfo> {

}
