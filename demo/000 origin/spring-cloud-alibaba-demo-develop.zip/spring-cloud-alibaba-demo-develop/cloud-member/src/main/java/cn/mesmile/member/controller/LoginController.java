package cn.mesmile.member.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.member.model.dto.LoginForm;
import cn.mesmile.member.model.vo.LoginUserVO;
import cn.mesmile.member.service.LoginUserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zb
 * @date 2022/3/19 17:11
 * @Description
 */
@RestController
@RequiredArgsConstructor
@Api(tags = "验证码管理")
public class LoginController {

    private final LoginUserService loginUserService;

    @PostMapping("/login")
    @ApiOperation("会员登录")
    @ApiImplicitParam(value = "loginForm的json数据，会员登录",name = "loginForm")
    public R<LoginUserVO> login(@RequestBody @Validated LoginForm loginForm){
        LoginUserVO result = loginUserService.login(loginForm);
        return R.data(result);
    }
}
