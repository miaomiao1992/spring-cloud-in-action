package cn.mesmile.member.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.member.entity.UserMember;
import cn.mesmile.member.model.dto.*;
import cn.mesmile.member.service.UserMemberService;
import cn.mesmile.member.model.vo.UserAuthInfoVO;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
@Api(tags = "会员管理")
public class UserMemberController {

    private final UserMemberService userMemberService;

    @GetMapping
    @ApiOperation("查询分页会员列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size", value = "每页显示条数",defaultValue = "10"),
            @ApiImplicitParam(name = "userId", value = "用户id"),
            @ApiImplicitParam(name = "username", value = "用户名"),
            @ApiImplicitParam(name = "realName", value = "真实姓名"),
            @ApiImplicitParam(name = "mobile", value = "手机号"),
            @ApiImplicitParam(name = "status", value = "状态，0禁用，1启用")
    })
    @PreAuthorize("hasAuthority('user_qurey')")
    public R<Page<UserMember>> findUserMemberPage(@ApiIgnore Page<UserMember> page,Long userId ,String username,
                                              String realName, String mobile, Integer status){
        page.addOrder(OrderItem.desc("created"));
        Page<UserMember> result = userMemberService.findUserMemberPage(page, userId, username, realName, mobile ,status);
        return R.data(result);
    }


    @PostMapping("/status")
    @ApiOperation("修改用户状态")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "用户id"),
            @ApiImplicitParam(name = "status", value = "状态"),
    })
    @PreAuthorize("hasAuthority('user_qurey')")
    public R status(Long id ,Integer status){
        boolean update = userMemberService.update(Wrappers.<UserMember>lambdaUpdate()
                .eq(UserMember::getId, id)
                .set(UserMember::getStatus, status)
        );
        return R.status(update);
    }

    @PatchMapping
    @ApiOperation("修改用户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userMember", value = "userMember的json数据"),
    })
    @PreAuthorize("hasAuthority('user_update')")
    public R status(@RequestBody UserMember userMember){
        boolean update = userMemberService.updateById(userMember);
        return R.status(update);
    }

    @GetMapping("/info")
    @ApiOperation("查看用户详情")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "userMember的id")
    })
    @PreAuthorize("hasAuthority('user_update')")
    public R<UserMember> userInfo(@RequestParam("id")Long id){
        UserMember userMember = userMemberService.getById(id);
        return R.data(userMember);
    }

    @GetMapping("/directInvites")
    @ApiOperation("查询该用户邀请的用户列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size", value = "每页显示条数",defaultValue = "10"),
            @ApiImplicitParam(name = "userId", value = "userMember的id")
    })
    public R<Page<UserMember>> getDirectInvitesPage(@ApiIgnore Page<UserMember> page,Long userId ){
        Page<UserMember> result = userMemberService.getDirectInvitesPage(page, userId);
        return R.data(result);
    }

    @GetMapping("/auths")
    @ApiOperation("查询分页会员审核列表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size", value = "每页显示条数",defaultValue = "10"),
            @ApiImplicitParam(name = "userId", value = "用户id"),
            @ApiImplicitParam(name = "username", value = "用户名"),
            @ApiImplicitParam(name = "realName", value = "真实姓名"),
            @ApiImplicitParam(name = "mobile", value = "手机号"),
            @ApiImplicitParam(name = "reviewsStatus", value = "审核状态,1通过,2拒绝,0,待审核")
    })
//    @PreAuthorize("hasAuthority('user_qurey')")
    public R<Page<UserMember>> findAuthUserMemberPage(@ApiIgnore Page<UserMember> page,Long userId ,String username,
                                                  String realName, String mobile, Integer reviewsStatus){
        page.addOrder(OrderItem.desc("created"));
        Page<UserMember> result = userMemberService.findAuthUserMemberPage(page, userId, username, realName, mobile ,reviewsStatus);
        return R.data(result);
    }


    @GetMapping("/auths/info")
    @ApiOperation("查询会员认证审核信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "用户id")
    })
//    @PreAuthorize("hasAuthority('user_qurey')")
    public R<UserAuthInfoVO> getAuthInfo(Long id){
        UserAuthInfoVO userAuthInfoVO = userMemberService.getAuthInfo(id);
        return R.data(userAuthInfoVO);
    }

    @PostMapping("/auths/status")
    @ApiOperation("查询会员认证审核")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "用户id"),
            @ApiImplicitParam(name = "authStatus", value = "认证状态"),
            @ApiImplicitParam(name = "authCode", value = "认证编号"),
            @ApiImplicitParam(name = "remark", value = "拒绝原因")
    })
//    @PreAuthorize("hasAuthority('user_qurey')")
    public R updateAuthStatus(@RequestParam("id") Long id,@RequestParam("authStatus") Integer authStatus,
                              @RequestParam("authCode") Long authCode,@RequestParam("remark")String remark){
        boolean result = userMemberService.updateAuthStatus(id, authStatus, authCode,remark);
        return R.status(result);
    }

    @GetMapping("/current/info")
    @ApiOperation("查询当前用户id")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "用户id")
    })
    public R<UserMember> getCurrentUsrInfo(Long id){
//        SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        UserMember userMember = userMemberService.getById(id);
        userMember.setPassword("**********");
        userMember.setPaypassword("**********");
        userMember.setAccessKeyId("**********");
        userMember.setAccessKeySecret("**********");
        return R.data(userMember);
    }

    @GetMapping("/authAccount")
    @ApiOperation("用户的实名认证")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "",name = "")
    })
    public R identifyCheck(UserAuthForm userAuthForm){
//        SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        // todo 优化
        Long userId = 12345678L;
        boolean checkResult = userMemberService.identifyCheck(userId,userAuthForm);
        return R.status(checkResult);
    }

    @PostMapping("/authUser")
    @ApiOperation("用户进行高级认证，上传身份证")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "",name = "")
    })
    public R identifyCheck(@RequestBody List<String> images){
//        SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        // todo 优化
        Long userId = 12345678L;
        userMemberService.authUser(userId, images);
        return R.status(true);
    }

    @PostMapping("/updatePhone")
    @ApiOperation("修改手机号")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "updatePhoneForm的json数据",name = "updatePhoneForm")
    })
    public R updatePhone(@RequestBody @Validated UpdatePhoneForm updatePhoneForm){
//        SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        boolean result = userMemberService.updatePhone(updatePhoneForm);
        return R.status(result);
    }


    @GetMapping("/checkTel")
    @ApiOperation("检查新手机号是否可用")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "手机号码",name = "mobile"),
            @ApiImplicitParam(value = "国家区号",name = "countryCode"),
    })
    public R checkTel(@RequestParam("mobile") String mobile,@RequestParam("countryCode") String countryCode){
//        SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        boolean result = userMemberService.checkTel(mobile, countryCode);
        return R.status(result);
    }

    @PostMapping("/updateLoginPassword")
    @ApiOperation("修改登录密码")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "updateLoginPasswordForm的json数据",name = "updateLoginPasswordForm")
    })
    public R updateLoginPassword(@RequestBody @Validated UpdateLoginPasswordForm updateLoginPasswordForm){
        boolean result = userMemberService.updateLoginPassword(updateLoginPasswordForm);
        return R.status(result);
    }

    @PostMapping("/updatePayPassword")
    @ApiOperation("修改交易密码")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "updatePayPasswordForm的json数据",name = "updatePayPasswordForm")
    })
    public R updatePayPassword(@RequestBody @Validated UpdatePayPasswordForm updatePayPasswordForm){
        boolean result = userMemberService.updatePayPassword(updatePayPasswordForm);
        return R.status(result);
    }

    @PostMapping("/setPayPassword")
    @ApiOperation("重置交易密码")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "setPayPasswordForm的json数据",name = "setPayPasswordForm")
    })
    public R setPayPassword(@RequestBody @Validated SetPayPasswordForm setPayPasswordForm){
        boolean result = userMemberService.setPayPassword(setPayPasswordForm);
        return R.status(result);
    }


    @GetMapping("/invites")
    @ApiOperation("查询某个用户的邀请列表")
//    @ApiImplicitParams({
//            @ApiImplicitParam(value = "setPayPasswordForm的json数据",name = "setPayPasswordForm")
//    })
    public R<List<UserMember>> invitesList(){
//        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Long userId = 123456L;
        List<UserMember> result = userMemberService.invitesList(userId);
        return R.data(result);
    }

    @PostMapping("/register")
    @ApiOperation("通过邮箱或电话号码注册会员账号")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "setPayPasswordForm的json数据",name = "setPayPasswordForm")
    })
    public R register(@RequestBody @Validated UserMemberRegisterForm userMemberRegisterForm){
        boolean result = userMemberService.register(userMemberRegisterForm);
        return R.status(result);
    }

    @PostMapping("/setPassword")
    @ApiOperation("重置登录密码")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "setPayPasswordForm的json数据",name = "setPayPasswordForm")
    })
    public R setPassword(@RequestBody @Validated SetPasswordForm setPasswordForm){
        boolean result = userMemberService.setPassword(setPasswordForm);
        return R.status(result);
    }


}
