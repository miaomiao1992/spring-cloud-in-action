package cn.mesmile.member.service;

import cn.mesmile.member.model.dto.LoginForm;
import cn.mesmile.member.model.vo.LoginUserVO;

/**
 * @author zb
 * @date 2022/3/19 17:19
 * @Description
 */
public interface LoginUserService {

    /**
     * 前台会员登录
     * @param loginForm
     * @return
     */
    LoginUserVO login(LoginForm loginForm);
}
