package cn.mesmile.member.config;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author zb
 * @date 2022/3/19 18:13
 * @Description 阿里云 云市场  身份证实名认证
 */
@Data
@ConfigurationProperties(prefix = "identify")
public class IdCardProperties {

    /**
     *  idcard 身份证号码
     *  name 姓名
     * https://idcert.market.alicloudapi.com/idcard?idcard=%s&name=%s
     */
    @ApiModelProperty("身份证请求地址")
    private String url;

    /**
     * 云市场购买的appKey
     */
    @ApiModelProperty("appKey")
    private String appKey;

    /**
     * 云市场购买的appSecret
     */
    @ApiModelProperty("appSecret")
    private String appSecret;

    /**
     * 云市场购买的appCode
     */
    @ApiModelProperty("appCode")
    private String appCode;

}
