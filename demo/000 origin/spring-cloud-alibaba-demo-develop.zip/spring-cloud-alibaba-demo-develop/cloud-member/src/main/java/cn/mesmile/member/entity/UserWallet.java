package cn.mesmile.member.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 用户提币地址
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Getter
@Setter
@TableName("user_wallet")
@ApiModel(value = "UserWallet对象", description = "用户提币地址")
public class UserWallet implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户ID")
    private Long userId;

    @ApiModelProperty("币种ID")
    private Long coinId;

    @ApiModelProperty("币种名称")
    private String coinName;

    @ApiModelProperty("提币地址名称")
    private String name;

    @ApiModelProperty("地址")
    private String addr;

    @ApiModelProperty("排序")
    private Integer sort;

    @ApiModelProperty("状态")
    private Integer status;

    @TableField(value = "last_update_time", fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @TableField(value = "created", fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;


}
