package cn.mesmile.member.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author zb
 * @date 2022/3/20 14:20
 * @Description 重置用户登录密码
 */
@Data
@ApiModel("重置用户登录密码")
public class SetPasswordForm extends  BaseGeetest{

    @ApiModelProperty("国家区号")
    private String countryCode;

    @ApiModelProperty("手机号码")
    private String mobile;

    @ApiModelProperty("密码")
    private String password;

    @ApiModelProperty("验证码")
    private String validateCode;

}
