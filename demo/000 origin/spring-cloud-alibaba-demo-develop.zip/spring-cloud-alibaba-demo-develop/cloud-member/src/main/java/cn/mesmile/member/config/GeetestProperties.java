package cn.mesmile.member.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author zb
 * @date 2022/3/19 16:15
 * @Description
 */
@Data
//@Component
@ConfigurationProperties(prefix = "geetest")
public class GeetestProperties {

    /**
     * 极验 id
     */
    private String geetestId;
    /**
     * 极验 key
     */
    private String geetestKey;
}
