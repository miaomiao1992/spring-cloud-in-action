package cn.mesmile.member.mapper;

import cn.mesmile.member.entity.UserAuthAuditRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 实名认证审核信息 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface UserAuthAuditRecordMapper extends BaseMapper<UserAuthAuditRecord> {

}
