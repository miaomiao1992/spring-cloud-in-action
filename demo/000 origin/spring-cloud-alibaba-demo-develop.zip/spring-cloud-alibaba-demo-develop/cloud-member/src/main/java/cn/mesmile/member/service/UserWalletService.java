package cn.mesmile.member.service;

import cn.mesmile.member.entity.UserWallet;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户提币地址 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface UserWalletService extends IService<UserWallet> {

    /**
     * 分页查询提币地址
     * @param page 分页信息
     * @param userId 用户id
     * @return
     */
    Page<UserWallet> findUserWalletPage(Page<UserWallet> page, Long userId);
}
