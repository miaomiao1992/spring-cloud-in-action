package cn.mesmile.member.service.impl;

import cn.mesmile.member.entity.UserAuthInfo;
import cn.mesmile.member.mapper.UserAuthInfoMapper;
import cn.mesmile.member.service.UserAuthInfoService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 实名认证信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Service
public class UserAuthInfoServiceImpl extends ServiceImpl<UserAuthInfoMapper, UserAuthInfo> implements UserAuthInfoService {

}
