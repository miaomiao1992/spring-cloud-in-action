package cn.mesmile.member.model.dto;

import cn.mesmile.common.base.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author zb
 * @date 2022/3/19 17:06
 * @Description
 */
@Data
@ApiModel("用户登录表单")
public class LoginForm extends BaseGeetest {

    @ApiModelProperty("国家编号")
    private String countryCode;

    @ApiModelProperty("用户名")
    @NotBlank(message = "用户名不允许为空")
    private String username;

    @ApiModelProperty("密码")
    @NotBlank(message = "密码不允许为空")
    private String password;

}
