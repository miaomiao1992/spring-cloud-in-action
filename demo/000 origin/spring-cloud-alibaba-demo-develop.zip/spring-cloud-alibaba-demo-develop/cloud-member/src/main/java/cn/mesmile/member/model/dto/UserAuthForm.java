package cn.mesmile.member.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author zb
 * @date 2022/3/19 19:01
 * @Description 用户认证
 */
@Data
@ApiModel("用户身份认证信息")
public class UserAuthForm extends BaseGeetest{

    @ApiModelProperty(value = "用户的真实名称")
    private String realName;

    @ApiModelProperty(value = "用户的证件类型")
    private Integer idCardType;

    @ApiModelProperty(value = "用户的证件号码")
    private String idCard;

}
