package cn.mesmile.member.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.member.entity.UserAddress;
import cn.mesmile.member.entity.UserBank;
import cn.mesmile.member.service.UserAddressService;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * <p>
 * 用户钱包地址信息 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@RestController
@RequestMapping("/userAddress")
@RequiredArgsConstructor
@Api(tags = "会员钱包地址管理")
public class UserAddressController {

    private final UserAddressService userAddressService;

    @GetMapping
    @ApiOperation("查询分页会员钱包地址")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size", value = "每页显示条数",defaultValue = "10"),
            @ApiImplicitParam(name = "userId", value = "用户id")
    })
    @PreAuthorize("hasAuthority('user_address_qurey')")
    public R<Page<UserAddress>> findUserAddressPage(@ApiIgnore Page<UserAddress> page, Long userId ){
        page.addOrder(OrderItem.desc("created"));
        Page<UserAddress> result = userAddressService.findUserAddressPage(page, userId);
        return R.data(result);
    }

}
