package cn.mesmile.member.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 实名认证审核信息 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@RestController
@RequestMapping("/member/user-auth-audit-record")
public class UserAuthAuditRecordController {

}
