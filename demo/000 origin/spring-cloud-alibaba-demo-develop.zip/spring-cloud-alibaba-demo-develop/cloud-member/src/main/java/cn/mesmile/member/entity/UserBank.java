package cn.mesmile.member.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 用户人民币提现地址
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Getter
@Setter
@TableName("user_bank")
@ApiModel(value = "UserBank对象", description = "用户人民币提现地址")
public class UserBank implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("自增id")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户id")
    private Long userId;

    @ApiModelProperty("银行卡名称")
    private String remark;

    @ApiModelProperty("开户人")
    private String realName;

    @ApiModelProperty("开户行")
    private String bank;

    @ApiModelProperty("开户省")
    private String bankProv;

    @ApiModelProperty("开户市")
    private String bankCity;

    @ApiModelProperty("开户地址")
    private String bankAddr;

    @ApiModelProperty("开户账号")
    private String bankCard;

    @ApiModelProperty("状态：0，禁用；1，启用；")
    private Integer status;

    @TableField(value = "last_update_time", fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @TableField(value = "created", fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;

    @TableField(exist = false)
    @ApiModelProperty("支付密码")
    private String payPassword;

}
