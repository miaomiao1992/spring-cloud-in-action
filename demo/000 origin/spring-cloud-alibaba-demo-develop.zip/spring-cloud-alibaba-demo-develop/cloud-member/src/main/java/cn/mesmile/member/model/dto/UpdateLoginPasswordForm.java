package cn.mesmile.member.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author zb
 * @date 2022/3/19 22:58
 * @Description 修改密码表单
 */
@Data
@ApiModel("修改登录密码")
public class UpdateLoginPasswordForm {

    @ApiModelProperty("原始密码")
    @NotBlank(message = "原始密码不允许为空")
    private String oldPassword;

    @ApiModelProperty("新的密码")
    @NotBlank(message = "原始密码不允许为空")
    private String newPassword;

    @ApiModelProperty("手机验证码")
    @NotBlank(message = "原始密码不允许为空")
    private String validateCode;

}
