package cn.mesmile.member.model.vo;

import cn.mesmile.member.entity.UserAuthAuditRecord;
import cn.mesmile.member.entity.UserAuthInfo;
import cn.mesmile.member.entity.UserMember;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * @author zb
 * @date 2022/3/19 12:06
 * @Description
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(value = "用户认证的详细信息")
public class UserAuthInfoVO implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "用户")
    private UserMember user;

    @ApiModelProperty("用户认证的详情列表")
    private List<UserAuthInfo> userAuthInfoList;

    @ApiModelProperty("用户审核历史")
    private List<UserAuthAuditRecord> userAuthAuditRecordList;

}
