package cn.mesmile.member.mapper;

import cn.mesmile.member.entity.UserAuthInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 实名认证信息 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface UserAuthInfoMapper extends BaseMapper<UserAuthInfo> {

}
