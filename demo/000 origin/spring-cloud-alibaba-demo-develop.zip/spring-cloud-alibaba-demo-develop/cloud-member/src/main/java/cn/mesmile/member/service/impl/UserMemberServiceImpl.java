package cn.mesmile.member.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.RandomUtil;
import cn.hutool.core.util.StrUtil;
import cn.mesmile.common.exception.ServiceException;
import cn.mesmile.common.utils.CloudRedisUtil;
import cn.mesmile.member.config.IdCardAutoConfiguration;
import cn.mesmile.member.entity.Sms;
import cn.mesmile.member.entity.UserAuthAuditRecord;
import cn.mesmile.member.entity.UserAuthInfo;
import cn.mesmile.member.entity.UserMember;
import cn.mesmile.member.geetest.GeetestLib;
import cn.mesmile.member.mapper.UserMemberMapper;
import cn.mesmile.member.model.dto.*;
import cn.mesmile.member.service.SmsService;
import cn.mesmile.member.service.UserAuthAuditRecordService;
import cn.mesmile.member.service.UserAuthInfoService;
import cn.mesmile.member.service.UserMemberService;
import cn.mesmile.member.model.vo.UserAuthInfoVO;
import cn.mesmile.member.utils.GeetestUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.constraints.NotBlank;
import java.util.*;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Service
@Transactional(rollbackFor = Exception.class,readOnly = true,propagation = Propagation.SUPPORTS)
public class UserMemberServiceImpl extends ServiceImpl<UserMemberMapper, UserMember> implements UserMemberService {

    @Autowired
    private UserAuthInfoService userAuthInfoService;
    @Autowired
    private UserAuthAuditRecordService userAuthAuditRecordService;
    @Autowired
    private CloudRedisUtil cloudRedisUtil;
    @Autowired
    private GeetestLib geetestLib;
    @Autowired
    private Snowflake snowflake;
    @Autowired
    private SmsService smsService;

    @Override
    public Page<UserMember> findUserMemberPage(Page<UserMember> page, Long userId, String username, String realName, String mobile, Integer status) {
        Page<UserMember> result = page(page,
                Wrappers.<UserMember>lambdaQuery()
                        .eq(userId != null, UserMember::getId, userId)
                        .like(StrUtil.isNotBlank(username), UserMember::getUsername, username)
                        .like(StrUtil.isNotBlank(realName), UserMember::getRealName, realName)
                        .eq(StrUtil.isNotBlank(mobile), UserMember::getMobile, mobile)
                        .eq(status != null, UserMember::getStatus, status)
        );
        return result;
    }

    @Override
    public Page<UserMember> getDirectInvitesPage(Page<UserMember> page, Long userId) {
        Page<UserMember> result = page(page, Wrappers.<UserMember>lambdaQuery().eq(userId != null, UserMember::getDirectInviteid, userId));
        return result;
    }

    @Override
    public Page<UserMember> findAuthUserMemberPage(Page<UserMember> page, Long userId, String username, String realName,
                                                   String mobile, Integer reviewsStatus) {
        Page<UserMember> result = page(page,
                Wrappers.<UserMember>lambdaQuery()
                        .eq(userId != null, UserMember::getId, userId)
                        .like(StrUtil.isNotBlank(username), UserMember::getUsername, username)
                        .like(StrUtil.isNotBlank(realName), UserMember::getRealName, realName)
                        .eq(StrUtil.isNotBlank(mobile), UserMember::getMobile, mobile)
                        .eq(reviewsStatus != null, UserMember::getReviewsStatus, reviewsStatus)
        );
        return result;
    }

    @Override
    public UserAuthInfoVO getAuthInfo(Long userId) {
        UserMember userMember = getById(userId);
        if (userMember != null){
            List<UserAuthInfo> userAuthInfoList = null;
            List<UserAuthAuditRecord> userAuthAuditRecordList;
            Integer reviewsStatus = userMember.getReviewsStatus();
            if (reviewsStatus == null || reviewsStatus == 0){
                // 等待审核
                userAuthAuditRecordList = Collections.emptyList();
                // 用户认证的详情列表
                userAuthInfoList = userAuthInfoService.list(Wrappers.<UserAuthInfo>lambdaQuery().eq(UserAuthInfo::getUserId, userId));
            }else {
                // 用户审核历史
                userAuthAuditRecordList = userAuthAuditRecordService.list(Wrappers.<UserAuthAuditRecord>lambdaQuery().eq(UserAuthAuditRecord::getUserId, userId));
                if (CollUtil.isNotEmpty(userAuthAuditRecordList)){
                    Long authCode = userAuthAuditRecordList.get(0).getAuthCode();
                    // 用户认证的详情列表
                    userAuthInfoList = userAuthInfoService.list(Wrappers.<UserAuthInfo>lambdaQuery().eq(UserAuthInfo::getAuthCode, authCode));
                }
            }
            return new UserAuthInfoVO(userMember,userAuthInfoList,userAuthAuditRecordList );
        }
        return new UserAuthInfoVO();
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updateAuthStatus(Long id, Integer authStatus, Long authCode,String remark) {
        // 修改审核状态 ReviewsStatus
        boolean update = update(Wrappers.<UserMember>lambdaUpdate()
                .eq(UserMember::getId, id).set(UserMember::getReviewsStatus, authStatus));
        // 添加认证记录
        UserAuthAuditRecord userAuthAuditRecord = new UserAuthAuditRecord();
        userAuthAuditRecord.setUserId(id);
        userAuthAuditRecord.setStatus(authStatus);
        userAuthAuditRecord.setAuthCode(authCode);
        userAuthAuditRecord.setRemark(remark);
        userAuthAuditRecord.setAuditUserId(123456L);
        userAuthAuditRecord.setAuditUserName("审核人");

//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        Object principal = authentication.getPrincipal();
//        String username = principal.toString();

        return userAuthAuditRecordService.save(userAuthAuditRecord);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean identifyCheck(Long userId,UserAuthForm userAuthForm) {
        UserMember userMember = getById(userId);
        if (userMember == null){
            return false;
        }
        Integer authStatus = userMember.getAuthStatus();
        if (!Objects.equals(authStatus,0)){
            throw new SecurityException("该用户已经认证");
        }
        // 极验认证
        userAuthForm.checkFormData(cloudRedisUtil, geetestLib);
        // GeetestUtil.checkFormData(userAuthForm.getGeetest_challenge(),userAuthForm.getGeetest_validate(),
        //         userAuthForm.getGeetest_seccod(),userAuthForm.getUuid(), cloudRedisUtil, geetestLib);
        // 实名认证
        boolean check = IdCardAutoConfiguration.check(userAuthForm.getRealName(), userAuthForm.getIdCard());
        if (check){
            userMember.setAuthtime(new Date());
            userMember.setAuthStatus(1);
            userMember.setRealName(userAuthForm.getRealName());
            userMember.setIdCard(userAuthForm.getIdCard());
            userMember.setIdCardType(userAuthForm.getIdCardType());
            return updateById(userMember);
        }
        return false;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void authUser(Long userId, List<String> images) {
        if (CollUtil.isEmpty(images)){
            throw new ServiceException("上传图片不允许为空");
        }
        UserMember userMember = getById(userId);
        if (userMember == null){
            throw new ServiceException("认证失败，请刷新页面后上传");
        }
        List<UserAuthInfo> userAuthInfos = new ArrayList<>(images.size());
        // 雪花算法生成id
        Long authCode = snowflake.nextId();
        for (int i = 0; i < images.size(); i++) {
            String url = images.get(i);
            UserAuthInfo userAuthInfo = new UserAuthInfo();
            userAuthInfo.setUserId(userId);
            userAuthInfo.setImageUrl(url);
            userAuthInfo.setSerialno(i+1);
            userAuthInfo.setAuthCode(authCode);
            userAuthInfos.add(userAuthInfo);
        }
        userAuthInfoService.saveBatch(userAuthInfos);
        //审核状态,1通过,2拒绝,0,待审核
        userMember.setReviewsStatus(0);
        updateById(userMember);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updatePhone(UpdatePhoneForm updatePhoneForm) {
        //        SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Long id = 1234567L;
        UserMember userMember = getById(id);
        if (userMember != null){
            String oldMobile = userMember.getMobile();
            String newMobilePhone = updatePhoneForm.getNewMobilePhone();
            String countryCode = updatePhoneForm.getCountryCode();
            String validateCode = updatePhoneForm.getValidateCode();
            String oldValidateCode = updatePhoneForm.getOldValidateCode();

            // todo redis 验证手机验证码

            boolean update = update(Wrappers.<UserMember>lambdaUpdate()
                    .eq(UserMember::getId, id)
                    .set(UserMember::getMobile, newMobilePhone)
            );
            return update;
        }
        return false;
    }

    @Override
    public boolean checkTel(String mobile, String countryCode) {
        int count = count(Wrappers.<UserMember>lambdaQuery().eq(UserMember::getMobile, mobile));
        if (count > 0){
            throw new ServiceException("该手机号："+ mobile +"已经被使用了");
        }
        // 发送手机号码
        Sms sms = new Sms();
        sms.setMobile(mobile);
        sms.setCountryCode(countryCode);
//        sms.setTemplateCode("从ConfigService里面查询");
        return smsService.sendSms(sms);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updateLoginPassword(UpdateLoginPasswordForm updateLoginPasswordForm) {
//        SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Long userId = 123456L;
        UserMember userMember = getById(userId);
        if (userMember != null){
            String newPassword = updateLoginPasswordForm.getNewPassword();
            String oldPassword = updateLoginPasswordForm.getOldPassword();
            String validateCode = updateLoginPasswordForm.getValidateCode();
            String password = userMember.getPassword();
            BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
            // 原始密码    加密后的密码
            boolean matches = bCryptPasswordEncoder.matches(oldPassword, password);
            if (!matches){
                throw new ServiceException("原始密码错误");
            }
            // todo redis 里面获取验证码 验证

            userMember.setPassword(bCryptPasswordEncoder.encode(newPassword));
            updateById(userMember);
        }
        return false;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updatePayPassword(UpdatePayPasswordForm updatePayPasswordForm) {
        //        SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Long userId = 123456L;
        UserMember userMember = getById(userId);
        if (userMember != null){
            String newPassword = updatePayPasswordForm.getNewPassword();
            String oldPassword = updatePayPasswordForm.getOldPassword();
            String payPassword = userMember.getPaypassword();
            String validateCode = updatePayPasswordForm.getValidateCode();
            BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
            // 原始密码    加密后的密码
            boolean matches = bCryptPasswordEncoder.matches(oldPassword, payPassword);
            if (!matches){
                throw new ServiceException("原始交易密码错误");
            }
            // todo redis 里面获取验证码 验证

            userMember.setPaypassword(bCryptPasswordEncoder.encode(newPassword));
            updateById(userMember);
        }
        return false;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean setPayPassword(SetPayPasswordForm setPayPasswordForm) {
        //        SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Long userId = 123456L;
        UserMember userMember = getById(userId);
        if (userMember != null){
            // todo 从redis 验证短信验证码

            BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
            String payPassword = bCryptPasswordEncoder.encode(setPayPasswordForm.getPayPassword());
            userMember.setPaypassword(payPassword);
            return updateById(userMember);
        }
        return false;
    }

    @Override
    public List<UserMember> invitesList(Long userId) {
        if (userId == null){
            return Collections.emptyList();
        }
        List<UserMember> list = list(Wrappers.<UserMember>lambdaQuery()
                .eq(UserMember::getDirectInviteid, userId)
        );
        if (CollUtil.isEmpty(list)){
            return Collections.emptyList();
        }
        list.forEach(user -> {
            user.setPaypassword("***********");
            user.setPassword("***********");
            user.setAccessKeyId("**********");
            user.setAccessKeySecret("************");
        });
        return list;
    }

    @Override
    public boolean register(UserMemberRegisterForm userMemberRegisterForm) {
        // 验证码检查
        userMemberRegisterForm.checkFormData(cloudRedisUtil, geetestLib);
        // GeetestUtil.checkFormData(userMemberRegisterForm.getGeetest_challenge(),
        //         userMemberRegisterForm.getGeetest_validate(),userMemberRegisterForm.getGeetest_seccod()
        //         ,userMemberRegisterForm.getUuid(),cloudRedisUtil,geetestLib);
        String email = userMemberRegisterForm.getEmail();
        String mobile = userMemberRegisterForm.getMobile();
        if (StrUtil.isAllBlank(email,mobile)){
            throw new ServiceException("请输入电话号码或邮箱");
        }
        int count = count(Wrappers.<UserMember>lambdaQuery()
                .eq(StrUtil.isNotBlank(email),UserMember::getEmail, email)
                .or()
                .eq(StrUtil.isNotBlank(mobile),UserMember::getMobile, mobile)
            );
        if (count > 0){
            throw new ServiceException("邮箱名或者电话号码已经被占用，注册失败");
        }
        UserMember userMember = getUserMember(userMemberRegisterForm);
        // 保存
        return save(userMember);
    }

    @Override
    public boolean setPassword(SetPasswordForm setPasswordForm) {
        // 验证码检查
        setPasswordForm.checkFormData(cloudRedisUtil,geetestLib);
        // GeetestUtil.checkFormData(setPasswordForm.getGeetest_challenge(),
        //         setPasswordForm.getGeetest_validate(),setPasswordForm.getGeetest_seccod()
        //         ,setPasswordForm.getUuid(),cloudRedisUtil,geetestLib);
        // TODO 短信验证码检查

        // 修改密码
        UserMember userMember = getOne(Wrappers.<UserMember>lambdaQuery().eq(UserMember::getMobile, setPasswordForm.getMobile()));
        if (userMember != null){
            userMember.setPassword(new BCryptPasswordEncoder().encode(setPasswordForm.getPassword()));
            return updateById(userMember);
        }
        return false;
    }

    private UserMember getUserMember(UserMemberRegisterForm userMemberRegisterForm) {
        UserMember userMember = new UserMember();
        userMember.setPaypassword(new BCryptPasswordEncoder().encode(userMemberRegisterForm.getPassword()));
        userMember.setEmail(userMemberRegisterForm.getEmail());
        userMember.setMobile(userMemberRegisterForm.getMobile());
        userMember.setPaypassSetting(false);
        userMember.setStatus(1);
        userMember.setType(1);
        userMember.setAuthStatus(0);
        userMember.setLogins(0);
        userMember.setInviteCode(RandomUtil.randomString(8));
        if (StrUtil.isNotBlank(userMemberRegisterForm.getInvitionCode())){
            UserMember userMember2 = getOne(Wrappers.<UserMember>lambdaQuery().eq(UserMember::getInviteCode, userMemberRegisterForm.getInvitionCode()));
            if (userMember2 != null){
                userMember.setDirectInviteid(userMember2.getId().toString());
            }
        }
        return userMember;
    }


}
