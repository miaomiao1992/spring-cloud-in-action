package cn.mesmile.member.service.impl;

import cn.mesmile.member.entity.UserAuthAuditRecord;
import cn.mesmile.member.mapper.UserAuthAuditRecordMapper;
import cn.mesmile.member.service.UserAuthAuditRecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 实名认证审核信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Service
public class UserAuthAuditRecordServiceImpl extends ServiceImpl<UserAuthAuditRecordMapper, UserAuthAuditRecord> implements UserAuthAuditRecordService {

}
