package cn.mesmile.member.model.dto;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author zb
 * @date 2022/3/20 10:58
 * @Description
 */
@Data
@ApiModel("用户dto")
public class UserMemberDTO {

    @ApiModelProperty("自增id")
    private Long id;

    @ApiModelProperty("用户类型：1-普通用户；2-代理人")
    private Integer type;

    @ApiModelProperty("用户名")
    private String username;

    @ApiModelProperty("国际电话区号")
    private String countryCode;

    @ApiModelProperty("手机号")
    private String mobile;

    @ApiModelProperty("邮箱")
    private String email;

    @ApiModelProperty("真实姓名")
    private String realName;

}
