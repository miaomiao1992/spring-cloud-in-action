package cn.mesmile.member.service;

import cn.mesmile.member.entity.UserAuthAuditRecord;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 实名认证审核信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface UserAuthAuditRecordService extends IService<UserAuthAuditRecord> {

}
