package cn.mesmile.member.config;

import cn.hutool.core.lang.Snowflake;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author zb
 * @date 2022/3/19 21:28
 * @Description
 */
@Configuration
public class IdGenConfig {

    @Value("${snowflake.machineId:0}")
    private int machineId;
    @Value("${snowflake.appId:0}")
    private int appId;

    @Bean
    public Snowflake snowflake(){
        return new Snowflake(machineId, appId);
    }


}
