package cn.mesmile.member.service.impl;

import cn.mesmile.member.entity.UserLoginLog;
import cn.mesmile.member.mapper.UserLoginLogMapper;
import cn.mesmile.member.service.UserLoginLogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户登录日志 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Service
public class UserLoginLogServiceImpl extends ServiceImpl<UserLoginLogMapper, UserLoginLog> implements UserLoginLogService {

}
