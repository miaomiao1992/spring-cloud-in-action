package cn.mesmile.member.utils;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.common.exception.ServiceException;
import cn.mesmile.common.utils.CloudRedisUtil;
import cn.mesmile.member.geetest.GeetestLib;
import cn.mesmile.member.geetest.entity.GeetestLibResult;
import cn.mesmile.member.geetest.enums.DigestmodEnum;
import cn.mesmile.member.model.dto.BaseGeetest;
import com.alibaba.fastjson.JSONObject;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * @author zb
 * @date 2022/3/19 19:10
 * @Description
 */
@Slf4j
public class GeetestUtil {

    /**
     * 二次校验 验证码,方法已经废弃，请使用{@link BaseGeetest#checkFormData(CloudRedisUtil, GeetestLib)}
     * @param challenge
     * @param validate
     * @param seccode
     * @param uuid
     * @param cloudRedisUtil
     * @param geetestLib
     */
    @Deprecated
    public static void checkFormData(String challenge, String validate, String seccode,
                                     String uuid, CloudRedisUtil cloudRedisUtil,GeetestLib geetestLib) {
        if (!StrUtil.isAllNotEmpty(challenge, validate, seccode)){
            throw new ServiceException("验证码参数异常");
        }
        /**
         * 极验二次校验
         */
        String uuidStr = (String) cloudRedisUtil.get(GeetestLib.GEETEST_SERVER_USER_KEY + ":" + uuid);
        Integer status = (Integer) cloudRedisUtil.get(GeetestLib.GEETEST_SERVER_STATUS_SESSION_KEY);

        GeetestLibResult result = null;
        // 检测存入redis中的极验云状态标识
        if (status != null && status == 1){
            DigestmodEnum digestmodEnum = DigestmodEnum.MD5;
            Map<String, String> paramMap = new HashMap<>(8);
            paramMap.put("digestmod", digestmodEnum.getName());
            paramMap.put("user_id", uuidStr);
            paramMap.put("client_type", "web");
            result = geetestLib.successValidate(challenge, validate, seccode, paramMap);
        } else {
            result = geetestLib.failValidate(challenge, validate, seccode);
        }
        if (result.getStatus() != 1){
            log.info("验证数据异常："+ JSONObject.toJSONString(result,true));
            throw new ServiceException("验证码异常");
        }
    }
}
