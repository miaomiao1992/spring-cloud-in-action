package cn.mesmile.member.config;

import cn.mesmile.member.geetest.GeetestLib;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author zb
 * @date 2022/3/19 16:18
 * @Description
 */
@Configuration
@EnableConfigurationProperties(GeetestProperties.class)
public class GeetestAutoConfiguration {

    private GeetestProperties geetestProperties;

    public GeetestAutoConfiguration(GeetestProperties geetestProperties){
        this.geetestProperties = geetestProperties;
    }

    @Bean
    public GeetestLib geetestLib(){
        return new GeetestLib(geetestProperties.getGeetestId(),geetestProperties.getGeetestKey());
    }


}
