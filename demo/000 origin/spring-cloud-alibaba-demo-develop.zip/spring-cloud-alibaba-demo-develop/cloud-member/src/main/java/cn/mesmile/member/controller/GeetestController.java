package cn.mesmile.member.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.common.utils.CloudRedisUtil;
import cn.mesmile.member.geetest.GeetestLib;
import cn.mesmile.member.geetest.entity.GeetestLibResult;
import cn.mesmile.member.geetest.enums.DigestmodEnum;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @author zb
 * @date 2022/3/19 16:37
 * @Description
 */
@RestController
@RequestMapping("/gt")
@RequiredArgsConstructor
@Api(tags = "验证码管理")
public class GeetestController {

    @Autowired
    private GeetestLib geetestLib;
    @Autowired
    private CloudRedisUtil cloudRedisUtil;

    @GetMapping("/register")
    @ApiOperation("验证码功能，获取极验的第一次数据包")
    @ApiImplicitParam(value = "随机数",name = "uuid")
    public R<String> register(String uuid) throws JSONException {
          /*
        必传参数 digestmod 此版本sdk可支持md5、sha256、hmac-sha256，md5之外的算法需特殊配置的账号，联系极验客服
        自定义参数,可选择添加
            user_id 客户端用户的唯一标识，确定用户的唯一性；作用于提供进阶数据分析服务，可在register和validate接口传入，不传入也不影响验证服务的使用；若担心用户信息风险，可作预处理(如哈希处理)再提供到极验
            client_type 客户端类型，web：电脑上的浏览器；h5：手机上的浏览器，包括移动应用内完全内置的web_view；native：通过原生sdk植入app应用的方式；unknown：未知
            ip_address 客户端请求sdk服务器的ip地址
        */
        DigestmodEnum digestmodEnum = DigestmodEnum.MD5;
        Map<String, String> paramMap = new HashMap<>(8);
        paramMap.put("digestmod", digestmodEnum.getName());
        paramMap.put("user_id", uuid);
        paramMap.put("client_type", "web");
//        paramMap.put("ip_address", "127.0.0.3");
        GeetestLibResult result = geetestLib.register(digestmodEnum, paramMap);
        // 存入redis校验
        cloudRedisUtil.setEx(GeetestLib.GEETEST_SERVER_STATUS_SESSION_KEY, result.getStatus(),180 , TimeUnit.SECONDS);
        cloudRedisUtil.setEx(GeetestLib.GEETEST_SERVER_USER_KEY+":"+uuid,uuid, 180, TimeUnit.SECONDS);
        return R.data(result.getData());
    }

}
