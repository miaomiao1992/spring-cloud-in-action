package cn.mesmile.member.service;

import cn.mesmile.member.entity.Sms;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 短信信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface SmsService extends IService<Sms> {

    /**
     * 发送短信
     * @param sms
     * @return
     */
    boolean sendSms(Sms sms);
}
