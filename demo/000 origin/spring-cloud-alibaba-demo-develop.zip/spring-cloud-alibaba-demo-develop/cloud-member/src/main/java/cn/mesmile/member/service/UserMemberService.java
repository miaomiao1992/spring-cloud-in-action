package cn.mesmile.member.service;

import cn.mesmile.member.entity.UserMember;
import cn.mesmile.member.model.dto.*;
import cn.mesmile.member.model.vo.UserAuthInfoVO;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
 * <p>
 * 用户表 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface UserMemberService extends IService<UserMember> {

    /**
     * 分页查找用户
     * @param page 分页信息
     * @param userId 用户id
     * @param username 用户名
     * @param realName 真实姓名
     * @param mobile 电话号码
     * @param status 状态
     * @return
     */
    Page<UserMember> findUserMemberPage(Page<UserMember> page, Long userId, String username, String realName, String mobile, Integer status);

    /**
     * 查询被某个用户邀请的用户列表
     * @param page
     * @param userId
     * @return
     */
    Page<UserMember> getDirectInvitesPage(Page<UserMember> page, Long userId);

    /**
     * 查询会员实名认证审核列表
     * @param page 分页
     * @param userId 用户id
     * @param username 用户名
     * @param realName 真实姓名
     * @param mobile 电话号码
     * @param reviewsStatus  审核状态,1通过,2拒绝,0,待审核
     * @return
     */
    Page<UserMember> findAuthUserMemberPage(Page<UserMember> page, Long userId, String username, String realName, String mobile, Integer reviewsStatus);

    /**
     * 通过用户id 获取认证信息
     * @param userId 用户id
     * @return
     */
    UserAuthInfoVO getAuthInfo(Long userId);

    /**
     * 审核用户信息
     * @param id 用户id
     * @param authStatus 用户审核状态
     * @param authCode 认证编码
     * @param remark 拒绝原因
     * @return
     */
    boolean updateAuthStatus(Long id, Integer authStatus, Long authCode,String remark);

    /**
     * 用户身份认证
     * @param userId 用户id
     * @param userAuthForm 认证表单
     * @return
     */
    boolean identifyCheck(Long userId, UserAuthForm userAuthForm);

    /**
     * 用户上传身份证信息，认证
     * @param userId
     * @param images
     */
    void authUser(Long userId, List<String> images);

    /**
     * 修改手机号
     * @param updatePhoneForm
     * @return
     */
    boolean updatePhone(UpdatePhoneForm updatePhoneForm);

    /**
     *  检查新手机号是否可用
     * @param mobile
     * @param countryCode
     * @return
     */
    boolean checkTel(String mobile, String countryCode);

    /**
     * 修改登录密码
     * @param updateLoginPasswordForm
     * @return
     */
    boolean updateLoginPassword(UpdateLoginPasswordForm updateLoginPasswordForm);

    /**
     * 修改交易密码
     * @param updatePayPasswordForm
     * @return
     */
    boolean updatePayPassword(UpdatePayPasswordForm updatePayPasswordForm);

    /**
     * 重置交易密码
     * @param setPayPasswordForm
     * @return
     */
    boolean setPayPassword(SetPayPasswordForm setPayPasswordForm);

    /**
     * 查询某个用户的邀请列表
     * @param userId
     * @return
     */
    List<UserMember> invitesList(Long userId);

    /**
     * 通过邮箱或者电话号码注册
     * @param userMemberRegisterForm
     * @return
     */
    boolean register(UserMemberRegisterForm userMemberRegisterForm);

    /**
     * 重置登录密码
     * @param setPasswordForm
     * @return
     */
    boolean setPassword(SetPasswordForm setPasswordForm);
}
