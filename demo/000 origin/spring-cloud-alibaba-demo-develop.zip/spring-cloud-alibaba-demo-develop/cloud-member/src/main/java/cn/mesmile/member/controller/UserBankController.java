package cn.mesmile.member.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.member.entity.UserBank;
import cn.mesmile.member.entity.UserMember;
import cn.mesmile.member.service.UserBankService;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

/**
 * <p>
 * 用户人民币提现地址 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@RestController
@RequestMapping("/userBanks")
@RequiredArgsConstructor
@Api(tags = "会员银行卡信息管理")
public class UserBankController {

    private final UserBankService userBankService;

    @GetMapping
    @ApiOperation("查询分页会员银行卡信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "current", value = "当前页",defaultValue = "1"),
            @ApiImplicitParam(name = "size", value = "每页显示条数",defaultValue = "10"),
            @ApiImplicitParam(name = "userId", value = "用户id")
    })
    @PreAuthorize("hasAuthority('user_bank_qurey')")
    public R<Page<UserBank>> findUserBankPage(@ApiIgnore Page<UserBank> page, Long userId ){
        page.addOrder(OrderItem.desc("created"));
        Page<UserBank> result = userBankService.findUserBankPage(page, userId);
        return R.data(result);
    }


    @PatchMapping
    @ApiOperation("修改会员银行卡信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "userBank", value = "userBank的json数据")
    })
//    @PreAuthorize("hasAuthority('user_banks_update')")
    public R update(@RequestBody UserBank userBank){
        boolean update = userBankService.updateById(userBank);
        return R.data(update);
    }

    @PostMapping("/status")
    @ApiOperation("修改会员银行卡状态")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "userBank的id"),
            @ApiImplicitParam(name = "status", value = "银行卡的状态")
    })
//    @PreAuthorize("hasAuthority('user_banks_update')")
    public R status(Long id, Integer status){
        boolean update = userBankService.update(
                Wrappers.<UserBank>lambdaUpdate().eq(UserBank::getUserId, id).set(UserBank::getStatus, status));
        return R.data(update);
    }

    @GetMapping("/current")
    @ApiOperation("获取当前用户的银行卡")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "", name = "")
    })
    public R<UserBank> currentBank(){
//        SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        //todo
        Long userId = 1234567L;
        UserBank userBank = userBankService.getOne(Wrappers.<UserBank>lambdaQuery()
                .eq(UserBank::getUserId,userId).eq(UserBank::getStatus,1));
        return R.data(userBank);
    }


    @GetMapping("/bind")
    @ApiOperation("绑定银行卡")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "", name = "")
    })
    public R<UserBank> bindBank(@RequestBody UserBank userBank){
        // todo
//        SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Long userId = 1234567L;
        boolean result = userBankService.bindBank(userBank, userId);
        return R.status(result);
    }

}
