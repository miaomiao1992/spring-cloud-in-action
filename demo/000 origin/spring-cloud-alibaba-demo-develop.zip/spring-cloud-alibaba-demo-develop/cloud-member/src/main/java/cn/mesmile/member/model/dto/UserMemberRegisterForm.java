package cn.mesmile.member.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author zb
 * @date 2022/3/20 13:49
 * @Description
 */
@Data
@ApiModel("会员注册表单")
public class UserMemberRegisterForm extends BaseGeetest{

    @ApiModelProperty("国家的代号")
    private String countryCode;

    @ApiModelProperty("密码")
    private String password;

    @ApiModelProperty("邮箱地址")
    private String email;

    @ApiModelProperty("手机号码")
    private String mobile;

    @ApiModelProperty("邀请码")
    private String invitionCode;

    @ApiModelProperty("手机验证码")
    private String validateCode;

}
