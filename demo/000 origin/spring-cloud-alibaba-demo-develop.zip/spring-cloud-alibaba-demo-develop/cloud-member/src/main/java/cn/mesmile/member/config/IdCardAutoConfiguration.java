package cn.mesmile.member.config;

import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 * @author zb
 * @date 2022/3/19 16:18
 * @Description
 */
@Configuration
@EnableConfigurationProperties(IdCardProperties.class)
public class IdCardAutoConfiguration {

    private IdCardProperties idCardProperties;

    public IdCardAutoConfiguration(IdCardProperties idCardProperties){
        this.idCardProperties = idCardProperties;
    }

    /**
     *  接通云市场 实名认证
     * @param realName 真实姓名
     * @param idCard 身份号码
     * @return
     */
    public static boolean check(String realName, String idCard){
        // TODO 接通 阿里云 云市场 身份证实名认证 判断
        return true;
    }

}
