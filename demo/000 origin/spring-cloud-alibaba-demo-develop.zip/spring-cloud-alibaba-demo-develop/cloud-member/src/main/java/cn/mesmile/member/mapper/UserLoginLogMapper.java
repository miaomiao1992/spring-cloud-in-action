package cn.mesmile.member.mapper;

import cn.mesmile.member.entity.UserLoginLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 用户登录日志 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface UserLoginLogMapper extends BaseMapper<UserLoginLog> {

}
