package cn.mesmile.member.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 用户登录日志
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Getter
@Setter
@TableName("user_login_log")
@ApiModel(value = "UserLoginLog对象", description = "用户登录日志")
public class UserLoginLog implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户ID")
    private Long userId;

    @ApiModelProperty("客户端类型	            1-PC	            2-IOS	            3-Android")
    private Integer clientType;

    @ApiModelProperty("登录IP")
    private String loginIp;

    @ApiModelProperty("登录地址")
    private String loginAddress;

    @ApiModelProperty("登录时间")
    private Date loginTime;


}
