package cn.mesmile.member.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

/**
 * <p>
 * 短信信息
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Data
@TableName("sms")
@ApiModel(value = "Sms对象", description = "短信信息")
public class Sms implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键id")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("短信模板ID")
    @NotBlank(message = "短信模板不允许为空")
    private String templateCode;

    @ApiModelProperty("国际区号")
    @NotBlank(message = "国际区号不允许为空")
    private String countryCode;

    @ApiModelProperty("短信接收手机号")
    @NotBlank(message = "手机号不允许为空")
    private String mobile;

    @ApiModelProperty("短信内容")
    @NotBlank(message = "短信内容不允许为空")
    private String content;

    @ApiModelProperty("短信状态：0，默认值；大于0，成功发送短信数量；小于0，异常；")
    private Integer status;

    @ApiModelProperty("备注")
    private String remark;

    @TableField(value = "last_update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("发送时间")
    private Date lastUpdateTime;

    @TableField(value = "created",fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;


}
