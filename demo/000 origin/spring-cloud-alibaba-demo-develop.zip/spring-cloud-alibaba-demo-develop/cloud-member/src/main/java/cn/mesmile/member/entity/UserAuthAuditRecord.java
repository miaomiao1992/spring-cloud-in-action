package cn.mesmile.member.entity;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 实名认证审核信息
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Getter
@Setter
@TableName("user_auth_audit_record")
@ApiModel(value = "UserAuthAuditRecord对象", description = "实名认证审核信息")
public class UserAuthAuditRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    private Long id;

    @ApiModelProperty("对应user_auth_info表code")
    private Long authCode;

    @ApiModelProperty("用户ID")
    private Long userId;

    @ApiModelProperty("状态1同意2拒絕")
    private Integer status;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("当前审核级数")
    private Integer step;

    @ApiModelProperty("审核人ID")
    private Long auditUserId;

    @ApiModelProperty("审核人")
    private String auditUserName;

    @TableField(value = "created",fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;


}
