package cn.mesmile.member.service.impl;

import cn.mesmile.common.exception.ServiceException;
import cn.mesmile.member.entity.UserBank;
import cn.mesmile.member.entity.UserMember;
import cn.mesmile.member.mapper.UserBankMapper;
import cn.mesmile.member.service.UserBankService;
import cn.mesmile.member.service.UserMemberService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.sql.rowset.serial.SerialException;

/**
 * <p>
 * 用户人民币提现地址 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Service
public class UserBankServiceImpl extends ServiceImpl<UserBankMapper, UserBank> implements UserBankService {

    private UserMemberService userMemberService;

    @Override
    public Page<UserBank> findUserBankPage(Page<UserBank> page, Long userId) {
        Page<UserBank> result = page(page, Wrappers.<UserBank>lambdaQuery().eq(userId != null, UserBank::getUserId, userId));
        return result;
    }

    @Override
    public boolean bindBank(UserBank userBank, Long userId) {
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        UserMember user = userMemberService.getById(userId);
        // 原始密码 和  加密密码
        if (!bCryptPasswordEncoder.matches(userBank.getPayPassword(), user.getPaypassword())){
            throw new ServiceException("支付密码错误");
        }
        Long id = userBank.getId();
        if (id != null){
            // 修改
            UserBank oldUserBank = getById(id);
            if (oldUserBank == null){
                throw new ServiceException("输入信息有误，请刷新页面");
            }
            return updateById(userBank);
        }
        // 若银行卡id为null ,则需要新建一个
        userBank.setUserId(userId);
        return save(userBank);
    }
}
