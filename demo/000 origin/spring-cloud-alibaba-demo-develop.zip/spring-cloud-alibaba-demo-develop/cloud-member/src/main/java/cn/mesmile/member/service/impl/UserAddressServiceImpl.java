package cn.mesmile.member.service.impl;

import cn.mesmile.member.entity.UserAddress;
import cn.mesmile.member.mapper.UserAddressMapper;
import cn.mesmile.member.service.UserAddressService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户钱包地址信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Service
public class UserAddressServiceImpl extends ServiceImpl<UserAddressMapper, UserAddress> implements UserAddressService {

    @Override
    public Page<UserAddress> findUserAddressPage(Page<UserAddress> page, Long userId) {
        Page<UserAddress> result = page(page, Wrappers.<UserAddress>lambdaQuery()
                .eq(userId != null, UserAddress::getUserId, userId));
        return result;
    }
}
