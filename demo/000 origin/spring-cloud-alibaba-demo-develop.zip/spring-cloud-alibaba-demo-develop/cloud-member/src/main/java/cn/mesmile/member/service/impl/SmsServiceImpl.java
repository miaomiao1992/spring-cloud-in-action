package cn.mesmile.member.service.impl;

import cn.hutool.core.util.RandomUtil;
import cn.mesmile.member.entity.Sms;
import cn.mesmile.member.mapper.SmsMapper;
import cn.mesmile.member.service.SmsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 短信信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
@Service
public class SmsServiceImpl extends ServiceImpl<SmsMapper, Sms> implements SmsService {

    @Override
    public boolean sendSms(Sms sms) {
        // todo 发送短信

        String randomNumber = RandomUtil.randomNumbers(6);
        // 存入redis  key 短信模板:手机号   value randomNumber 过期时间两分钟

        sms.setStatus(1);
        boolean save = save(sms);

        return true;
    }
}
