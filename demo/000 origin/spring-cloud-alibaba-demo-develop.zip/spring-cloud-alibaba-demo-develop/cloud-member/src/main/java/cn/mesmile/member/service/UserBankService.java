package cn.mesmile.member.service;

import cn.mesmile.member.entity.UserBank;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 用户人民币提现地址 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-18
 */
public interface UserBankService extends IService<UserBank> {

    /**
     * 分页查询会员银行卡信息
     * @param page
     * @param userId
     * @return
     */
    Page<UserBank> findUserBankPage(Page<UserBank> page, Long userId);

    /**
     * 绑定银行卡
     * @param userBank
     * @param userId
     * @return
     */
    boolean bindBank(UserBank userBank, Long userId);
}
