package cn.mesmile.member.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;

/**
 * @author zb
 * @date 2022/3/19 23:23
 * @Description
 */
@Data
@ApiModel("重置支付密码")
public class SetPayPasswordForm {

    @ApiModelProperty("支付密码")
    @NotBlank(message = "支付密码不允许为空")
    private String payPassword;

    @ApiModelProperty("验证码")
    @NotBlank(message = "验证码不允许为空")
    private String validateCode;

}
