package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.CashRechargeAuditRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 充值审核记录 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CashRechargeAuditRecordMapper extends BaseMapper<CashRechargeAuditRecord> {

}
