package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.ForexOpenPositionOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 开仓订单信息 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface ForexOpenPositionOrderMapper extends BaseMapper<ForexOpenPositionOrder> {

}
