package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.CoinWithdraw;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 数字货币提现记录 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CoinWithdrawMapper extends BaseMapper<CoinWithdraw> {

}
