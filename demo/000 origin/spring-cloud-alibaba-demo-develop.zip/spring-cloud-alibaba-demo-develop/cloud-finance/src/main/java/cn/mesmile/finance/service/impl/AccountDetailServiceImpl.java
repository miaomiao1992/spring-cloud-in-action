package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.AccountDetail;
import cn.mesmile.finance.mapper.AccountDetailMapper;
import cn.mesmile.finance.service.AccountDetailService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 资金账户流水 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class AccountDetailServiceImpl extends ServiceImpl<AccountDetailMapper, AccountDetail> implements AccountDetailService {

    @Override
    public Page<AccountDetail> findAccountDetailPage(Page<AccountDetail> page) {
        Page<AccountDetail> result = page(page);
        return result;
    }
}
