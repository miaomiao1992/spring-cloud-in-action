package cn.mesmile.finance.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("user_coin_freeze")
@ApiModel(value = "UserCoinFreeze对象", description = "")
public class UserCoinFreeze implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "user_id", type = IdType.ASSIGN_ID)
    private Long userId;

    private Long coinId;

    private BigDecimal freeze;


}
