package cn.mesmile.finance.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.finance.entity.CoinType;
import cn.mesmile.finance.mapper.CoinTypeMapper;
import cn.mesmile.finance.service.CoinTypeService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 币种类型 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,readOnly = true, propagation = Propagation.SUPPORTS)
public class CoinTypeServiceImpl extends ServiceImpl<CoinTypeMapper, CoinType> implements CoinTypeService {

    @Override
    public Page<CoinType> getCoinTypePage(Page<CoinType> page, String code) {
        Page<CoinType> result = page(page,
                Wrappers.<CoinType>lambdaQuery().like(StrUtil.isNotBlank(code),CoinType::getCode, code)
        );
        return result;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updateCoinTypeStatus(Long id, Integer status) {
        boolean update = update(Wrappers.<CoinType>lambdaUpdate().eq(CoinType::getId, id).set(CoinType::getStatus, status));
        return update;
    }
}
