package cn.mesmile.finance.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 创新交易币种表
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("forex_coin")
@ApiModel(value = "ForexCoin对象", description = "创新交易币种表")
public class ForexCoin implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("币种名称")
    private String name;

    @ApiModelProperty("币种标题")
    private String title;

    @ApiModelProperty("排序")
    private Integer sort;

    @ApiModelProperty("状态: 0禁用 1启用")
    private Boolean status;

    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;

    @ApiModelProperty("创建时间")
    private Date created;


}
