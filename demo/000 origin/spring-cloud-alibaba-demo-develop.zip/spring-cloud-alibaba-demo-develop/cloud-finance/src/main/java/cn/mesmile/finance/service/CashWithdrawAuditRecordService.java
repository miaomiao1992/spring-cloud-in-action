package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.CashWithdrawAuditRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 提现审核记录 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CashWithdrawAuditRecordService extends IService<CashWithdrawAuditRecord> {

    /**
     * 分页查找提现审核记录
     * @param page 分页信息
     * @return
     */
    Page<CashWithdrawAuditRecord> findCashWithdrawAuditRecordPage(Page<CashWithdrawAuditRecord> page);
}

