package cn.mesmile.finance.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.ForexAccountDetailService;
import cn.mesmile.finance.entity.ForexAccountDetail;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 持仓账户流水 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "持仓账户流水相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/forex-account-detail")
public class ForexAccountDetailController {

    private final ForexAccountDetailService forexAccountDetailService;

    @ApiOperation("分页查询持仓账户流水")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<ForexAccountDetail>> findForexAccountDetailPage(@ApiIgnore Page<ForexAccountDetail> page){
        Page<ForexAccountDetail> result = forexAccountDetailService.findForexAccountDetailPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增持仓账户流水")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "forexAccountDetail", value = "forexAccountDetail对象的json数据")
    })
    public R save(@RequestBody ForexAccountDetail forexAccountDetail){
        boolean save = forexAccountDetailService.save(forexAccountDetail);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改持仓账户流水")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "forexAccountDetail", value = "forexAccountDetail对象的json数据")
    })
    public R update(@RequestBody ForexAccountDetail forexAccountDetail){
        boolean update = forexAccountDetailService.updateById(forexAccountDetail);
        return R.status(update);
    }

    @ApiOperation("删除持仓账户流水")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = forexAccountDetailService.removeByIds(ids);
        return R.data(delete);
    }
}
