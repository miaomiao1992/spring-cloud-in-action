package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.ForexAccountDetail;
import cn.mesmile.finance.mapper.ForexAccountDetailMapper;
import cn.mesmile.finance.service.ForexAccountDetailService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 持仓账户流水 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class ForexAccountDetailServiceImpl extends ServiceImpl<ForexAccountDetailMapper, ForexAccountDetail> implements ForexAccountDetailService {

    @Override
    public Page<ForexAccountDetail> findForexAccountDetailPage(Page<ForexAccountDetail> page) {
        Page<ForexAccountDetail> result = page(page);
        return result;
    }
}
