package cn.mesmile.finance.controller;

import cn.mesmile.finance.entity.CashWithdrawAuditRecord;
import org.hibernate.validator.constraints.pl.REGON;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.CashWithdrawalsService;
import cn.mesmile.finance.entity.CashWithdrawals;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 提现表 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "提现表相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/cash-withdrawals")
public class CashWithdrawalsController {

    private final CashWithdrawalsService cashWithdrawalsService;

    @ApiOperation("分页查询提现表")
    @GetMapping("/records")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
            @ApiImplicitParam(value = "用户名",name = "userName"),
            @ApiImplicitParam(value = "电话号码",name = "mobile"),
            @ApiImplicitParam(value = "提现状态",name = "status"),
            @ApiImplicitParam(value = "最小提现金额",name = "numMin"),
            @ApiImplicitParam(value = "最大提现金额",name = "numMax"),
            @ApiImplicitParam(value = "开始时间",name = "startTime"),
            @ApiImplicitParam(value = "结束时间",name = "endTime")
    })
    public R<Page<CashWithdrawals>> findCashWithdrawalsPage(@ApiIgnore Page<CashWithdrawals> page, String userName, String mobile, Integer status, Integer numMin,
                                                            Integer numMax, Date startTime, Date endTime){
        Page<CashWithdrawals> result = cashWithdrawalsService.findCashWithdrawalsPage(page,userName,mobile,status, numMin,numMax,startTime,endTime);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增提现表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "cashWithdrawals", value = "cashWithdrawals对象的json数据")
    })
    public R save(@RequestBody CashWithdrawals cashWithdrawals){
        boolean save = cashWithdrawalsService.save(cashWithdrawals);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改提现表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "cashWithdrawals", value = "cashWithdrawals对象的json数据")
    })
    public R update(@RequestBody CashWithdrawals cashWithdrawals){
        boolean update = cashWithdrawalsService.updateById(cashWithdrawals);
        return R.status(update);
    }

    @ApiOperation("删除提现表")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = cashWithdrawalsService.removeByIds(ids);
        return R.data(delete);
    }

    @PostMapping("/updateWithdrawalsStatus")
    @ApiOperation("提现审核")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateWithdrawalsStatus(@RequestBody CashWithdrawAuditRecord cashWithdrawAuditRecord){
        // Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        Long userId = 123456L;
        boolean result = cashWithdrawalsService.updateWithdrawalsStatus(cashWithdrawAuditRecord);
        return R.status(result);
    }


}
