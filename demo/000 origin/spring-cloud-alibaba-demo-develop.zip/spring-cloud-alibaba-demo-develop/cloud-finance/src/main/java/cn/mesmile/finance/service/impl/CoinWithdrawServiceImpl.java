package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.CoinRecharge;
import cn.mesmile.finance.entity.CoinWithdraw;
import cn.mesmile.finance.mapper.CoinWithdrawMapper;
import cn.mesmile.finance.service.CoinWithdrawService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * <p>
 * 数字货币提现记录 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class CoinWithdrawServiceImpl extends ServiceImpl<CoinWithdrawMapper, CoinWithdraw> implements CoinWithdrawService {

    @Override
    public Page<CoinWithdraw> findCoinWithdrawPage(Page<CoinWithdraw> page, String userName, String mobile, Integer status, Integer numMin,
                                                   Integer numMax, Date startTime, Date endTime) {
        //  todo userName  mobile 转换成 userId
        Page<CoinWithdraw> result = page(page, Wrappers.<CoinWithdraw>lambdaQuery()
                .eq(status != null, CoinWithdraw::getStatus, status)
                .between(numMin!=null && numMax != null, CoinWithdraw::getNum, numMin, numMax)
                .between(startTime!=null && endTime != null, CoinWithdraw::getCreated, startTime, endTime));
        return result;
    }
}
