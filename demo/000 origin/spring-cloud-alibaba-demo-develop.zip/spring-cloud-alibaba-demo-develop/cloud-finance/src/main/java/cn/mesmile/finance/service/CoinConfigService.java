package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.CoinConfig;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 币种配置信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CoinConfigService extends IService<CoinConfig> {

    /**
     * 分页查找币种配置信息
     * @param page 分页信息
     * @return
     */
    Page<CoinConfig> findCoinConfigPage(Page<CoinConfig> page);

    /**
     * 通过币种id 查询币种配置
     * @param coinId
     * @return
     */
    CoinConfig getCoinConfig(Long coinId);
}

