package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.AdminAddress;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 平台归账手续费等账户 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface AdminAddressMapper extends BaseMapper<AdminAddress> {

}
