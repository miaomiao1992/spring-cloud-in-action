package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.CashWithdrawAuditRecord;
import cn.mesmile.finance.mapper.CashWithdrawAuditRecordMapper;
import cn.mesmile.finance.service.CashWithdrawAuditRecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 提现审核记录 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class CashWithdrawAuditRecordServiceImpl extends ServiceImpl<CashWithdrawAuditRecordMapper, CashWithdrawAuditRecord> implements CashWithdrawAuditRecordService {

    @Override
    public Page<CashWithdrawAuditRecord> findCashWithdrawAuditRecordPage(Page<CashWithdrawAuditRecord> page) {
        Page<CashWithdrawAuditRecord> result = page(page);
        return result;
    }
}
