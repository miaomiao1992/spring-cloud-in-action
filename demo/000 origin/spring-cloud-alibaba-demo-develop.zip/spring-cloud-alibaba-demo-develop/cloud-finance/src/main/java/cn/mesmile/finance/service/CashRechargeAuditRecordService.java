package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.CashRechargeAuditRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 充值审核记录 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CashRechargeAuditRecordService extends IService<CashRechargeAuditRecord> {

    /**
     * 分页查找充值审核记录
     * @param page 分页信息
     * @return
     */
    Page<CashRechargeAuditRecord> findCashRechargeAuditRecordPage(Page<CashRechargeAuditRecord> page);

}

