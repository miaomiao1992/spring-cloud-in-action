package cn.mesmile.finance.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.finance.entity.CoinType;
import cn.mesmile.finance.service.CoinTypeService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 币种类型 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@RequiredArgsConstructor
@RestController
@RequestMapping("/coinTypes")
@Api(value = "币种类型相关api")
public class CoinTypeController {

    private final CoinTypeService coinTypeService;

    @ApiOperation("分页查询币种类型")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
            @ApiImplicitParam(value = "币种编码",name = "code")
    })
    @PreAuthorize("hasAuthority('trade_coin_type_query')")
    public R<Page<CoinType>> getCoinTypePage(@ApiIgnore Page<CoinType> page,String code){
        Page<CoinType> result = coinTypeService.getCoinTypePage(page, code);
        return R.data(result);
    }

    @ApiOperation("新增币种类型")
    @PostMapping("/save")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "coinType的json数据",name = "coinType")
    })
    @PreAuthorize("hasAuthority('trade_coin_type_create')")
    public R saveCoinType(@RequestBody CoinType coinType){
        boolean save = coinTypeService.save(coinType);
        return R.data(save);
    }

    @ApiOperation("修改币种类型")
    @PatchMapping("/update")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "coinType的json数据",name = "coinType")
    })
    @PreAuthorize("hasAuthority('trade_coin_type_update')")
    public R updateCoinType(@RequestBody CoinType coinType){
        boolean update = coinTypeService.updateById(coinType);
        return R.data(update);
    }

    @ApiOperation("修改币种状态")
    @PostMapping("/setStatus")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "id",name = "id"),
            @ApiImplicitParam(value = "status状态",name = "status"),
    })
    @PreAuthorize("hasAuthority('trade_coin_type_update')")
    public R updateCoinType(@RequestParam(value = "id") Long id, @RequestParam(value = "status") Integer status){
        boolean update = coinTypeService.updateCoinTypeStatus(id, status);
        return R.data(update);
    }

    @ApiOperation("查询所有币种，根据状态")
    @PostMapping("/all")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "status状态",name = "status"),
    })
    @PreAuthorize("hasAuthority('trade_coin_type_query')")
    public R<List<CoinType>> updateCoinType(@RequestParam(value = "status") Integer status){
        List<CoinType> list = coinTypeService.list(Wrappers.<CoinType>lambdaQuery()
                .eq(status != null,CoinType::getStatus, status));
        return R.data(list);
    }

}
