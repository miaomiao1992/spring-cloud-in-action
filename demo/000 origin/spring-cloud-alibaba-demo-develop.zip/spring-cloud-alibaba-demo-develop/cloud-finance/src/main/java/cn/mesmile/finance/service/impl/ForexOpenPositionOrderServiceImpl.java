package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.ForexOpenPositionOrder;
import cn.mesmile.finance.mapper.ForexOpenPositionOrderMapper;
import cn.mesmile.finance.service.ForexOpenPositionOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 开仓订单信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class ForexOpenPositionOrderServiceImpl extends ServiceImpl<ForexOpenPositionOrderMapper, ForexOpenPositionOrder> implements ForexOpenPositionOrderService {

    @Override
    public Page<ForexOpenPositionOrder> findForexOpenPositionOrderPage(Page<ForexOpenPositionOrder> page) {
        Page<ForexOpenPositionOrder> result = page(page);
        return result;
    }
}
