package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.ForexOpenPositionOrder;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 开仓订单信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface ForexOpenPositionOrderService extends IService<ForexOpenPositionOrder> {

    /**
     * 分页查找开仓订单信息
     * @param page 分页信息
     * @return
     */
    Page<ForexOpenPositionOrder> findForexOpenPositionOrderPage(Page<ForexOpenPositionOrder> page);
}

