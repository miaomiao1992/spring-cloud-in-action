package cn.mesmile.finance.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.ForexAccountService;
import cn.mesmile.finance.entity.ForexAccount;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 创新交易持仓信息 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "创新交易持仓信息相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/forex-account")
public class ForexAccountController {

    private final ForexAccountService forexAccountService;

    @ApiOperation("分页查询创新交易持仓信息")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<ForexAccount>> findForexAccountPage(@ApiIgnore Page<ForexAccount> page){
        Page<ForexAccount> result = forexAccountService.findForexAccountPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增创新交易持仓信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "forexAccount", value = "forexAccount对象的json数据")
    })
    public R save(@RequestBody ForexAccount forexAccount){
        boolean save = forexAccountService.save(forexAccount);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改创新交易持仓信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "forexAccount", value = "forexAccount对象的json数据")
    })
    public R update(@RequestBody ForexAccount forexAccount){
        boolean update = forexAccountService.updateById(forexAccount);
        return R.status(update);
    }

    @ApiOperation("删除创新交易持仓信息")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = forexAccountService.removeByIds(ids);
        return R.data(delete);
    }
}
