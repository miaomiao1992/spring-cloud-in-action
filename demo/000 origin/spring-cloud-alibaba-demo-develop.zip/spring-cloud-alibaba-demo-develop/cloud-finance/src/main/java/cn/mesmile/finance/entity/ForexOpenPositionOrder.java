package cn.mesmile.finance.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 开仓订单信息
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("forex_open_position_order")
@ApiModel(value = "ForexOpenPositionOrder对象", description = "开仓订单信息")
public class ForexOpenPositionOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户ID")
    private Long userId;

    @ApiModelProperty("交易对ID")
    private Long marketId;

    @ApiModelProperty("交易对名称")
    private String marketName;

    @ApiModelProperty("结算币种")
    private Long coinId;

    @ApiModelProperty("持仓方向：1-买；2-卖")
    private Integer type;

    @ApiModelProperty("资金账户ID")
    private Long accountId;

    @ApiModelProperty("委托订单")
    private Long entrustOrderId;

    @ApiModelProperty("成交订单号")
    private Long orderId;

    @ApiModelProperty("成交价格")
    private BigDecimal price;

    @ApiModelProperty("成交数量")
    private BigDecimal num;

    @ApiModelProperty("扣除保证金")
    private BigDecimal lockMargin;

    @ApiModelProperty("平仓量")
    private BigDecimal closeNum;

    @ApiModelProperty("状态：1：未平仓；2-已平仓")
    private Integer status;

    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;

    @ApiModelProperty("创建时间")
    private Date created;


}
