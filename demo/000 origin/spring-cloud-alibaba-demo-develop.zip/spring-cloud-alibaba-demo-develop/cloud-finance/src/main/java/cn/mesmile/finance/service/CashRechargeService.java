package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.CashRecharge;
import cn.mesmile.finance.entity.CashRechargeAuditRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.Date;

/**
 * <p>
 * 充值表 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CashRechargeService extends IService<CashRecharge> {

    /**
     * 分页查找充值表
     * @param page 分页信息
     * @return
     */
    Page<CashRecharge> findCashRechargePage(Page<CashRecharge> page, String userName, String mobile, Integer status, Integer numMin,
                                            Integer numMax, Date startTime, Date endTime);

    /**
     * 审核充值
     * @param userId
     * @param cashRechargeAuditRecord
     * @return
     */
    boolean cashRechargeUpdateStatus(Long userId, CashRechargeAuditRecord cashRechargeAuditRecord);
}

