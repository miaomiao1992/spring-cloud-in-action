package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.ForexAccount;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 创新交易持仓信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface ForexAccountService extends IService<ForexAccount> {

    /**
     * 分页查找创新交易持仓信息
     * @param page 分页信息
     * @return
     */
    Page<ForexAccount> findForexAccountPage(Page<ForexAccount> page);
}

