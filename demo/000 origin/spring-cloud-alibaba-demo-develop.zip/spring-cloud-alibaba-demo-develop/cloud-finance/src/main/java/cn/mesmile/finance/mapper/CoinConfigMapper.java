package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.CoinConfig;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 币种配置信息 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CoinConfigMapper extends BaseMapper<CoinConfig> {

}
