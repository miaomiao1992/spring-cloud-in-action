package cn.mesmile.finance.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.common.exception.ServiceException;
import cn.mesmile.finance.entity.CashRecharge;
import cn.mesmile.finance.entity.CashRechargeAuditRecord;
import cn.mesmile.finance.mapper.CashRechargeAuditRecordMapper;
import cn.mesmile.finance.mapper.CashRechargeMapper;
import cn.mesmile.finance.service.AccountService;
import cn.mesmile.finance.service.CashRechargeService;
import com.alicp.jetcache.Cache;
import com.alicp.jetcache.anno.CacheType;
import com.alicp.jetcache.anno.CreateCache;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import net.sf.jsqlparser.statement.execute.Execute;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * <p>
 * 充值表 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class CashRechargeServiceImpl extends ServiceImpl<CashRechargeMapper, CashRecharge> implements CashRechargeService {

    @CreateCache(name = "CASH_RECHARGE_LOCK:",expire = 60,timeUnit = TimeUnit.SECONDS,cacheType = CacheType.BOTH)
    private Cache<String,String> cache;

    @Autowired
    private CashRechargeAuditRecordMapper cashRechargeAuditRecordMapper;
    @Autowired
    private AccountService accountService;

    @Override
    public Page<CashRecharge> findCashRechargePage(Page<CashRecharge> page, String userName, String mobile, Integer status,
                                                   Integer numMin,
                                                   Integer numMax, Date startTime, Date endTime) {
        // todo userName  mobile userId 是用户信息
        Page<CashRecharge> result = page(page, Wrappers.<CashRecharge>lambdaQuery()
                .between(numMin!=null && numMax != null, CashRecharge::getNum, numMin, numMax)
                .between(startTime!=null && endTime != null, CashRecharge::getLastTime, startTime, endTime)
        );
        return result;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean cashRechargeUpdateStatus(Long userId, CashRechargeAuditRecord cashRechargeAuditRecord) {
        // 只能同时有一个人去操作
        AtomicBoolean update = new AtomicBoolean(false);
        boolean result = cache.tryLockAndRun(cashRechargeAuditRecord.getId().toString(), 3, TimeUnit.SECONDS, () -> {
            Long id = cashRechargeAuditRecord.getId();
            CashRecharge cashRecharge = getById(id);
            if (cashRecharge == null){
                throw new ServiceException("当前充值记录不存在");
            }
            Integer status = cashRecharge.getStatus();
            if (Objects.equals(status,1)){
                throw  new ServiceException("审核已经通过，无需再审核");
            }
            CashRechargeAuditRecord cashRechargeAuditRecordDb = new CashRechargeAuditRecord();
            cashRechargeAuditRecordDb.setAuditUserId(userId);
            cashRechargeAuditRecordDb.setStatus(status);
            cashRechargeAuditRecordDb.setRemark(cashRechargeAuditRecord.getRemark());
            Integer step = cashRecharge.getStep();
            cashRechargeAuditRecordDb.setStep(step + 1);
            int insert = cashRechargeAuditRecordMapper.insert(cashRechargeAuditRecordDb);
            if (insert < 1){
                throw new ServiceException("审核失败");
            }
            cashRecharge.setStatus(status);
            cashRecharge.setAuditRemark(cashRechargeAuditRecord.getRemark());
            cashRecharge.setStep(step + 1);
            // 审核拒绝
            if (Objects.equals(status,2)){
                boolean update1 = updateById(cashRecharge);
                if (update1){
                    throw new ServiceException("审核失败");
                }
            }
            // 审核通过
            if(Objects.equals(status,1)){
                // String businessType, Integer direction,String remark
                // 给用户账号充钱
                boolean isOk = accountService.transferAccountAmount(userId, cashRecharge.getUserId(),
                        cashRecharge.getId(),cashRecharge.getCoinId(),cashRecharge.getNum(),cashRecharge.getFee()
                        , "recharge_into", 1 ,"充值" );
                if (isOk){
                    cashRecharge.setLastTime(new Date());
                    boolean update1 = updateById(cashRecharge);
                    if (update1){
                        throw new ServiceException("审核失败");
                    }
                }
            }

        });
        return update.get();
    }
}
