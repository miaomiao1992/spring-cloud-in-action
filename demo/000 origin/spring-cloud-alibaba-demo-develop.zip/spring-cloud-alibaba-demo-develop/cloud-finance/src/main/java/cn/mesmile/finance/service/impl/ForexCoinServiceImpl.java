package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.ForexCoin;
import cn.mesmile.finance.mapper.ForexCoinMapper;
import cn.mesmile.finance.service.ForexCoinService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 创新交易币种表 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class ForexCoinServiceImpl extends ServiceImpl<ForexCoinMapper, ForexCoin> implements ForexCoinService {

    @Override
    public Page<ForexCoin> findForexCoinPage(Page<ForexCoin> page) {
        Page<ForexCoin> result = page(page);
        return result;
    }
}
