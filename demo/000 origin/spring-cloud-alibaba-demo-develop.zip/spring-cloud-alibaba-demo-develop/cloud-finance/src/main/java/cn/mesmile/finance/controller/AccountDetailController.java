package cn.mesmile.finance.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.AccountDetailService;
import cn.mesmile.finance.entity.AccountDetail;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 资金账户流水 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "资金账户流水相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/account-detail")
public class AccountDetailController {

    private final AccountDetailService accountDetailService;

    @ApiOperation("分页查询资金账户流水")
    @GetMapping("/records")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
            @ApiImplicitParam(value = "用户名",name = "userName"),
            @ApiImplicitParam(value = "电话号码",name = "mobile"),
            @ApiImplicitParam(value = "币种id",name = "coinId"),
            @ApiImplicitParam(value = "资产最小值",name = "amountStart"),
            @ApiImplicitParam(value = "资产最大值",name = "amountEnd"),
            @ApiImplicitParam(value = "开始时间",name = "startTime"),
            @ApiImplicitParam(value = "结束时间",name = "endTime"),
    })
    public R<Page<AccountDetail>> findAccountDetailPage(@ApiIgnore Page<AccountDetail> page){
        Page<AccountDetail> result = accountDetailService.findAccountDetailPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增资金账户流水")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "accountDetail", value = "accountDetail对象的json数据")
    })
    public R save(@RequestBody AccountDetail accountDetail){
        boolean save = accountDetailService.save(accountDetail);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改资金账户流水")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "accountDetail", value = "accountDetail对象的json数据")
    })
    public R update(@RequestBody AccountDetail accountDetail){
        boolean update = accountDetailService.updateById(accountDetail);
        return R.status(update);
    }

    @ApiOperation("删除资金账户流水")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = accountDetailService.removeByIds(ids);
        return R.data(delete);
    }
}
