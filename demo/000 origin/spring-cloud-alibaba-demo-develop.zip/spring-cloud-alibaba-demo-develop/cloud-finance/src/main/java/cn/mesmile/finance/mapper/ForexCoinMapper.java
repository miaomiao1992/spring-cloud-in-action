package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.ForexCoin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 创新交易币种表 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface ForexCoinMapper extends BaseMapper<ForexCoin> {

}
