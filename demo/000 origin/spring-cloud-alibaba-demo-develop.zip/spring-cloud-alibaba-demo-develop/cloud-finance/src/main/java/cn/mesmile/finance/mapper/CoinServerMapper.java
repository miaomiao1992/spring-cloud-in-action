package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.CoinServer;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 监测当前服务器Ip状态 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CoinServerMapper extends BaseMapper<CoinServer> {

}
