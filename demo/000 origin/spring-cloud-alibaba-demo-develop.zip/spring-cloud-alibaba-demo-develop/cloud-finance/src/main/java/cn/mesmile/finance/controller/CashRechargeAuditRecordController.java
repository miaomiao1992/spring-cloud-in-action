package cn.mesmile.finance.controller;

import cn.mesmile.common.result.R;
import cn.mesmile.finance.entity.CashRechargeAuditRecord;
import cn.mesmile.finance.service.CashRechargeAuditRecordService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

/**
 * <p>
 * 充值审核记录 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "充值审核记录相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/cash-recharge-audit-record")
public class CashRechargeAuditRecordController {

    private final CashRechargeAuditRecordService cashRechargeAuditRecordService;

    @ApiOperation("分页查询充值审核记录")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<CashRechargeAuditRecord>> findCashRechargeAuditRecordPage(@ApiIgnore Page<CashRechargeAuditRecord> page){
        Page<CashRechargeAuditRecord> result = cashRechargeAuditRecordService.findCashRechargeAuditRecordPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增充值审核记录")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "cashRechargeAuditRecord", value = "cashRechargeAuditRecord对象的json数据")
    })
    public R save(@RequestBody CashRechargeAuditRecord cashRechargeAuditRecord){
        boolean save = cashRechargeAuditRecordService.save(cashRechargeAuditRecord);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改充值审核记录")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "cashRechargeAuditRecord", value = "cashRechargeAuditRecord对象的json数据")
    })
    public R update(@RequestBody CashRechargeAuditRecord cashRechargeAuditRecord){
        boolean update = cashRechargeAuditRecordService.updateById(cashRechargeAuditRecord);
        return R.status(update);
    }

    @ApiOperation("删除充值审核记录")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = cashRechargeAuditRecordService.removeByIds(ids);
        return R.data(delete);
    }
}
