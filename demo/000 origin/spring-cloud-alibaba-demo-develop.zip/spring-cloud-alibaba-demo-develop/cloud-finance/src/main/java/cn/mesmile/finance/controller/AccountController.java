package cn.mesmile.finance.controller;

import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.AccountService;
import cn.mesmile.finance.entity.Account;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;

import java.security.SecureRandom;
import java.util.List;

/**
 * <p>
 * 用户财产记录 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "用户财产记录相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/account")
public class AccountController {

    private final AccountService accountService;

    @ApiOperation("分页查询用户财产记录")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<Account>> findAccountPage(@ApiIgnore Page<Account> page){
        Page<Account> result = accountService.findAccountPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增用户财产记录")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "account", value = "account对象的json数据")
    })
    public R save(@RequestBody Account account){
        boolean save = accountService.save(account);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改用户财产记录")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "account", value = "account对象的json数据")
    })
    public R update(@RequestBody Account account){
        boolean update = accountService.updateById(account);
        return R.status(update);
    }

    @ApiOperation("删除用户财产记录")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = accountService.removeByIds(ids);
        return R.data(delete);
    }

    @ApiOperation("获取当前用户的货币的资产情况")
    @PostMapping("/{coinName}")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "货币的中文名",name = "coinName"),
    })
    public R findCoinByCoinName(@PathVariable("coinName")String coinName){
        // Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        //  TODO
        Long userId = 123456L;
        Account account = accountService.findCoinByCoinName(userId, coinName);
        return R.data(account);
    }

}
