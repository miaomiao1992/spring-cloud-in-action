package cn.mesmile.finance.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 币种余额
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("coin_balance")
@ApiModel(value = "CoinBalance对象", description = "币种余额")
public class CoinBalance implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    private Long id;

    @ApiModelProperty("币种ID")
    private Long coinId;

    @ApiModelProperty("币种名称")
    private String coinName;

    @ApiModelProperty("系统余额（根据充值提币计算）")
    private BigDecimal systemBalance;

    @ApiModelProperty("币种类型")
    private String coinType;

    @ApiModelProperty("归集账户余额")
    private BigDecimal collectAccountBalance;

    @ApiModelProperty("钱包账户余额")
    private BigDecimal loanAccountBalance;

    @ApiModelProperty("手续费账户余额(eth转账需要手续费)")
    private BigDecimal feeAccountBalance;

    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @ApiModelProperty("创建时间")
    private Date created;

    private BigDecimal rechargeAccountBalance;


}
