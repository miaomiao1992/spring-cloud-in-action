package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.CoinWithdrawAuditRecord;
import cn.mesmile.finance.mapper.CoinWithdrawAuditRecordMapper;
import cn.mesmile.finance.service.CoinWithdrawAuditRecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 提币审核记录 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class CoinWithdrawAuditRecordServiceImpl extends ServiceImpl<CoinWithdrawAuditRecordMapper, CoinWithdrawAuditRecord> implements CoinWithdrawAuditRecordService {

    @Override
    public Page<CoinWithdrawAuditRecord> findCoinWithdrawAuditRecordPage(Page<CoinWithdrawAuditRecord> page) {
        Page<CoinWithdrawAuditRecord> result = page(page);
        return result;
    }
}
