package cn.mesmile.finance.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.CoinWithdrawService;
import cn.mesmile.finance.entity.CoinWithdraw;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 数字货币提现记录 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "数字货币提现记录相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/coin-withdraw")
public class CoinWithdrawController {

    private final CoinWithdrawService coinWithdrawService;

    @ApiOperation("分页查询数字货币提现记录")
    @GetMapping("/records")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
            @ApiImplicitParam(value = "用户名",name = "userName"),
            @ApiImplicitParam(value = "电话号码",name = "mobile"),
            @ApiImplicitParam(value = "充值状态",name = "status"),
            @ApiImplicitParam(value = "最小提现金额",name = "numMin"),
            @ApiImplicitParam(value = "最大提现金额",name = "numMax"),
            @ApiImplicitParam(value = "开始提现时间",name = "startTime"),
            @ApiImplicitParam(value = "结束提现时间",name = "endTime")
    })
    public R<Page<CoinWithdraw>> findCoinWithdrawPage(@ApiIgnore Page<CoinWithdraw> page, String userName, String mobile, Integer status, Integer numMin,
                                                      Integer numMax, Date startTime, Date endTime){
        Page<CoinWithdraw> result = coinWithdrawService.findCoinWithdrawPage(page,userName,mobile,status, numMin,numMax,startTime,endTime);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增数字货币提现记录")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "coinWithdraw", value = "coinWithdraw对象的json数据")
    })
    public R save(@RequestBody CoinWithdraw coinWithdraw){
        boolean save = coinWithdrawService.save(coinWithdraw);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改数字货币提现记录")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "coinWithdraw", value = "coinWithdraw对象的json数据")
    })
    public R update(@RequestBody CoinWithdraw coinWithdraw){
        boolean update = coinWithdrawService.updateById(coinWithdraw);
        return R.status(update);
    }

    @ApiOperation("删除数字货币提现记录")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = coinWithdrawService.removeByIds(ids);
        return R.data(delete);
    }
}
