package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.ForexClosePositionOrder;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 平仓详情 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface ForexClosePositionOrderService extends IService<ForexClosePositionOrder> {

    /**
     * 分页查找平仓详情
     * @param page 分页信息
     * @return
     */
    Page<ForexClosePositionOrder> findForexClosePositionOrderPage(Page<ForexClosePositionOrder> page);
}

