package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.CoinType;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 币种类型 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CoinTypeMapper extends BaseMapper<CoinType> {

}
