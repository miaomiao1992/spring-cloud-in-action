package cn.mesmile.finance.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 监测当前服务器Ip状态
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("coin_server")
@ApiModel(value = "CoinServer对象", description = "监测当前服务器Ip状态")
public class CoinServer implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("自增id")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("钱包服务器ip")
    private String rpcIp;

    @ApiModelProperty("钱包服务器ip")
    private String rpcPort;

    @ApiModelProperty("服务是否运行 0:正常,1:停止")
    private Integer running;

    @ApiModelProperty("钱包服务器区块高度")
    private Long walletNumber;

    private String coinName;

    @ApiModelProperty("备注信息")
    private String mark;

    @ApiModelProperty("真实区块高度")
    private Long realNumber;

    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;

    @ApiModelProperty("创建时间")
    private Date created;


}
