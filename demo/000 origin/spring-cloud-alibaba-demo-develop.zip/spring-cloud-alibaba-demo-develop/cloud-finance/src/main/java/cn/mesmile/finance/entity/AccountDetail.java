package cn.mesmile.finance.entity;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

/**
 * <p>
 * 资金账户流水
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("account_detail")
@ApiModel(value = "AccountDetail对象", description = "资金账户流水")
public class AccountDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户id")
    private Long userId;

    @ApiModelProperty("币种id")
    private Long coinId;

    @ApiModelProperty("账户id")
    private Long accountId;

    @ApiModelProperty("该笔流水资金关联方的账户id")
    private Long refAccountId;

    @ApiModelProperty("订单ID")
    private Long orderId;

    @ApiModelProperty("入账为1，出账为2")
    private Integer direction;

    @ApiModelProperty("业务类型:	充值(recharge_into) 	提现审核通过(withdrawals_out) 	下单(order_create) 	成交(order_turnover)	成交手续费(order_turnover_poundage)  	撤单(order_cancel)  	注册奖励(bonus_register)	提币冻结解冻(withdrawals)	充人民币(recharge)	提币手续费(withdrawals_poundage)   	兑换(cny_btcx_exchange)	奖励充值(bonus_into)	奖励冻结(bonus_freeze)")
    private String businessType;

    @ApiModelProperty("资产数量")
    private BigDecimal amount;

    @ApiModelProperty("手续费")
    private BigDecimal fee;

    @ApiModelProperty("流水状态：	充值	提现	冻结	解冻	转出	转入")
    private String remark;

    @TableField(value = "created", fill = FieldFill.INSERT)
    @ApiModelProperty("日期")
    private Date created;


}
