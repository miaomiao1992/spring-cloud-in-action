package cn.mesmile.finance.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.ForexCoinService;
import cn.mesmile.finance.entity.ForexCoin;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 创新交易币种表 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "创新交易币种表相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/forex-coin")
public class ForexCoinController {

    private final ForexCoinService forexCoinService;

    @ApiOperation("分页查询创新交易币种表")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<ForexCoin>> findForexCoinPage(@ApiIgnore Page<ForexCoin> page){
        Page<ForexCoin> result = forexCoinService.findForexCoinPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增创新交易币种表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "forexCoin", value = "forexCoin对象的json数据")
    })
    public R save(@RequestBody ForexCoin forexCoin){
        boolean save = forexCoinService.save(forexCoin);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改创新交易币种表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "forexCoin", value = "forexCoin对象的json数据")
    })
    public R update(@RequestBody ForexCoin forexCoin){
        boolean update = forexCoinService.updateById(forexCoin);
        return R.status(update);
    }

    @ApiOperation("删除创新交易币种表")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = forexCoinService.removeByIds(ids);
        return R.data(delete);
    }
}
