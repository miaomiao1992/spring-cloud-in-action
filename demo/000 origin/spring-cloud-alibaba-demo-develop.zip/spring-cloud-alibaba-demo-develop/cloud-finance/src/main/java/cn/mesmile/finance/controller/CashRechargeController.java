package cn.mesmile.finance.controller;

import cn.mesmile.finance.entity.CashRechargeAuditRecord;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.CashRechargeService;
import cn.mesmile.finance.entity.CashRecharge;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 充值表 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "充值表相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/cash-recharge")
public class CashRechargeController {

    private final CashRechargeService cashRechargeService;

    @ApiOperation("分页查询充值表")
    @GetMapping("/records")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
            @ApiImplicitParam(value = "用户名",name = "userName"),
            @ApiImplicitParam(value = "电话号码",name = "mobile"),
            @ApiImplicitParam(value = "审核状态",name = "status"),
            @ApiImplicitParam(value = "最小充值金额",name = "numMin"),
            @ApiImplicitParam(value = "最大充值金额",name = "numMax"),
            @ApiImplicitParam(value = "开始时间",name = "startTime"),
            @ApiImplicitParam(value = "结束时间",name = "endTime")
    })
    public R<Page<CashRecharge>> findCashRechargePage(@ApiIgnore Page<CashRecharge> page,
                                                      String userName, String mobile, Integer status, Integer numMin,
                                                      Integer numMax, Date startTime,Date endTime
                                                      ){
        Page<CashRecharge> result = cashRechargeService.findCashRechargePage(page,userName,mobile,status, numMin,numMax,startTime,endTime);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增充值表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "cashRecharge", value = "cashRecharge对象的json数据")
    })
    public R save(@RequestBody CashRecharge cashRecharge){
        boolean save = cashRechargeService.save(cashRecharge);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改充值表")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "cashRecharge", value = "cashRecharge对象的json数据")
    })
    public R update(@RequestBody CashRecharge cashRecharge){
        boolean update = cashRechargeService.updateById(cashRecharge);
        return R.status(update);
    }

    @ApiOperation("删除充值表")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = cashRechargeService.removeByIds(ids);
        return R.data(delete);
    }


    @ApiOperation("现金充值审核")
    @PostMapping("/cashRechargeUpdateStatus")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "cashRechargeAuditRecord的json数据",name = "cashRechargeAuditRecord"),
    })
    public R cashRechargeUpdateStatus(@RequestBody CashRechargeAuditRecord cashRechargeAuditRecord){
        // Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        // todo userId
        Long userId = 123456L;
        boolean update = cashRechargeService.cashRechargeUpdateStatus(userId, cashRechargeAuditRecord);
        return R.status(update);
    }
}
