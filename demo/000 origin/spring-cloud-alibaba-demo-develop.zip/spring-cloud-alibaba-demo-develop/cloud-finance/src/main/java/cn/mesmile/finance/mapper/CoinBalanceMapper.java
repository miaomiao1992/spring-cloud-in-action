package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.CoinBalance;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 币种余额 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CoinBalanceMapper extends BaseMapper<CoinBalance> {

}
