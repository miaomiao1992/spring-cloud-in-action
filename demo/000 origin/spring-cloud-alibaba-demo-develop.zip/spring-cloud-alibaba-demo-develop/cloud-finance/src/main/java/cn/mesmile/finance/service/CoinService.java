package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.Coin;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 币种配置信息 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CoinService extends IService<Coin> {

    /**
     * 分页查找币种配置信息
     * @param page 分页信息
     * @param name 名称
     * @param type 币种类型
     * @param title 币种标题
     * @param status 币种状态
     * @param walletType 钱包类型
     * @return
     */
    Page<Coin> findCoinPage(Page<Coin> page,String name, String type,
                            String title,Integer status,String walletType);

    /**
     *  通过货币名查找货币
     * @param coinName
     * @return
     */
    Coin findCoinByCoinName(String coinName);
}

