package cn.mesmile.finance.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 创新交易持仓信息
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("forex_account")
@ApiModel(value = "ForexAccount对象", description = "创新交易持仓信息")
public class ForexAccount implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户ID")
    private Long userId;

    @ApiModelProperty("交易对ID")
    private Long marketId;

    @ApiModelProperty("交易对")
    private String marketName;

    @ApiModelProperty("持仓方向：1-买；2-卖")
    private Integer type;

    @ApiModelProperty("持仓量")
    private BigDecimal amount;

    @ApiModelProperty("冻结持仓量")
    private BigDecimal lockAmount;

    @ApiModelProperty("状态：1-有效；2-锁定；")
    private Integer status;

    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;

    @ApiModelProperty("创建时间")
    private Date created;


}
