package cn.mesmile.finance.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 平台归账手续费等账户
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("admin_address")
@ApiModel(value = "AdminAddress对象", description = "平台归账手续费等账户")
public class AdminAddress implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("编号")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("币种Id")
    private Long coinId;

    @ApiModelProperty("eth keystore")
    private String keystore;

    @ApiModelProperty("eth账号密码")
    private String pwd;

    @ApiModelProperty("地址")
    private String address;

    @ApiModelProperty("1:归账(冷钱包地址),2:打款,3:手续费")
    private Integer status;

    @ApiModelProperty("类型")
    private String coinType;


}
