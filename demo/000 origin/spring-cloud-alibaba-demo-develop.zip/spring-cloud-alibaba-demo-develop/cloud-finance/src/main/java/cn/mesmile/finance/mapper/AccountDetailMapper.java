package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.AccountDetail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 资金账户流水 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface AccountDetailMapper extends BaseMapper<AccountDetail> {

}
