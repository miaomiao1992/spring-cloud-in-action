package cn.mesmile.finance.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.CoinServerService;
import cn.mesmile.finance.entity.CoinServer;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 监测当前服务器Ip状态 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "监测当前服务器Ip状态相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/coin-server")
public class CoinServerController {

    private final CoinServerService coinServerService;

    @ApiOperation("分页查询监测当前服务器Ip状态")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<CoinServer>> findCoinServerPage(@ApiIgnore Page<CoinServer> page){
        Page<CoinServer> result = coinServerService.findCoinServerPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增监测当前服务器Ip状态")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "coinServer", value = "coinServer对象的json数据")
    })
    public R save(@RequestBody CoinServer coinServer){
        boolean save = coinServerService.save(coinServer);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改监测当前服务器Ip状态")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "coinServer", value = "coinServer对象的json数据")
    })
    public R update(@RequestBody CoinServer coinServer){
        boolean update = coinServerService.updateById(coinServer);
        return R.status(update);
    }

    @ApiOperation("删除监测当前服务器Ip状态")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = coinServerService.removeByIds(ids);
        return R.data(delete);
    }
}
