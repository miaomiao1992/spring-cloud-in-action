package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.CoinWithdrawAuditRecord;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 提币审核记录 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CoinWithdrawAuditRecordService extends IService<CoinWithdrawAuditRecord> {

    /**
     * 分页查找提币审核记录
     * @param page 分页信息
     * @return
     */
    Page<CoinWithdrawAuditRecord> findCoinWithdrawAuditRecordPage(Page<CoinWithdrawAuditRecord> page);
}

