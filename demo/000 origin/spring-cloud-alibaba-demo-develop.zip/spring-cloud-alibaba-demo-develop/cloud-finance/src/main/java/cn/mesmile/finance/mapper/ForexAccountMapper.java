package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.ForexAccount;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 创新交易持仓信息 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface ForexAccountMapper extends BaseMapper<ForexAccount> {

}
