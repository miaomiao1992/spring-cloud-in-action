package cn.mesmile.finance.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 提现表
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("cash_withdrawals")
@ApiModel(value = "CashWithdrawals对象", description = "提现表")
public class CashWithdrawals implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户ID")
    private Long userId;

    @ApiModelProperty("币种ID")
    private Long coinId;

    @ApiModelProperty("资金账户ID")
    private Long accountId;

    @ApiModelProperty("数量（提现金额）")
    private BigDecimal num;

    @ApiModelProperty("手续费")
    private BigDecimal fee;

    @ApiModelProperty("到账金额")
    private BigDecimal mum;

    @ApiModelProperty("开户人")
    private String truename;

    @ApiModelProperty("银行名称")
    private String bank;

    @ApiModelProperty("银行所在省")
    private String bankProv;

    @ApiModelProperty("银行所在市")
    private String bankCity;

    @ApiModelProperty("开户行")
    private String bankAddr;

    @ApiModelProperty("银行账号")
    private String bankCard;

    @ApiModelProperty("备注")
    private String remark;

    @ApiModelProperty("当前审核级数")
    private Integer step;

    @ApiModelProperty("状态：0-待审核；1-审核通过；2-拒绝；3-提现成功；")
    private Integer status;

    @ApiModelProperty("创建时间")
    private Date created;

    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @ApiModelProperty("最后确认提现到账时间")
    private Date lastTime;


}
