package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.UserAccountFreeze;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface UserAccountFreezeService extends IService<UserAccountFreeze> {

    /**
     * 分页查找
     * @param page 分页信息
     * @return
     */
    Page<UserAccountFreeze> findUserAccountFreezePage(Page<UserAccountFreeze> page);
}

