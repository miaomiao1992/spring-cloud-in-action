package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.CoinType;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 币种类型 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CoinTypeService extends IService<CoinType> {

    /**
     *  分页查询币种
     * @param page
     * @param code
     * @return
     */
    Page<CoinType> getCoinTypePage(Page<CoinType> page, String code);

    /**
     * 修改状态
     * @param id
     * @param status
     * @return
     */
    boolean updateCoinTypeStatus(Long id, Integer status);
}
