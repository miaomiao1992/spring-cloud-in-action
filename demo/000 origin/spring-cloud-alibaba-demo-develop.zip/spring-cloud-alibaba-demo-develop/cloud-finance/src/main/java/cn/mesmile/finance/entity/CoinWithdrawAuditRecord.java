package cn.mesmile.finance.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 提币审核记录
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("coin_withdraw_audit_record")
@ApiModel(value = "CoinWithdrawAuditRecord对象", description = "提币审核记录")
public class CoinWithdrawAuditRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("提币订单号")
    private Long orderId;

    @ApiModelProperty("状态")
    private Integer status;

    @ApiModelProperty("审核备注")
    private String remark;

    @ApiModelProperty("当前审核级数")
    private Integer step;

    @ApiModelProperty("审核人ID")
    private Long auditUserId;

    @ApiModelProperty("审核人")
    private String auditUserName;

    @ApiModelProperty("创建时间")
    private Date created;


}
