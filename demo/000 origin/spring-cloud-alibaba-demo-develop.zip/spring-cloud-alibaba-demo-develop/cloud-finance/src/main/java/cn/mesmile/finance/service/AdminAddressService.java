package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.AdminAddress;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 平台归账手续费等账户 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface AdminAddressService extends IService<AdminAddress> {

    /**
     * 分页查找平台归账手续费等账户
     * @param page 分页信息
     * @param coinId 币种id
     * @return
     */
    Page<AdminAddress> findAdminAddressPage(Page<AdminAddress> page,Long coinId);

    /**
     * 保存方法
     * @param adminAddress
     * @return
     */
    boolean saveAdminAddress(AdminAddress adminAddress);
}

