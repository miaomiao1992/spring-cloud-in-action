package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.ForexAccountDetail;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 持仓账户流水 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface ForexAccountDetailService extends IService<ForexAccountDetail> {

    /**
     * 分页查找持仓账户流水
     * @param page 分页信息
     * @return
     */
    Page<ForexAccountDetail> findForexAccountDetailPage(Page<ForexAccountDetail> page);
}

