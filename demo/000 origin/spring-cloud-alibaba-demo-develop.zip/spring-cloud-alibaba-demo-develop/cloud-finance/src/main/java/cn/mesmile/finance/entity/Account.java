package cn.mesmile.finance.entity;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

/**
 * <p>
 * 用户财产记录
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("account")
@ApiModel(value = "Account对象", description = "用户财产记录")
public class Account implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("自增id")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户id")
    private Long userId;

    @ApiModelProperty("币种id")
    private Long coinId;

    @ApiModelProperty("账号状态：1，正常；2，冻结；")
    private Boolean status;

    @ApiModelProperty("币种可用金额")
    private BigDecimal balanceAmount;

    @ApiModelProperty("币种冻结金额")
    private BigDecimal freezeAmount;

    @ApiModelProperty("累计充值金额")
    private BigDecimal rechargeAmount;

    @ApiModelProperty("累计提现金额")
    private BigDecimal withdrawalsAmount;

    @ApiModelProperty("净值")
    private BigDecimal netValue;

    @ApiModelProperty("占用保证金")
    private BigDecimal lockMargin;

    @ApiModelProperty("持仓盈亏/浮动盈亏")
    private BigDecimal floatProfit;

    @ApiModelProperty("总盈亏")
    private BigDecimal totalProfit;

    @ApiModelProperty("充值地址")
    private String recAddr;

    @ApiModelProperty("版本号")
    private Long version;

    @TableField(value = "last_update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @TableField(value = "created",fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;

    @TableField(exist = false)
    @ApiModelProperty("卖出的价格")
    private BigDecimal sellRate;

    @TableField(exist = false)
    @ApiModelProperty("卖入的价格")
    private BigDecimal buyRate;


}
