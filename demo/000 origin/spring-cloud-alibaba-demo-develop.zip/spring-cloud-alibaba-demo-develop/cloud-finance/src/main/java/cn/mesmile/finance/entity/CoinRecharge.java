package cn.mesmile.finance.entity;

import com.baomidou.mybatisplus.annotation.*;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 数字货币充值记录
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("coin_recharge")
@ApiModel(value = "CoinRecharge对象", description = "数字货币充值记录")
public class CoinRecharge implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("自增id")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户id")
    private Long userId;

    @ApiModelProperty("币种id")
    private Long coinId;

    @ApiModelProperty("币种名称")
    private String coinName;

    @ApiModelProperty("币种类型")
    private String coinType;

    @ApiModelProperty("钱包地址")
    private String address;

    @ApiModelProperty("充值确认数")
    private Integer confirm;

    @ApiModelProperty("状态：0-待入帐；1-充值失败，2到账失败，3到账成功；")
    private Integer status;

    @ApiModelProperty("交易id")
    private String txid;

    private BigDecimal amount;

    @TableField(value = "last_update_time",fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;

    @TableField(value = "created",fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;


}
