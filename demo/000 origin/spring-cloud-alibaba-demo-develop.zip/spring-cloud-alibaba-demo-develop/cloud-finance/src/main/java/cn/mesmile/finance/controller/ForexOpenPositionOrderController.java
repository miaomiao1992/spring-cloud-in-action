package cn.mesmile.finance.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.ForexOpenPositionOrderService;
import cn.mesmile.finance.entity.ForexOpenPositionOrder;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 开仓订单信息 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "开仓订单信息相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/forex-open-position-order")
public class ForexOpenPositionOrderController {

    private final ForexOpenPositionOrderService forexOpenPositionOrderService;

    @ApiOperation("分页查询开仓订单信息")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<ForexOpenPositionOrder>> findForexOpenPositionOrderPage(@ApiIgnore Page<ForexOpenPositionOrder> page){
        Page<ForexOpenPositionOrder> result = forexOpenPositionOrderService.findForexOpenPositionOrderPage(page);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增开仓订单信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "forexOpenPositionOrder", value = "forexOpenPositionOrder对象的json数据")
    })
    public R save(@RequestBody ForexOpenPositionOrder forexOpenPositionOrder){
        boolean save = forexOpenPositionOrderService.save(forexOpenPositionOrder);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改开仓订单信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "forexOpenPositionOrder", value = "forexOpenPositionOrder对象的json数据")
    })
    public R update(@RequestBody ForexOpenPositionOrder forexOpenPositionOrder){
        boolean update = forexOpenPositionOrderService.updateById(forexOpenPositionOrder);
        return R.status(update);
    }

    @ApiOperation("删除开仓订单信息")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = forexOpenPositionOrderService.removeByIds(ids);
        return R.data(delete);
    }
}
