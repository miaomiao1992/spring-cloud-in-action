package cn.mesmile.finance.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.CoinRechargeService;
import cn.mesmile.finance.entity.CoinRecharge;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 数字货币充值记录 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "数字货币充值记录相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/coin-recharge")
public class CoinRechargeController {

    private final CoinRechargeService coinRechargeService;

    @ApiOperation("分页查询数字货币充值记录")
    @GetMapping("/records")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
            @ApiImplicitParam(value = "用户名",name = "userName"),
            @ApiImplicitParam(value = "电话号码",name = "mobile"),
            @ApiImplicitParam(value = "充值状态",name = "status"),
            @ApiImplicitParam(value = "最小充值金额",name = "numMin"),
            @ApiImplicitParam(value = "最大充值金额",name = "numMax"),
            @ApiImplicitParam(value = "开始充值时间",name = "startTime"),
            @ApiImplicitParam(value = "结束充值时间",name = "endTime")
    })
    public R<Page<CoinRecharge>> findCoinRechargePage(@ApiIgnore Page<CoinRecharge> page, String userName, String mobile, Integer status, Integer numMin,
                                                      Integer numMax, Date startTime, Date endTime){
        Page<CoinRecharge> result = coinRechargeService.findCoinRechargePage(page,userName,mobile,status, numMin,numMax,startTime,endTime);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增数字货币充值记录")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "coinRecharge", value = "coinRecharge对象的json数据")
    })
    public R save(@RequestBody CoinRecharge coinRecharge){
        boolean save = coinRechargeService.save(coinRecharge);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改数字货币充值记录")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "coinRecharge", value = "coinRecharge对象的json数据")
    })
    public R update(@RequestBody CoinRecharge coinRecharge){
        boolean update = coinRechargeService.updateById(coinRecharge);
        return R.status(update);
    }

    @ApiOperation("删除数字货币充值记录")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = coinRechargeService.removeByIds(ids);
        return R.data(delete);
    }
}
