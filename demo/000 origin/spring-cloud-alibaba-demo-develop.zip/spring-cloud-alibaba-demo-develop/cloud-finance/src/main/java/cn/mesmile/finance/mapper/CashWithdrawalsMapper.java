package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.CashWithdrawals;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 提现表 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CashWithdrawalsMapper extends BaseMapper<CashWithdrawals> {

}
