package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.Account;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.math.BigDecimal;

/**
 * <p>
 * 用户财产记录 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface AccountService extends IService<Account> {

    /**
     * 分页查找用户财产记录
     * @param page 分页信息
     * @return
     */
    Page<Account> findAccountPage(Page<Account> page);

    /**
     * 向用户账号充值前
     * @param adminId 管理员
     * @param userId 目标用户
     * @param coinId 币种id
     * @param num 充值多少钱
     * @param fee 手续费
     * @return
     */
    boolean transferAccountAmount(Long adminId, Long userId, Long orderNum,Long coinId, BigDecimal num, BigDecimal fee,String businessType, Integer direction,String remark);

    /**
     *  通过货币名称查询账户数据
     * @param userId
     * @param coinName
     * @return
     */
    Account findCoinByCoinName(Long userId, String coinName);
}

