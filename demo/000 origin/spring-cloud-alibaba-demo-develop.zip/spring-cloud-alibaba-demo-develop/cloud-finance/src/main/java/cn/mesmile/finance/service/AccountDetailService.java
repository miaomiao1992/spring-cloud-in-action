package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.AccountDetail;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 资金账户流水 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface AccountDetailService extends IService<AccountDetail> {

    /**
     * 分页查找资金账户流水
     * @param page 分页信息
     * @return
     */
    Page<AccountDetail> findAccountDetailPage(Page<AccountDetail> page);
}

