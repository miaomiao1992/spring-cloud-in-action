package cn.mesmile.finance.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 * <p>
 * 币种类型
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("coin_type")
@ApiModel(value = "CoinType对象", description = "币种类型")
public class CoinType implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("代码")
    private String code;

    @ApiModelProperty("描述")
    private String description;

    @ApiModelProperty("状态：0-无效；1-有效；")
    private Integer status;

    @ApiModelProperty("创建时间")
    private Date created;

    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;


}
