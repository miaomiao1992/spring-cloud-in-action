package cn.mesmile.finance.entity;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 币种配置信息
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("coin")
@ApiModel(value = "Coin对象", description = "币种配置信息")
public class Coin implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("币种ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("币种名称")
    private String name;

    @ApiModelProperty("币种标题")
    private String title;

    @ApiModelProperty("币种logo")
    private String img;

    @ApiModelProperty("xnb：人民币	default：比特币系列	ETH：以太坊	ethToken：以太坊代币		")
    private String type;

    @ApiModelProperty("rgb：认购币	qbb：钱包币	")
    private String wallet;

    @ApiModelProperty("小数位数")
    private Integer round;

    @ApiModelProperty("最小提现单位")
    private BigDecimal baseAmount;

    @ApiModelProperty("单笔最小提现数量")
    private BigDecimal minAmount;

    @ApiModelProperty("单笔最大提现数量")
    private BigDecimal maxAmount;

    @ApiModelProperty("当日最大提现数量")
    private BigDecimal dayMaxAmount;

    @ApiModelProperty("status=1：启用	0：禁用")
    private Integer status;

    @ApiModelProperty("自动转出数量")
    private Double autoOut;

    @ApiModelProperty("手续费率")
    private Double rate;

    @ApiModelProperty("最低收取手续费个数")
    private BigDecimal minFeeNum;

    @ApiModelProperty("提现开关")
    private Integer withdrawFlag;

    @ApiModelProperty("充值开关")
    private Integer rechargeFlag;

    @TableField(value = "last_update_time", fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @TableField(value = "created", fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;


}
