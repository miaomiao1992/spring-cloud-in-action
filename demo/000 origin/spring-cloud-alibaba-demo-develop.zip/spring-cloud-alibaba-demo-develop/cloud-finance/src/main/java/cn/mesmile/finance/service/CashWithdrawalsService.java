package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.CashWithdrawAuditRecord;
import cn.mesmile.finance.entity.CashWithdrawals;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import java.util.Date;

/**
 * <p>
 * 提现表 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CashWithdrawalsService extends IService<CashWithdrawals> {

    /**
     * 分页查找提现表
     * @param page 分页信息
     * @return
     */
    Page<CashWithdrawals> findCashWithdrawalsPage(Page<CashWithdrawals> page, String userName, String mobile, Integer status, Integer numMin,

                                                  Integer numMax, Date startTime, Date endTime);

    /**
     * 审核提现记录
     * @param cashWithdrawAuditRecord
     * @return
     */
    boolean updateWithdrawalsStatus(CashWithdrawAuditRecord cashWithdrawAuditRecord);
}

