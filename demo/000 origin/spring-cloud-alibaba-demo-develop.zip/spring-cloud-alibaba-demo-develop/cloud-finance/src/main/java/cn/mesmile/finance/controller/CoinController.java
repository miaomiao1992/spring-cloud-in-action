package cn.mesmile.finance.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.CoinService;
import cn.mesmile.finance.entity.Coin;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 币种配置信息 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "币种配置信息相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/coins")
public class CoinController {

    private final CoinService coinService;

    @ApiOperation("分页查询币种配置信息")
    @GetMapping
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
            @ApiImplicitParam(value = "名称",name = "name"),
            @ApiImplicitParam(value = "类型",name = "type"),
            @ApiImplicitParam(value = "标题",name = "title"),
            @ApiImplicitParam(value = "状态",name = "status"),
            @ApiImplicitParam(value = "钱包类型",name = "wallet_type"),
    })
    public R<Page<Coin>> findCoinPage(@ApiIgnore Page<Coin> page,String name, String type,
                                      String title,Integer status,String wallet_type){
        Page<Coin> result = coinService.findCoinPage(page,name,type,title,status,wallet_type);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增币种配置信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "coin", value = "coin对象的json数据")
    })
    public R save(@RequestBody Coin coin){
        boolean save = coinService.save(coin);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改币种配置信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "coin", value = "coin对象的json数据")
    })
    public R update(@RequestBody Coin coin){
        boolean update = coinService.updateById(coin);
        return R.status(update);
    }

    @ApiOperation("删除币种配置信息")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = coinService.removeByIds(ids);
        return R.data(delete);
    }

    @PostMapping("/setStatus")
    @ApiOperation("禁用或者启用")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "id值"),
            @ApiImplicitParam(name = "status", value = "状态")
    })
    public R setStatus(@RequestParam("id")Long id ,@RequestParam("status")Integer status){
        boolean update = coinService.update(Wrappers.<Coin>lambdaUpdate().eq(Coin::getId, id).set(Coin::getStatus, status));
        return R.status(update);
    }

    @GetMapping("/info/{id}")
    @ApiOperation("查询单条信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "id值"),
    })
    public R setStatus(@PathVariable("id")Long id){
        Coin coin = coinService.getById(id);
        return R.data(coin);
    }

    @GetMapping("/all")
    @ApiOperation("查询所有币种信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "status", value = "币种状态"),
    })
    public R<List<Coin>> allCoin(@RequestParam("status")Integer status){
        List<Coin> list = coinService.list(Wrappers.<Coin>lambdaQuery()
                .eq(status != null, Coin::getStatus, status));
        return R.data(list);
    }

}
