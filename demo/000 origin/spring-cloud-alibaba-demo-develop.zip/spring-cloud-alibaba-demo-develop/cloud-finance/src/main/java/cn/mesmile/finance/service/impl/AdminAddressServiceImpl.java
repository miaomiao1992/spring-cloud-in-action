package cn.mesmile.finance.service.impl;

import cn.mesmile.common.exception.ServiceException;
import cn.mesmile.finance.entity.AdminAddress;
import cn.mesmile.finance.entity.Coin;
import cn.mesmile.finance.mapper.AdminAddressMapper;
import cn.mesmile.finance.service.AdminAddressService;
import cn.mesmile.finance.service.CoinService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import net.bytebuddy.asm.Advice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 平台归账手续费等账户 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class AdminAddressServiceImpl extends ServiceImpl<AdminAddressMapper, AdminAddress> implements AdminAddressService {

    @Autowired
    private CoinService coinService;

    @Override
    public Page<AdminAddress> findAdminAddressPage(Page<AdminAddress> page,Long coinId) {
        Page<AdminAddress> result = page(page, Wrappers.<AdminAddress>lambdaQuery().eq(coinId != null, AdminAddress::getCoinId, coinId));
        return result;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean saveAdminAddress(AdminAddress adminAddress) {
        Long coinId = adminAddress.getCoinId();
        Coin coin = coinService.getById(coinId);
        if (coin == null){
            throw new ServiceException("输入的币种id有误");
        }
        String type = coin.getType();
        adminAddress.setCoinType(type);
        return save(adminAddress);
    }
}
