package cn.mesmile.finance.mapper;

import cn.mesmile.finance.entity.CashWithdrawAuditRecord;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 提现审核记录 Mapper 接口
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CashWithdrawAuditRecordMapper extends BaseMapper<CashWithdrawAuditRecord> {

}
