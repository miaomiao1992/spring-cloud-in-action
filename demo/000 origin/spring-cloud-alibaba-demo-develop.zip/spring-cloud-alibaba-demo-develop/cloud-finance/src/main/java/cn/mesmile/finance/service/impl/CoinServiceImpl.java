package cn.mesmile.finance.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.mesmile.finance.entity.Coin;
import cn.mesmile.finance.mapper.CoinMapper;
import cn.mesmile.finance.service.CoinService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.print.attribute.standard.MediaSize;

/**
 * <p>
 * 币种配置信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class CoinServiceImpl extends ServiceImpl<CoinMapper, Coin> implements CoinService {

    @Override
    public Page<Coin> findCoinPage(Page<Coin> page,String name, String type,
                                   String title,Integer status,String walletType) {
        Page<Coin> result = page(page, Wrappers.<Coin>lambdaQuery()
            .like(StrUtil.isNotBlank(name),Coin::getName, name)
            .eq(StrUtil.isNotBlank(type),Coin::getType, type)
            .like(StrUtil.isNotBlank(title),Coin::getTitle, title)
            .eq(status != null,Coin::getStatus, status)
            .eq(StrUtil.isNotBlank(walletType),Coin::getWallet, walletType)
        );
        return result;
    }

    @Override
    public Coin findCoinByCoinName(String coinName) {
        Coin one = getOne(Wrappers.<Coin>lambdaQuery().eq(Coin::getName, coinName).eq(Coin::getStatus, 1));
        return one;
    }
}
