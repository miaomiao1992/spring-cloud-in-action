package cn.mesmile.finance.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 平仓详情
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("forex_close_position_order")
@ApiModel(value = "ForexClosePositionOrder对象", description = "平仓详情")
public class ForexClosePositionOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户ID")
    private Long userId;

    @ApiModelProperty("交易对ID")
    private Long marketId;

    @ApiModelProperty("交易对名称")
    private String marketName;

    @ApiModelProperty("持仓方向：1-买；2-卖")
    private Integer type;

    @ApiModelProperty("资金账户ID")
    private Long accountId;

    @ApiModelProperty("委托订单号")
    private Long entrustOrderId;

    @ApiModelProperty("成交订单号")
    private Long orderId;

    @ApiModelProperty("成交价")
    private BigDecimal price;

    @ApiModelProperty("成交数量")
    private BigDecimal num;

    @ApiModelProperty("关联开仓订单号")
    private Long openId;

    @ApiModelProperty("平仓盈亏")
    private BigDecimal profit;

    @ApiModelProperty("返回还保证金")
    private BigDecimal unlockMargin;

    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;

    @ApiModelProperty("创建时间")
    private Date created;


}
