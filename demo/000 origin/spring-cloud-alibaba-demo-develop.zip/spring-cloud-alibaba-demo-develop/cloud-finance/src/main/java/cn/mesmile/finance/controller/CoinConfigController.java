package cn.mesmile.finance.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.CoinConfigService;
import cn.mesmile.finance.entity.CoinConfig;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 币种配置信息 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "币种配置信息相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/finance/coin-config")
public class CoinConfigController {

    private final CoinConfigService coinConfigService;

    @ApiOperation("分页查询币种配置信息")
    @GetMapping("/get")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
    })
    public R<Page<CoinConfig>> findCoinConfigPage(@ApiIgnore Page<CoinConfig> page){
        Page<CoinConfig> result = coinConfigService.findCoinConfigPage(page);
        return R.data(result);
    }

    @ApiOperation("查询单条信息")
    @GetMapping("/info/{coinId}")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "coinId值",name = "coinId"),
    })
    public R<CoinConfig> info(@PathVariable("coinId")Long coinId){
        CoinConfig coinConfig = coinConfigService.getCoinConfig(coinId);
        return R.data(coinConfig);
    }

    @PostMapping
    @ApiOperation("新增币种配置信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "coinConfig", value = "coinConfig对象的json数据")
    })
    public R save(@RequestBody CoinConfig coinConfig) {
        boolean save = coinConfigService.save(coinConfig);
        return R.status(save);
    }

    @PostMapping("/update")
    @ApiOperation("修改币种配置信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "coinConfig", value = "coinConfig对象的json数据")
    })
    public R update(@RequestBody CoinConfig coinConfig){
        boolean result = coinConfigService.saveOrUpdate(coinConfig);
        return R.status(result);
    }

    @ApiOperation("删除币种配置信息")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = coinConfigService.removeByIds(ids);
        return R.data(delete);
    }
}
