package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.ForexAccount;
import cn.mesmile.finance.mapper.ForexAccountMapper;
import cn.mesmile.finance.service.ForexAccountService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 创新交易持仓信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class ForexAccountServiceImpl extends ServiceImpl<ForexAccountMapper, ForexAccount> implements ForexAccountService {

    @Override
    public Page<ForexAccount> findForexAccountPage(Page<ForexAccount> page) {
        Page<ForexAccount> result = page(page);
        return result;
    }
}
