package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.UserCoinFreeze;
import cn.mesmile.finance.mapper.UserCoinFreezeMapper;
import cn.mesmile.finance.service.UserCoinFreezeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class UserCoinFreezeServiceImpl extends ServiceImpl<UserCoinFreezeMapper, UserCoinFreeze> implements UserCoinFreezeService {

    @Override
    public Page<UserCoinFreeze> findUserCoinFreezePage(Page<UserCoinFreeze> page) {
        Page<UserCoinFreeze> result = page(page);
        return result;
    }
}
