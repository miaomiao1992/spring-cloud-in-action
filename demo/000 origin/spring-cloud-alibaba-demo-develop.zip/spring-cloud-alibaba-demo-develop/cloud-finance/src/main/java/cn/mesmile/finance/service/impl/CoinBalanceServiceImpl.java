package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.CoinBalance;
import cn.mesmile.finance.mapper.CoinBalanceMapper;
import cn.mesmile.finance.service.CoinBalanceService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 币种余额 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class CoinBalanceServiceImpl extends ServiceImpl<CoinBalanceMapper, CoinBalance> implements CoinBalanceService {

    @Override
    public Page<CoinBalance> findCoinBalancePage(Page<CoinBalance> page) {
        Page<CoinBalance> result = page(page);
        return result;
    }
}
