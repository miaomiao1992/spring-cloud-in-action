package cn.mesmile.finance.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.RestController;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import springfox.documentation.annotations.ApiIgnore;
import cn.mesmile.finance.service.AdminAddressService;
import cn.mesmile.finance.entity.AdminAddress;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import cn.mesmile.common.result.R;
import java.util.List;

/**
 * <p>
 * 平台归账手续费等账户 前端控制器
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Api(value = "平台归账手续费等账户相关api")
@RequiredArgsConstructor
@RestController
@RequestMapping("/adminAddress")
public class AdminAddressController {

    private final AdminAddressService adminAddressService;

    @ApiOperation("分页查询平台归账手续费等账户")
    @GetMapping
    @ApiImplicitParams({
            @ApiImplicitParam(value = "当前页",name = "current",defaultValue = "1"),
            @ApiImplicitParam(value = "每页显示条数",name = "size",defaultValue = "10"),
            @ApiImplicitParam(value = "币种id",name = "coinId")
    })
    public R<Page<AdminAddress>> findAdminAddressPage(@ApiIgnore Page<AdminAddress> page,Long coinId){
        Page<AdminAddress> result = adminAddressService.findAdminAddressPage(page,coinId);
        return R.data(result);
    }

    @PostMapping
    @ApiOperation("新增平台归账手续费等账户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "adminAddress", value = "adminAddress对象的json数据")
    })
    public R save(@RequestBody AdminAddress adminAddress){
        boolean save = adminAddressService.saveAdminAddress(adminAddress);
        if (!save){
            return R.fail("新增失败");
        }
        return R.data(adminAddress);
    }

    @PostMapping("/update")
    @ApiOperation("修改平台归账手续费等账户")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "adminAddress", value = "adminAddress对象的json数据")
    })
    public R update(@RequestBody AdminAddress adminAddress){
        boolean update = adminAddressService.updateById(adminAddress);
        return R.status(update);
    }

    @ApiOperation("删除平台归账手续费等账户")
    @PostMapping("/delete")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "多个id值",name = "ids"),
    })
    public R updateCoinType(@RequestBody List<String> ids){
        boolean delete = adminAddressService.removeByIds(ids);
        return R.data(delete);
    }
}
