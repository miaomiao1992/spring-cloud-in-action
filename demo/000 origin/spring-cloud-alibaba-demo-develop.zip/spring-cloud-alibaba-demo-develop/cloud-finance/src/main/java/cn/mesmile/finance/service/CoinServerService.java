package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.CoinServer;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 监测当前服务器Ip状态 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CoinServerService extends IService<CoinServer> {

    /**
     * 分页查找监测当前服务器Ip状态
     * @param page 分页信息
     * @return
     */
    Page<CoinServer> findCoinServerPage(Page<CoinServer> page);
}

