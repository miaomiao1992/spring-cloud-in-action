package cn.mesmile.finance.entity;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.validation.annotation.Validated;

/**
 * <p>
 * 充值表
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("cash_recharge")
@ApiModel(value = "CashRecharge对象", description = "充值表")
public class CashRecharge implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("自增id")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户id")
    private Long userId;

    @ApiModelProperty("币种id")
    private Long coinId;

    @ApiModelProperty("币种名：cny，人民币；")
    private String coinName;

    @ApiModelProperty("数量（充值金额）")
    private BigDecimal num;

    @ApiModelProperty("手续费")
    private BigDecimal fee;

    @ApiModelProperty("手续费币种")
    private String feecoin;

    @ApiModelProperty("成交量（到账金额）")
    private BigDecimal mum;

    @ApiModelProperty("类型：alipay，支付宝；cai1pay，财易付；bank，银联；")
    private String type;

    @ApiModelProperty("充值订单号")
    private String tradeno;

    @ApiModelProperty("第三方订单号")
    private String outtradeno;

    @ApiModelProperty("充值备注备注")
    private String remark;

    @ApiModelProperty("审核备注")
    private String auditRemark;

    @ApiModelProperty("当前审核级数")
    private Integer step;

    @ApiModelProperty("状态：0-待审核；1-审核通过；2-拒绝；3-充值成功；")
    private Integer status;

    @TableField(value = "created", fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;

    @TableField(value = "last_update_time", fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("更新时间")
    private Date lastUpdateTime;

    @ApiModelProperty("银行卡账户名")
    private String name;

    @ApiModelProperty("开户行")
    private String bankName;

    @ApiModelProperty("银行卡号")
    private String bankCard;

    @ApiModelProperty("最后确认到账时间。")
    private Date lastTime;


}
