package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.UserCoinFreeze;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface UserCoinFreezeService extends IService<UserCoinFreeze> {

    /**
     * 分页查找
     * @param page 分页信息
     * @return
     */
    Page<UserCoinFreeze> findUserCoinFreezePage(Page<UserCoinFreeze> page);
}

