package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.CashWithdrawals;
import cn.mesmile.finance.entity.CoinRecharge;
import cn.mesmile.finance.mapper.CoinRechargeMapper;
import cn.mesmile.finance.service.CoinRechargeService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * <p>
 * 数字货币充值记录 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class CoinRechargeServiceImpl extends ServiceImpl<CoinRechargeMapper, CoinRecharge> implements CoinRechargeService {

    @Override
    public Page<CoinRecharge> findCoinRechargePage(Page<CoinRecharge> page, String userName, String mobile, Integer status, Integer numMin,
                                                   Integer numMax, Date startTime, Date endTime) {
        //  todo userName  mobile 转换成 userId
        Page<CoinRecharge> result = page(page,  Wrappers.<CoinRecharge>lambdaQuery()
                .eq(status != null, CoinRecharge::getStatus, status)
                .between(numMin!=null && numMax != null, CoinRecharge::getAmount, numMin, numMax)
                .between(startTime!=null && endTime != null, CoinRecharge::getCreated, startTime, endTime));
        return result;
    }
}
