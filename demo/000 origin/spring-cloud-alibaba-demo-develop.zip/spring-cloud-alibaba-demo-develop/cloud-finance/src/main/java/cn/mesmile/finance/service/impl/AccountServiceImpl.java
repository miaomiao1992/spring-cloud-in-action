package cn.mesmile.finance.service.impl;

import cn.mesmile.common.exception.ServiceException;
import cn.mesmile.finance.entity.Account;
import cn.mesmile.finance.entity.AccountDetail;
import cn.mesmile.finance.entity.Coin;
import cn.mesmile.finance.mapper.AccountMapper;
import cn.mesmile.finance.service.AccountDetailService;
import cn.mesmile.finance.service.AccountService;
import cn.mesmile.finance.service.CoinService;
import com.alibaba.nacos.api.config.ConfigService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/**
 * <p>
 * 用户财产记录 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class AccountServiceImpl extends ServiceImpl<AccountMapper, Account> implements AccountService {

    @Autowired
    private AccountDetailService accountDetailService;
    @Autowired
    private CoinService coinService;

    @Override
    public Page<Account> findAccountPage(Page<Account> page) {
        Page<Account> result = page(page);
        return result;
    }

    @Override
    public boolean transferAccountAmount(Long adminId, Long userId, Long orderNum, Long coinId, BigDecimal num, BigDecimal fee,
                            String businessType, Integer direction,String remark
                ) {
        Account account = getCoinAccount(userId, coinId);
        if (account == null){
            throw new ServiceException("用户没有账号");
        }
        // 添加一条流水记录
        AccountDetail accountDetail = new AccountDetail();
        accountDetail.setUserId(userId);
        accountDetail.setCoinId(coinId);
        accountDetail.setAccountId(adminId);
        accountDetail.setOrderId(orderNum);
        accountDetail.setDirection(1);
        accountDetail.setBusinessType(businessType);
        accountDetail.setDirection(direction);
        accountDetail.setRemark(remark);
        accountDetail.setAmount(num);
        accountDetail.setFee(fee);
        accountDetail.setRefAccountId(adminId);
        boolean save = accountDetailService.save(accountDetail);
        if (save){
            account.setBalanceAmount(account.getBalanceAmount().add(num));
            return updateById(account);
        }
        return false;
    }

    @Override
    public Account findCoinByCoinName(Long userId, String coinName) {
        Coin coin = coinService.findCoinByCoinName(coinName);
        if (coin == null){
            throw new ServiceException("当前货币不存在");
        }
        Account account = getOne(Wrappers.<Account>lambdaQuery().eq(Account::getCoinId, coin.getId()).eq(Account::getUserId, userId));

        // 从配置文件中查询费率问题
        account.setSellRate(new BigDecimal("1"));
        account.setBuyRate(new BigDecimal("0.95"));

        return account;
    }

    private Account getCoinAccount(Long userId, Long coinId) {
        Account account = getOne(Wrappers.<Account>lambdaQuery()
                .eq(Account::getCoinId, coinId).eq(Account::getUserId, userId).eq(Account::getStatus, 1));
        return account;
    }
}
