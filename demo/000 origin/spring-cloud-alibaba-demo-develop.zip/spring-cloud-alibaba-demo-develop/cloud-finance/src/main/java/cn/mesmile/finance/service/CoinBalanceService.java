package cn.mesmile.finance.service;

import cn.mesmile.finance.entity.CoinBalance;
import com.baomidou.mybatisplus.extension.service.IService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

/**
 * <p>
 * 币种余额 服务类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
public interface CoinBalanceService extends IService<CoinBalance> {

    /**
     * 分页查找币种余额
     * @param page 分页信息
     * @return
     */
    Page<CoinBalance> findCoinBalancePage(Page<CoinBalance> page);
}

