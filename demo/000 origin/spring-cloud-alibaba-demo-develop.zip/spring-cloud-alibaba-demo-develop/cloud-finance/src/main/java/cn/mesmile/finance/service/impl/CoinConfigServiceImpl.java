package cn.mesmile.finance.service.impl;

import cn.mesmile.finance.entity.CoinConfig;
import cn.mesmile.finance.mapper.CoinConfigMapper;
import cn.mesmile.finance.service.CoinConfigService;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 币种配置信息 服务实现类
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Service
@Transactional(rollbackFor = Exception.class,propagation = Propagation.SUPPORTS,readOnly = true)
public class CoinConfigServiceImpl extends ServiceImpl<CoinConfigMapper, CoinConfig> implements CoinConfigService {

    @Override
    public Page<CoinConfig> findCoinConfigPage(Page<CoinConfig> page) {
        Page<CoinConfig> result = page(page);
        return result;
    }

    @Override
    public CoinConfig getCoinConfig(Long coinId) {
        // 币种id 等于 币种配置的id
        CoinConfig coinConfig = getOne(Wrappers.<CoinConfig>lambdaQuery().eq(CoinConfig::getId, coinId));
        return coinConfig;
    }
}
