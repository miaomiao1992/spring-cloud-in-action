package cn.mesmile.finance.entity;

import java.math.BigDecimal;

import com.baomidou.mybatisplus.annotation.*;

import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * <p>
 * 数字货币提现记录
 * </p>
 *
 * @author zb
 * @since 2022-03-20
 */
@Data
@TableName("coin_withdraw")
@ApiModel(value = "CoinWithdraw对象", description = "数字货币提现记录")
public class CoinWithdraw implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty("自增id")
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    @ApiModelProperty("用户id")
    private Long userId;

    @ApiModelProperty("币种id")
    private Long coinId;

    @ApiModelProperty("币种名称")
    private String coinName;

    @ApiModelProperty("币种类型")
    private String coinType;

    @ApiModelProperty("钱包地址")
    private String address;

    @ApiModelProperty("交易id")
    private String txid;

    @ApiModelProperty("提现量")
    private BigDecimal num;

    @ApiModelProperty("手续费()")
    private BigDecimal fee;

    @ApiModelProperty("实际提现")
    private BigDecimal mum;

    @ApiModelProperty("0站内1其他2手工提币")
    private Boolean type;

    @ApiModelProperty("链上手续费花费")
    private BigDecimal chainFee;

    @ApiModelProperty("区块高度")
    private Integer blockNum;

    @ApiModelProperty("后台审核人员提币备注备注")
    private String remark;

    @ApiModelProperty("钱包提币备注备注")
    private String walletMark;

    @ApiModelProperty("当前审核级数")
    private Integer step;

    @ApiModelProperty("状态：0-审核中；1-成功；2-拒绝；3-撤销；4-审核通过；5-打币中；")
    private Integer status;

    @ApiModelProperty("审核时间")
    private Date auditTime;

    @TableField(value = "last_update_time", fill = FieldFill.INSERT_UPDATE)
    @ApiModelProperty("修改时间")
    private Date lastUpdateTime;

    @TableField(value = "created", fill = FieldFill.INSERT)
    @ApiModelProperty("创建时间")
    private Date created;


}
