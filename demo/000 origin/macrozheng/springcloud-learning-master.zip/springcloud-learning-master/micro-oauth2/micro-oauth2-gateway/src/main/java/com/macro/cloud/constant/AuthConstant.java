package com.macro.cloud.constant;

/**
 * Created by macro on 2020/6/19.
 */
public class AuthConstant {

    public static final String AUTHORITY_PREFIX = "ROLE_";

    public static final String AUTHORITY_CLAIM_NAME = "authorities";

}
