package com.macro.cloud.constant;

/**
 * Created by macro on 2020/6/19.
 */
public class RedisConstant {

    public static final String RESOURCE_ROLES_MAP = "AUTH:RESOURCE_ROLES_MAP";

}
