#  dubbo整合spring cloud gateway
《[Dubbo想要个网关怎么办？试试整合Spring Cloud Gateway](https://mp.weixin.qq.com/s/_idYl39i1eQejLLLlCW2sg)》文章配套源码



## 依赖环境
* jdk 1.8
* Nacos 1.3
* Spring Boot 2.2.8.RELEASE
* Spring Cloud Hoxton.SR5
* Spring Cloud Alibaba 2.2.1.RELEASE
