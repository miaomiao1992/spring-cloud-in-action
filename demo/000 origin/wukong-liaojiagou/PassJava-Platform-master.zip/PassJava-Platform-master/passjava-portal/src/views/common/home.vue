<template>
  <div class="mod-home">
    <h1>PassJava（Java面试学习平台） 项目全套学习教程连载中</h1>
    <h3>简介</h3>
    <ul>
      <li>PassJava-Portal 基于vue、element-ui构建开发，实现PassJava后台管理前端功能，提供一套更优的前端解决方案</li>
      <li>PassJava-Platform 项目基于SpringCloud的业务平台</li>
      <li>PassJava-Learning 项目是PassJava（佳必过）项目的学习教程。对架构、业务、技术要点进行讲解。</li>
      <li>PassJava 是一款Java面试刷题的开源系统，可以用零碎时间利用小程序查看常见面试题，夯实Java基础。</li>
      <li>PassJava 项目可以教会你如何搭建SpringBoot项目，Spring Cloud项目</li>
      <li>采用流行的技术，如 SpringBoot、MyBatis、Redis、 MySql、 MongoDB、 RabbitMQ、Elasticsearch，采用Docker容器化部署。</li>
    </ul>

    <h3>更好的阅读体验</h3>
    <ul>
      <li>文档地址<a href="http://www.jayh.club" target="blank">http://www.jayh.club</a></li>
      <li>备用地址<a href="https://jackson0714.github.io/PassJava-Learning" target="_blank">https://jackson0714.github.io/PassJava-Learning</a></li>
    </ul>
    <h3>项目介绍</h3>
    <ul>
      <li>PassJava-Portal基于vue、element-ui构建开发，实现<a href="https://github.com/Jackson0714/PassJava-Platform" target="_blank">PassJava-Platform</a>后台管理前端功能，提供一套更优的前端解决方案</li>
      <li>前后端分离，通过token进行数据交互，可独立部署</li>
      <li>主题定制，通过scss变量统一一站式定制</li>
      <li>动态菜单，通过菜单管理统一管理访问路由</li>
      <li>数据切换，通过mock配置对接口数据／mock模拟数据进行切换</li>
      <li>发布时，可动态配置CDN静态资源／切换新旧版本</li>
      <li>演示地址：<a href="" target="_blank"></a> (账号密码：admin/admin)</li>
    </ul>
    <h3>获取帮助</h3>
    <ul>
      <li>官方社区：<a href="https://github.com/Jackson0714/PassJava-Learning" target="_blank">https://github.com/Jackson0714/PassJava-Learning</a></li>
      <li>前端Git地址：<a href="https://github.com/Jackson0714/PassJava-Portal" target="_blank">https://github.com/Jackson0714/PassJava-Portal</a></li>
      <li>后台Git地址：<a href="https://github.com/Jackson0714/PassJava-Platform" target="_blank">https://github.com/Jackson0714/PassJava-Platformt</a></li>
      <li>如需关注项目最新动态，请Watch、Star项目，同时也是对项目最好的支持</li>
    </ul>
    <h3>公众号</h3>
    <img src="http://cdn.jayh.club/blog/20200405/K6buDl2MUwGe.png?imageslim"/>
  </div>
</template>

<script>
  export default {
  }
</script>

<style>
  .mod-home {
    line-height: 1.5;
  }
</style>

