package com.jackson0714.passjava.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassjavaGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
