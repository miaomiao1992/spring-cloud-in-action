package com.jackson0714.passjava.content;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassjavaContentApplicationTests {

    @Test
    void contextLoads() {
    }

}
