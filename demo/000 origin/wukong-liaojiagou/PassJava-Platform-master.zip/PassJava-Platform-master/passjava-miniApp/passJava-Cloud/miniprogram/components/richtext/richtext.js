const config = require('../../config')

Component({
  /**
   * 组件的属性列表
   */
  properties: {
    detail: String
  },

  /**
   * 页面的初始数据
   */
  data: {
    
  },

  /**
   * 组件的方法列表
   */
  methods: {
    
  }
})
