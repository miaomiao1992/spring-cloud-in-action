/*! Project:无, Create:FWS 2020.03.01 19:00, Update:FWS 2020.03.01 19:00 */ 
module.exports=function(e){var a=e.getLanguage("c-like").rawDefinition();return a.name="C",a.aliases=["c","h"],a};