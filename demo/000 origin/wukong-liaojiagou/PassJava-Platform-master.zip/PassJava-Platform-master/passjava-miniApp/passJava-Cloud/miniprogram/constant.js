module.exports = {
  SYSTEM_ERROR_TIP: '网络闹点小脾气，一会儿就好~'
}