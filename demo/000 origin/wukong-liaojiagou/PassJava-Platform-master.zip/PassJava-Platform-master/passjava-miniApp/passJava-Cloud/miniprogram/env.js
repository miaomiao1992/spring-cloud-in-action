const isProdEnv = false
const baseUrl = isProdEnv ? 'http://localhost:8060/api' : 'http://localhost:8060/api'


module.exports = {
  miniAppid: 'wx5cc9249f826b8d4b',
  imagesFile: '',
  baseUrl: baseUrl
}