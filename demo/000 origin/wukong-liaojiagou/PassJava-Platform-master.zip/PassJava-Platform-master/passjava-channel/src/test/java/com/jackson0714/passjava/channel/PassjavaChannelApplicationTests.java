package com.jackson0714.passjava.channel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassjavaChannelApplicationTests {

    @Test
    void contextLoads() {
    }

}
